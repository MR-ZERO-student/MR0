"""
Risk Management Module

This module implements stop-loss and take-profit calculations based on technical analysis
and market volatility.
"""

import logging
import math
from datetime import datetime
import pandas as pd
import numpy as np

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class RiskManager:
    """Class for managing risk through stop-loss and take-profit calculations"""
    
    def __init__(self):
        """Initialize the risk manager"""
        # ATR multipliers from config
        self.atr_multiplier_sl = config.ATR_MULTIPLIER_SL
        self.atr_multiplier_tp = config.ATR_MULTIPLIER_TP
        
        logger.info("Risk manager initialized")
    
    def calculate_stop_loss(self, entry_price, atr_value, position_type="long"):
        """
        Calculate stop loss price based on ATR
        
        Args:
            entry_price: Entry price for the trade
            atr_value: ATR value for the asset
            position_type: 'long' or 'short'
            
        Returns:
            float: Stop loss price
        """
        try:
            if position_type.lower() == "long":
                stop_loss = entry_price - (atr_value * self.atr_multiplier_sl)
            else:  # Short position
                stop_loss = entry_price + (atr_value * self.atr_multiplier_sl)
            
            return stop_loss
        
        except Exception as e:
            logger.error(f"Error calculating stop loss: {e}", exc_info=True)
            # Default to 5% below/above entry price
            if position_type.lower() == "long":
                return entry_price * 0.95
            else:
                return entry_price * 1.05
    
    def calculate_take_profit(self, entry_price, atr_value, position_type="long"):
        """
        Calculate take profit price based on ATR
        
        Args:
            entry_price: Entry price for the trade
            atr_value: ATR value for the asset
            position_type: 'long' or 'short'
            
        Returns:
            float: Take profit price
        """
        try:
            if position_type.lower() == "long":
                take_profit = entry_price + (atr_value * self.atr_multiplier_tp)
            else:  # Short position
                take_profit = entry_price - (atr_value * self.atr_multiplier_tp)
            
            return take_profit
        
        except Exception as e:
            logger.error(f"Error calculating take profit: {e}", exc_info=True)
            # Default to 10% above/below entry price
            if position_type.lower() == "long":
                return entry_price * 1.1
            else:
                return entry_price * 0.9
    
    def calculate_risk_reward_ratio(self, entry_price, stop_loss, take_profit):
        """
        Calculate risk-reward ratio for a trade
        
        Args:
            entry_price: Entry price for the trade
            stop_loss: Stop loss price
            take_profit: Take profit price
            
        Returns:
            float: Risk-reward ratio
        """
        try:
            # Calculate risk and reward
            if entry_price > stop_loss:  # Long position
                risk = entry_price - stop_loss
                reward = take_profit - entry_price
            else:  # Short position
                risk = stop_loss - entry_price
                reward = entry_price - take_profit
            
            # Calculate ratio
            if risk > 0 and reward > 0:
                ratio = reward / risk
            else:
                logger.warning("Invalid risk or reward value, cannot calculate ratio")
                ratio = 0
            
            return ratio
        
        except Exception as e:
            logger.error(f"Error calculating risk-reward ratio: {e}", exc_info=True)
            return 0
    
    def calculate_exit_points(self, signal_data):
        """
        Calculate stop loss and take profit based on signal data
        
        Args:
            signal_data: Signal data from technical analysis
            
        Returns:
            dict with exit points
        """
        try:
            # Extract relevant data from signal
            entry_price = signal_data.get('price', 0)
            atr = signal_data.get('atr', 0)
            trend = signal_data.get('trend', 0)
            
            # Determine position type based on trend
            position_type = "long" if trend > 0 else "short"
            
            # If ATR is available, use it for calculations
            if atr > 0:
                stop_loss = self.calculate_stop_loss(entry_price, atr, position_type)
                take_profit = self.calculate_take_profit(entry_price, atr, position_type)
            else:
                # Use default percentages if ATR is not available
                if position_type == "long":
                    stop_loss = entry_price * 0.95  # 5% below entry
                    take_profit = entry_price * 1.15  # 15% above entry
                else:
                    stop_loss = entry_price * 1.05  # 5% above entry
                    take_profit = entry_price * 0.85  # 15% below entry
            
            # Calculate risk-reward ratio
            risk_reward_ratio = self.calculate_risk_reward_ratio(entry_price, stop_loss, take_profit)
            
            return {
                "entry_price": entry_price,
                "stop_loss": stop_loss,
                "take_profit": take_profit,
                "position_type": position_type,
                "risk_reward_ratio": risk_reward_ratio,
                "atr_used": atr > 0
            }
        
        except Exception as e:
            logger.error(f"Error calculating exit points: {e}", exc_info=True)
            return {
                "entry_price": signal_data.get('price', 0),
                "stop_loss": 0,
                "take_profit": 0,
                "position_type": "unknown",
                "risk_reward_ratio": 0,
                "atr_used": False
            }
    
    def adjust_for_volatility(self, exit_points, volatility_factor):
        """
        Adjust stop loss and take profit based on market volatility
        
        Args:
            exit_points: Exit points from calculate_exit_points
            volatility_factor: Factor representing current market volatility (1.0 = normal)
            
        Returns:
            dict with adjusted exit points
        """
        try:
            # Make a copy to avoid modifying the original
            adjusted = exit_points.copy()
            
            # Adjust stop loss and take profit based on volatility
            entry_price = adjusted['entry_price']
            position_type = adjusted['position_type']
            
            if position_type == "long":
                # For long positions, higher volatility means wider stops
                sl_distance = entry_price - adjusted['stop_loss']
                tp_distance = adjusted['take_profit'] - entry_price
                
                adjusted_sl_distance = sl_distance * volatility_factor
                adjusted_tp_distance = tp_distance * volatility_factor
                
                adjusted['stop_loss'] = entry_price - adjusted_sl_distance
                adjusted['take_profit'] = entry_price + adjusted_tp_distance
            else:
                # For short positions, higher volatility means wider stops
                sl_distance = adjusted['stop_loss'] - entry_price
                tp_distance = entry_price - adjusted['take_profit']
                
                adjusted_sl_distance = sl_distance * volatility_factor
                adjusted_tp_distance = tp_distance * volatility_factor
                
                adjusted['stop_loss'] = entry_price + adjusted_sl_distance
                adjusted['take_profit'] = entry_price - adjusted_tp_distance
            
            # Recalculate risk-reward ratio
            adjusted['risk_reward_ratio'] = self.calculate_risk_reward_ratio(
                entry_price, adjusted['stop_loss'], adjusted['take_profit']
            )
            
            return adjusted
        
        except Exception as e:
            logger.error(f"Error adjusting for volatility: {e}", exc_info=True)
            return exit_points
    
    def calculate_trailing_stop(self, current_price, highest_price, atr_value, position_type="long"):
        """
        Calculate trailing stop loss price
        
        Args:
            current_price: Current price of the asset
            highest_price: Highest price reached since entry (for long) or lowest price (for short)
            atr_value: ATR value for the asset
            position_type: 'long' or 'short'
            
        Returns:
            float: Trailing stop loss price
        """
        try:
            if position_type.lower() == "long":
                # For long positions, trail below the highest price
                trailing_stop = highest_price - (atr_value * self.atr_multiplier_sl)
                
                # Ensure trailing stop is not below the current stop loss
                trailing_stop = max(trailing_stop, self.calculate_stop_loss(current_price, atr_value, position_type))
            else:
                # For short positions, trail above the lowest price
                trailing_stop = highest_price + (atr_value * self.atr_multiplier_sl)
                
                # Ensure trailing stop is not above the current stop loss
                trailing_stop = min(trailing_stop, self.calculate_stop_loss(current_price, atr_value, position_type))
            
            return trailing_stop
        
        except Exception as e:
            logger.error(f"Error calculating trailing stop: {e}", exc_info=True)
            return current_price * (0.95 if position_type.lower() == "long" else 1.05)
    
    def evaluate_risk_score(self, signal_data, exit_points):
        """
        Calculate a risk score for a potential trade
        
        Args:
            signal_data: Signal data from technical analysis
            exit_points: Exit points from calculate_exit_points
            
        Returns:
            dict with risk evaluation
        """
        try:
            # Extract relevant data
            trend_strength = signal_data.get('trend_strength', 0)
            confidence = signal_data.get('confidence', 0)
            risk_reward_ratio = exit_points.get('risk_reward_ratio', 0)
            
            # Calculate base risk score (0-100)
            # Higher is better (less risky)
            base_score = 0
            
            # Factor 1: Trend strength (0-40 points)
            trend_score = (trend_strength / 100) * 40
            
            # Factor 2: Signal confidence (0-30 points)
            confidence_score = (confidence / 100) * 30
            
            # Factor 3: Risk-reward ratio (0-30 points)
            # RR ratio of 3.0 or higher gets full points
            rr_score = min(risk_reward_ratio / 3, 1) * 30
            
            # Calculate total score
            risk_score = trend_score + confidence_score + rr_score
            
            # Determine risk level
            if risk_score >= 80:
                risk_level = "Low"
            elif risk_score >= 60:
                risk_level = "Medium"
            elif risk_score >= 40:
                risk_level = "High"
            else:
                risk_level = "Very High"
            
            return {
                "risk_score": risk_score,
                "risk_level": risk_level,
                "trend_score": trend_score,
                "confidence_score": confidence_score,
                "risk_reward_score": rr_score,
                "max_score": 100
            }
        
        except Exception as e:
            logger.error(f"Error evaluating risk score: {e}", exc_info=True)
            return {
                "risk_score": 0,
                "risk_level": "Unknown",
                "trend_score": 0,
                "confidence_score": 0,
                "risk_reward_score": 0,
                "max_score": 100
            }
