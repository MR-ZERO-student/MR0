"""
Position Sizing Module

This module implements dynamic position sizing based on ATR and risk-per-trade settings.
"""

import logging
import math
from datetime import datetime
import pandas as pd
import numpy as np

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class PositionSizer:
    """Class for calculating optimal position sizes based on risk parameters"""
    
    def __init__(self, risk_per_trade=None):
        """
        Initialize the position sizer
        
        Args:
            risk_per_trade: Percentage of capital to risk per trade (0.01 = 1%)
        """
        # Use config value if not provided
        self.risk_per_trade = risk_per_trade if risk_per_trade is not None else config.RISK_PER_TRADE
        
        logger.info(f"Position sizer initialized with risk_per_trade={self.risk_per_trade}")
    
    def calculate_position_size(self, capital, entry_price, stop_loss_price):
        """
        Calculate position size based on fixed risk percentage and stop loss
        
        Args:
            capital: Available capital for trading
            entry_price: Entry price for the trade
            stop_loss_price: Stop loss price for the trade
            
        Returns:
            dict with position size details
        """
        try:
            # Calculate risk amount in currency
            risk_amount = capital * self.risk_per_trade
            
            # Calculate price difference between entry and stop loss
            if entry_price > stop_loss_price:  # Long position
                price_difference = entry_price - stop_loss_price
                position_type = "long"
            else:  # Short position
                price_difference = stop_loss_price - entry_price
                position_type = "short"
            
            # Calculate risk per unit
            risk_per_unit = price_difference
            
            # Calculate position size in units
            if risk_per_unit > 0:
                position_size_units = risk_amount / risk_per_unit
            else:
                logger.warning("Entry price and stop loss are the same, cannot calculate position size")
                position_size_units = 0
            
            # Calculate position size in currency
            position_size_currency = position_size_units * entry_price
            
            # Calculate percentage of capital
            capital_percentage = (position_size_currency / capital) * 100 if capital > 0 else 0
            
            # Calculate potential loss
            potential_loss = position_size_units * price_difference
            
            # Ensure potential loss matches risk amount (within rounding error)
            if abs(potential_loss - risk_amount) > 0.01 and risk_amount > 0:
                logger.warning(f"Potential loss ({potential_loss}) does not match risk amount ({risk_amount})")
            
            return {
                "position_size_units": position_size_units,
                "position_size_currency": position_size_currency,
                "capital_percentage": capital_percentage,
                "risk_amount": risk_amount,
                "position_type": position_type,
                "entry_price": entry_price,
                "stop_loss_price": stop_loss_price,
                "risk_per_unit": risk_per_unit
            }
        
        except Exception as e:
            logger.error(f"Error calculating position size: {e}", exc_info=True)
            return {
                "position_size_units": 0,
                "position_size_currency": 0,
                "capital_percentage": 0,
                "risk_amount": 0,
                "position_type": "unknown",
                "entry_price": entry_price,
                "stop_loss_price": stop_loss_price,
                "risk_per_unit": 0
            }
    
    def calculate_dynamic_position_size(self, capital, entry_price, atr_value, atr_multiplier=None):
        """
        Calculate position size based on ATR for stop loss placement
        
        Args:
            capital: Available capital for trading
            entry_price: Entry price for the trade
            atr_value: ATR value for the asset
            atr_multiplier: Multiplier for ATR to set stop loss (default from config)
            
        Returns:
            dict with position size details
        """
        try:
            # Use config value if not provided
            if atr_multiplier is None:
                atr_multiplier = config.ATR_MULTIPLIER_SL
            
            # Calculate stop loss based on ATR
            stop_loss_price = entry_price - (atr_value * atr_multiplier)
            
            # Calculate position size using the stop loss
            return self.calculate_position_size(capital, entry_price, stop_loss_price)
        
        except Exception as e:
            logger.error(f"Error calculating dynamic position size: {e}", exc_info=True)
            return {
                "position_size_units": 0,
                "position_size_currency": 0,
                "capital_percentage": 0,
                "risk_amount": 0,
                "position_type": "long",
                "entry_price": entry_price,
                "stop_loss_price": entry_price * 0.95,  # Default 5% below entry
                "risk_per_unit": 0
            }
    
    def calculate_position_size_for_signal(self, signal_data, capital):
        """
        Calculate position size based on a signal from technical analysis
        
        Args:
            signal_data: Signal data from technical analysis
            capital: Available capital for trading
            
        Returns:
            dict with position size details
        """
        try:
            # Extract relevant data from signal
            entry_price = signal_data.get('price', 0)
            atr = signal_data.get('atr', 0)
            stop_loss = signal_data.get('stop_loss', 0)
            
            # If stop loss is provided in signal, use it
            if stop_loss > 0:
                return self.calculate_position_size(capital, entry_price, stop_loss)
            
            # If ATR is provided, calculate dynamic position size
            elif atr > 0:
                return self.calculate_dynamic_position_size(capital, entry_price, atr)
            
            # If neither is provided, use a default 5% stop loss
            else:
                logger.warning("No stop loss or ATR provided in signal, using default 5% stop loss")
                stop_loss_price = entry_price * 0.95  # 5% below entry
                return self.calculate_position_size(capital, entry_price, stop_loss_price)
        
        except Exception as e:
            logger.error(f"Error calculating position size for signal: {e}", exc_info=True)
            return {
                "position_size_units": 0,
                "position_size_currency": 0,
                "capital_percentage": 0,
                "risk_amount": 0,
                "position_type": "unknown",
                "entry_price": 0,
                "stop_loss_price": 0,
                "risk_per_unit": 0
            }
    
    def adjust_for_max_position_size(self, position_data, max_position_pct=0.25):
        """
        Adjust position size to ensure it doesn't exceed a maximum percentage of capital
        
        Args:
            position_data: Position size data from calculate_position_size
            max_position_pct: Maximum position size as percentage of capital (0.25 = 25%)
            
        Returns:
            dict with adjusted position size details
        """
        try:
            # Check if position size exceeds maximum
            if position_data['capital_percentage'] > (max_position_pct * 100):
                # Calculate adjustment factor
                adjustment_factor = (max_position_pct * 100) / position_data['capital_percentage']
                
                # Adjust position size
                adjusted_position = position_data.copy()
                adjusted_position['position_size_units'] *= adjustment_factor
                adjusted_position['position_size_currency'] *= adjustment_factor
                adjusted_position['capital_percentage'] *= adjustment_factor
                adjusted_position['risk_amount'] *= adjustment_factor
                
                logger.info(f"Position size adjusted from {position_data['capital_percentage']:.2f}% to {adjusted_position['capital_percentage']:.2f}% of capital")
                
                return adjusted_position
            
            # No adjustment needed
            return position_data
        
        except Exception as e:
            logger.error(f"Error adjusting position size: {e}", exc_info=True)
            return position_data
