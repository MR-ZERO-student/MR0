"""
Trade Manager Module

This module integrates position sizing and risk management to provide
comprehensive trade management for cryptocurrency alerts.
"""

import logging
from datetime import datetime
import pandas as pd
import numpy as np

# Import local modules
from risk_management.position_sizing import PositionSizer
from risk_management.risk_calculator import RiskManager

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class TradeManager:
    """Class for managing trades with integrated risk management"""
    
    def __init__(self, capital=10000):
        """
        Initialize the trade manager
        
        Args:
            capital: Available capital for trading (default: $10,000)
        """
        self.capital = capital
        self.position_sizer = PositionSizer()
        self.risk_manager = RiskManager()
        
        # Track active trades
        self.active_trades = {}
        
        logger.info(f"Trade manager initialized with capital=${capital}")
    
    def process_signal(self, signal_data):
        """
        Process a trading signal and generate trade recommendations
        
        Args:
            signal_data: Signal data from technical analysis
            
        Returns:
            dict with trade recommendations
        """
        try:
            # Skip if signal is neutral
            if signal_data.get('signal', 0) == 0:
                return {
                    "recommendation": "No trade",
                    "reason": "Neutral signal"
                }
            
            # Calculate exit points (stop loss and take profit)
            exit_points = self.risk_manager.calculate_exit_points(signal_data)
            
            # Calculate position size
            position_data = self.position_sizer.calculate_position_size_for_signal(signal_data, self.capital)
            
            # Adjust position size for maximum allocation
            position_data = self.position_sizer.adjust_for_max_position_size(position_data)
            
            # Evaluate risk score
            risk_evaluation = self.risk_manager.evaluate_risk_score(signal_data, exit_points)
            
            # Determine if trade should be taken based on risk score
            take_trade = risk_evaluation['risk_score'] >= 50  # Minimum risk score threshold
            
            # Create trade recommendation
            recommendation = {
                "symbol": signal_data.get('symbol', 'Unknown'),
                "timestamp": datetime.now(),
                "signal": signal_data.get('signal', 0),
                "entry_price": signal_data.get('price', 0),
                "stop_loss": exit_points['stop_loss'],
                "take_profit": exit_points['take_profit'],
                "position_size_units": position_data['position_size_units'],
                "position_size_currency": position_data['position_size_currency'],
                "capital_percentage": position_data['capital_percentage'],
                "risk_amount": position_data['risk_amount'],
                "risk_reward_ratio": exit_points['risk_reward_ratio'],
                "risk_score": risk_evaluation['risk_score'],
                "risk_level": risk_evaluation['risk_level'],
                "recommendation": "Take trade" if take_trade else "Skip trade",
                "reason": self._get_recommendation_reason(signal_data, risk_evaluation, take_trade)
            }
            
            return recommendation
        
        except Exception as e:
            logger.error(f"Error processing signal: {e}", exc_info=True)
            return {
                "recommendation": "Error",
                "reason": f"Error processing signal: {str(e)}"
            }
    
    def _get_recommendation_reason(self, signal_data, risk_evaluation, take_trade):
        """Generate a reason for the trade recommendation"""
        if take_trade:
            if signal_data.get('signal', 0) > 0:
                return f"Strong BUY signal with {risk_evaluation['risk_level']} risk level"
            else:
                return f"Strong SELL signal with {risk_evaluation['risk_level']} risk level"
        else:
            if risk_evaluation['risk_score'] < 50:
                return f"Risk score too low ({risk_evaluation['risk_score']}/100)"
            elif signal_data.get('confidence', 0) < 60:
                return f"Signal confidence too low ({signal_data.get('confidence', 0)}%)"
            else:
                return "Insufficient trade parameters"
    
    def track_trade(self, trade_id, trade_data):
        """
        Track a new trade
        
        Args:
            trade_id: Unique identifier for the trade
            trade_data: Trade data from process_signal
            
        Returns:
            bool: Success or failure
        """
        try:
            # Add trade to active trades
            self.active_trades[trade_id] = {
                "entry_time": datetime.now(),
                "trade_data": trade_data,
                "current_price": trade_data['entry_price'],
                "highest_price": trade_data['entry_price'],
                "lowest_price": trade_data['entry_price'],
                "status": "open"
            }
            
            logger.info(f"Trade {trade_id} added to tracking")
            return True
        
        except Exception as e:
            logger.error(f"Error tracking trade: {e}", exc_info=True)
            return False
    
    def update_trade(self, trade_id, current_price):
        """
        Update a tracked trade with current price
        
        Args:
            trade_id: Unique identifier for the trade
            current_price: Current price of the asset
            
        Returns:
            dict: Updated trade status
        """
        try:
            # Check if trade exists
            if trade_id not in self.active_trades:
                logger.warning(f"Trade {trade_id} not found in active trades")
                return None
            
            # Get trade data
            trade = self.active_trades[trade_id]
            trade_data = trade['trade_data']
            
            # Update current price
            trade['current_price'] = current_price
            
            # Update highest and lowest prices
            trade['highest_price'] = max(trade['highest_price'], current_price)
            trade['lowest_price'] = min(trade['lowest_price'], current_price)
            
            # Check if stop loss or take profit hit
            if trade_data['signal'] > 0:  # Long position
                if current_price <= trade_data['stop_loss']:
                    trade['status'] = "closed"
                    trade['close_reason'] = "stop_loss"
                    trade['close_time'] = datetime.now()
                    trade['profit_loss'] = (current_price - trade_data['entry_price']) * trade_data['position_size_units']
                    trade['profit_loss_percentage'] = ((current_price / trade_data['entry_price']) - 1) * 100
                elif current_price >= trade_data['take_profit']:
                    trade['status'] = "closed"
                    trade['close_reason'] = "take_profit"
                    trade['close_time'] = datetime.now()
                    trade['profit_loss'] = (current_price - trade_data['entry_price']) * trade_data['position_size_units']
                    trade['profit_loss_percentage'] = ((current_price / trade_data['entry_price']) - 1) * 100
            else:  # Short position
                if current_price >= trade_data['stop_loss']:
                    trade['status'] = "closed"
                    trade['close_reason'] = "stop_loss"
                    trade['close_time'] = datetime.now()
                    trade['profit_loss'] = (trade_data['entry_price'] - current_price) * trade_data['position_size_units']
                    trade['profit_loss_percentage'] = ((trade_data['entry_price'] / current_price) - 1) * 100
                elif current_price <= trade_data['take_profit']:
                    trade['status'] = "closed"
                    trade['close_reason'] = "take_profit"
                    trade['close_time'] = datetime.now()
                    trade['profit_loss'] = (trade_data['entry_price'] - current_price) * trade_data['position_size_units']
                    trade['profit_loss_percentage'] = ((trade_data['entry_price'] / current_price) - 1) * 100
            
            # Calculate current profit/loss if trade is still open
            if trade['status'] == "open":
                if trade_data['signal'] > 0:  # Long position
                    trade['profit_loss'] = (current_price - trade_data['entry_price']) * trade_data['position_size_units']
                    trade['profit_loss_percentage'] = ((current_price / trade_data['entry_price']) - 1) * 100
                else:  # Short position
                    trade['profit_loss'] = (trade_data['entry_price'] - current_price) * trade_data['position_size_units']
                    trade['profit_loss_percentage'] = ((trade_data['entry_price'] / current_price) - 1) * 100
            
            # Update trailing stop if enabled
            if config.USE_TRAILING_STOP and trade['status'] == "open":
                # Get ATR from trade data or use a default value
                atr = trade_data.get('atr', trade_data['entry_price'] * 0.02)  # Default to 2% of entry price
                
                # Calculate trailing stop
                position_type = "long" if trade_data['signal'] > 0 else "short"
                reference_price = trade['highest_price'] if position_type == "long" else trade['lowest_price']
                
                trailing_stop = self.risk_manager.calculate_trailing_stop(
                    current_price, reference_price, atr, position_type
                )
                
                # Update stop loss if trailing stop is better
                if position_type == "long" and trailing_stop > trade_data['stop_loss']:
                    trade_data['stop_loss'] = trailing_stop
                    logger.info(f"Trailing stop updated for trade {trade_id}: {trailing_stop}")
                elif position_type == "short" and trailing_stop < trade_data['stop_loss']:
                    trade_data['stop_loss'] = trailing_stop
                    logger.info(f"Trailing stop updated for trade {trade_id}: {trailing_stop}")
            
            return trade
        
        except Exception as e:
            logger.error(f"Error updating trade: {e}", exc_info=True)
            return None
    
    def close_trade(self, trade_id, current_price, reason="manual"):
        """
        Close a tracked trade
        
        Args:
            trade_id: Unique identifier for the trade
            current_price: Current price of the asset
            reason: Reason for closing the trade
            
        Returns:
            dict: Closed trade data
        """
        try:
            # Check if trade exists
            if trade_id not in self.active_trades:
                logger.warning(f"Trade {trade_id} not found in active trades")
                return None
            
            # Get trade data
            trade = self.active_trades[trade_id]
            trade_data = trade['trade_data']
            
            # Update current price
            trade['current_price'] = current_price
            
            # Close the trade
            trade['status'] = "closed"
            trade['close_reason'] = reason
            trade['close_time'] = datetime.now()
            
            # Calculate profit/loss
            if trade_data['signal'] > 0:  # Long position
                trade['profit_loss'] = (current_price - trade_data['entry_price']) * trade_data['position_size_units']
                trade['profit_loss_percentage'] = ((current_price / trade_data['entry_price']) - 1) * 100
            else:  # Short position
                trade['profit_loss'] = (trade_data['entry_price'] - current_price) * trade_data['position_size_units']
                trade['profit_loss_percentage'] = ((trade_data['entry_price'] / current_price) - 1) * 100
            
            logger.info(f"Trade {trade_id} closed with P/L: ${trade['profit_loss']:.2f} ({trade['profit_loss_percentage']:.2f}%)")
            
            return trade
        
        except Exception as e:
            logger.error(f"Error closing trade: {e}", exc_info=True)
            return None
    
    def get_active_trades(self):
        """
        Get all active trades
        
        Returns:
            dict: Active trades
        """
        return {k: v for k, v in self.active_trades.items() if v['status'] == "open"}
    
    def get_closed_trades(self):
        """
        Get all closed trades
        
        Returns:
            dict: Closed trades
        """
        return {k: v for k, v in self.active_trades.items() if v['status'] == "closed"}
    
    def get_trade(self, trade_id):
        """
        Get a specific trade
        
        Args:
            trade_id: Unique identifier for the trade
            
        Returns:
            dict: Trade data
        """
        return self.active_trades.get(trade_id)
    
    def update_capital(self, new_capital):
        """
        Update available capital
        
        Args:
            new_capital: New capital amount
            
        Returns:
            float: Updated capital
        """
        self.capital = new_capital
        logger.info(f"Capital updated to ${new_capital}")
        return self.capital
