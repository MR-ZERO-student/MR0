"""
System Integration Module

This module integrates all components of the cryptocurrency analysis and alert system
into a cohesive application with scheduling and error handling.
"""

import os
import logging
import asyncio
import time
from datetime import datetime, timedelta
import json
import traceback
import threading
import queue
import signal
import sys
from typing import Dict, List, Any, Optional, Tuple

# Import local modules
from data_collection.dexscreener import DexScreenerAPI
from data_collection.social_media import SocialMediaMonitor
from data_collection.blockchain import BlockchainAnalyzer
from technical_analysis.indicators import TechnicalAnalysis, MultiTimeframeAnalysis
from technical_analysis.price_data import PriceDataFetcher
from technical_analysis.signal_generator import SignalGenerator
from risk_management.position_sizing import PositionSizer
from risk_management.risk_calculator import RiskManager
from risk_management.trade_manager import TradeManager
from telegram_integration.bot import TelegramBot
from telegram_integration.webhook import WebhookService, AlertSender
from telegram_integration.message_formatter import MessageFormatter
from visual_presentation.chart_generator import ChartGenerator
from visual_presentation.alert_template import AlertTemplate

# Import configuration
import config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("crypto_alert_bot.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class CryptoAlertSystem:
    """Main class for integrating all components of the cryptocurrency alert system"""
    
    def __init__(self):
        """Initialize the cryptocurrency alert system"""
        logger.info("Initializing Cryptocurrency Alert System")
        
        # Initialize components
        self._init_data_collection()
        self._init_technical_analysis()
        self._init_risk_management()
        self._init_telegram_integration()
        self._init_visual_presentation()
        
        # Initialize task queues
        self.analysis_queue = queue.Queue()
        self.alert_queue = queue.Queue()
        
        # Initialize scheduling
        self.scan_interval = config.SCAN_INTERVAL_MINUTES
        self.reminder_interval = config.REMINDER_CHECK_MINUTES
        self.running = False
        self.scheduler_thread = None
        self.worker_threads = []
        
        # Initialize signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        logger.info("Cryptocurrency Alert System initialized")
    
    def _init_data_collection(self):
        """Initialize data collection components"""
        logger.info("Initializing data collection components")
        
        self.dex_api = DexScreenerAPI()
        self.social_monitor = SocialMediaMonitor()
        self.blockchain_analyzer = BlockchainAnalyzer()
        
        logger.info("Data collection components initialized")
    
    def _init_technical_analysis(self):
        """Initialize technical analysis components"""
        logger.info("Initializing technical analysis components")
        
        self.price_fetcher = PriceDataFetcher()
        self.technical_analyzer = TechnicalAnalysis()
        self.mtf_analyzer = MultiTimeframeAnalysis()
        self.signal_generator = SignalGenerator()
        
        logger.info("Technical analysis components initialized")
    
    def _init_risk_management(self):
        """Initialize risk management components"""
        logger.info("Initializing risk management components")
        
        self.position_sizer = PositionSizer()
        self.risk_manager = RiskManager()
        self.trade_manager = TradeManager(capital=config.TRADING_CAPITAL)
        
        logger.info("Risk management components initialized")
    
    def _init_telegram_integration(self):
        """Initialize Telegram integration components"""
        logger.info("Initializing Telegram integration components")
        
        self.telegram_bot = TelegramBot()
        self.webhook_service = WebhookService(self.telegram_bot)
        self.alert_sender = AlertSender()
        self.message_formatter = MessageFormatter()
        
        logger.info("Telegram integration components initialized")
    
    def _init_visual_presentation(self):
        """Initialize visual presentation components"""
        logger.info("Initializing visual presentation components")
        
        self.chart_generator = ChartGenerator()
        self.alert_template = AlertTemplate()
        
        logger.info("Visual presentation components initialized")
    
    async def start(self):
        """Start the cryptocurrency alert system"""
        try:
            logger.info("Starting Cryptocurrency Alert System")
            
            # Start Telegram bot
            await self.telegram_bot.start()
            
            # Start webhook service
            await self.webhook_service.start()
            
            # Start scheduler
            self.running = True
            self.scheduler_thread = threading.Thread(target=self._scheduler_loop)
            self.scheduler_thread.daemon = True
            self.scheduler_thread.start()
            
            # Start worker threads
            self._start_workers()
            
            logger.info("Cryptocurrency Alert System started")
            
            # Send startup message
            await self.telegram_bot.send_text_message(
                "🚀 Cryptocurrency Alert System is now online and monitoring the market!"
            )
            
            return True
        
        except Exception as e:
            logger.error(f"Error starting Cryptocurrency Alert System: {e}", exc_info=True)
            return False
    
    async def stop(self):
        """Stop the cryptocurrency alert system"""
        try:
            logger.info("Stopping Cryptocurrency Alert System")
            
            # Stop scheduler
            self.running = False
            if self.scheduler_thread:
                self.scheduler_thread.join(timeout=5)
            
            # Stop worker threads
            self._stop_workers()
            
            # Stop webhook service
            await self.webhook_service.stop()
            
            # Stop Telegram bot
            await self.telegram_bot.stop()
            
            logger.info("Cryptocurrency Alert System stopped")
            
            return True
        
        except Exception as e:
            logger.error(f"Error stopping Cryptocurrency Alert System: {e}", exc_info=True)
            return False
    
    def _scheduler_loop(self):
        """Main scheduler loop for periodic tasks"""
        logger.info("Scheduler loop started")
        
        last_scan_time = datetime.now() - timedelta(minutes=self.scan_interval)
        last_reminder_time = datetime.now() - timedelta(minutes=self.reminder_interval)
        
        while self.running:
            try:
                current_time = datetime.now()
                
                # Check if it's time for a market scan
                if (current_time - last_scan_time).total_seconds() / 60 >= self.scan_interval:
                    logger.info("Scheduling market scan")
                    self._schedule_market_scan()
                    last_scan_time = current_time
                
                # Check if it's time to check reminders
                if (current_time - last_reminder_time).total_seconds() / 60 >= self.reminder_interval:
                    logger.info("Scheduling reminder check")
                    self._schedule_reminder_check()
                    last_reminder_time = current_time
                
                # Sleep for a short time
                time.sleep(10)
            
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}", exc_info=True)
                time.sleep(60)  # Sleep longer on error
        
        logger.info("Scheduler loop stopped")
    
    def _schedule_market_scan(self):
        """Schedule a market scan task"""
        self.analysis_queue.put(("scan_market", {}))
    
    def _schedule_reminder_check(self):
        """Schedule a reminder check task"""
        self.analysis_queue.put(("check_reminders", {}))
    
    def _start_workers(self):
        """Start worker threads for processing tasks"""
        logger.info("Starting worker threads")
        
        # Start analysis worker
        analysis_worker = threading.Thread(target=self._analysis_worker)
        analysis_worker.daemon = True
        analysis_worker.start()
        self.worker_threads.append(analysis_worker)
        
        # Start alert worker
        alert_worker = threading.Thread(target=self._alert_worker)
        alert_worker.daemon = True
        alert_worker.start()
        self.worker_threads.append(alert_worker)
        
        logger.info("Worker threads started")
    
    def _stop_workers(self):
        """Stop worker threads"""
        logger.info("Stopping worker threads")
        
        # Signal workers to stop
        self.analysis_queue.put(("stop", {}))
        self.alert_queue.put(("stop", {}))
        
        # Wait for workers to finish
        for thread in self.worker_threads:
            thread.join(timeout=5)
        
        logger.info("Worker threads stopped")
    
    def _analysis_worker(self):
        """Worker thread for processing analysis tasks"""
        logger.info("Analysis worker started")
        
        while self.running:
            try:
                # Get task from queue
                task_type, task_data = self.analysis_queue.get(timeout=1)
                
                # Check if stop signal
                if task_type == "stop":
                    logger.info("Analysis worker received stop signal")
                    break
                
                # Process task
                if task_type == "scan_market":
                    self._process_market_scan()
                elif task_type == "check_reminders":
                    self._process_reminder_check()
                elif task_type == "analyze_token":
                    self._process_token_analysis(task_data)
                else:
                    logger.warning(f"Unknown task type: {task_type}")
                
                # Mark task as done
                self.analysis_queue.task_done()
            
            except queue.Empty:
                # Queue timeout, continue loop
                pass
            
            except Exception as e:
                logger.error(f"Error in analysis worker: {e}", exc_info=True)
                time.sleep(5)  # Sleep on error
        
        logger.info("Analysis worker stopped")
    
    def _alert_worker(self):
        """Worker thread for processing alert tasks"""
        logger.info("Alert worker started")
        
        while self.running:
            try:
                # Get task from queue
                task_type, task_data = self.alert_queue.get(timeout=1)
                
                # Check if stop signal
                if task_type == "stop":
                    logger.info("Alert worker received stop signal")
                    break
                
                # Process task
                if task_type == "send_alert":
                    self._process_send_alert(task_data)
                elif task_type == "send_reminder":
                    self._process_send_reminder(task_data)
                else:
                    logger.warning(f"Unknown task type: {task_type}")
                
                # Mark task as done
                self.alert_queue.task_done()
            
            except queue.Empty:
                # Queue timeout, continue loop
                pass
            
            except Exception as e:
                logger.error(f"Error in alert worker: {e}", exc_info=True)
                time.sleep(5)  # Sleep on error
        
        logger.info("Alert worker stopped")
    
    def _process_market_scan(self):
        """Process a market scan task"""
        logger.info("Processing market scan")
        
        try:
            # Get trending tokens from DexScreener
            trending_tokens = asyncio.run(self.dex_api.get_trending_tokens())
            
            # Get trending tokens from social media
            social_trending = asyncio.run(self.social_monitor.get_trending_coins())
            
            # Combine and prioritize tokens
            all_tokens = self._combine_trending_tokens(trending_tokens, social_trending)
            
            # Schedule analysis for each token
            for token in all_tokens[:config.MAX_TOKENS_TO_ANALYZE]:
                self.analysis_queue.put(("analyze_token", token))
            
            logger.info(f"Scheduled analysis for {len(all_tokens[:config.MAX_TOKENS_TO_ANALYZE])} tokens")
        
        except Exception as e:
            logger.error(f"Error processing market scan: {e}", exc_info=True)
    
    def _combine_trending_tokens(self, dex_tokens, social_tokens):
        """Combine and prioritize trending tokens from different sources"""
        # Create a dictionary to store combined token data
        combined = {}
        
        # Add DexScreener tokens
        for token in dex_tokens:
            token_id = token.get('address', '').lower()
            if token_id:
                combined[token_id] = {
                    'address': token_id,
                    'symbol': token.get('symbol', 'Unknown'),
                    'name': token.get('name', 'Unknown'),
                    'chain': token.get('chain', 'ethereum'),
                    'dex_score': token.get('score', 0),
                    'social_score': 0,
                    'total_score': token.get('score', 0)
                }
        
        # Add social media tokens
        for token in social_tokens:
            token_id = token.get('address', '').lower()
            if token_id:
                if token_id in combined:
                    # Update existing token
                    combined[token_id]['social_score'] = token.get('score', 0)
                    combined[token_id]['total_score'] += token.get('score', 0)
                else:
                    # Add new token
                    combined[token_id] = {
                        'address': token_id,
                        'symbol': token.get('symbol', 'Unknown'),
                        'name': token.get('name', 'Unknown'),
                        'chain': token.get('chain', 'ethereum'),
                        'dex_score': 0,
                        'social_score': token.get('score', 0),
                        'total_score': token.get('score', 0)
                    }
        
        # Convert to list and sort by total score
        result = list(combined.values())
        result.sort(key=lambda x: x['total_score'], reverse=True)
        
        return result
    
    def _process_token_analysis(self, token_data):
        """Process token analysis task"""
        token_address = token_data.get('address')
        chain = token_data.get('chain', 'ethereum')
        symbol = token_data.get('symbol', 'Unknown')
        
        logger.info(f"Analyzing token: {symbol} ({token_address}) on {chain}")
        
        try:
            # Get token price data
            price_data = asyncio.run(self.price_fetcher.fetch_token_price_data(token_address, chain))
            
            if not price_data:
                logger.warning(f"No price data available for {symbol}")
                return
            
            # Generate technical analysis signal
            signal = asyncio.run(self.signal_generator.generate_token_signal(token_address, chain))
            
            if not signal:
                logger.warning(f"No signal generated for {symbol}")
                return
            
            # Get blockchain data
            blockchain_data = asyncio.run(self.blockchain_analyzer.analyze_token(token_address, chain))
            
            # Get social media data
            social_data = asyncio.run(self.social_monitor.analyze_coin(symbol))
            
            # Calculate risk score
            risk_data = self._calculate_risk_score(signal, blockchain_data, social_data)
            
            # Generate trade recommendation
            trade_rec = self.trade_manager.process_signal({
                **signal,
                **risk_data,
                'blockchain_data': blockchain_data,
                'social_data': social_data
            })
            
            # Check if signal is strong enough to send alert
            if self._should_send_alert(signal, risk_data, trade_rec):
                # Prepare alert data
                alert_data = self._prepare_alert_data(signal, risk_data, trade_rec, blockchain_data, social_data)
                
                # Generate chart
                chart_data = {
                    'ohlcv': price_data.get(60, next(iter(price_data.values()))),
                    'indicators': signal.get('indicators', {})
                }
                
                # Schedule alert
                self.alert_queue.put(("send_alert", {
                    'alert_data': alert_data,
                    'chart_data': chart_data
                }))
                
                logger.info(f"Scheduled alert for {symbol}")
            else:
                logger.info(f"Signal for {symbol} not strong enough for alert")
        
        except Exception as e:
            logger.error(f"Error analyzing token {symbol}: {e}", exc_info=True)
    
    def _calculate_risk_score(self, signal, blockchain_data, social_data):
        """Calculate comprehensive risk score for a token"""
        try:
            # Extract relevant data
            holders_count = blockchain_data.get('holders_count', 0)
            holder_distribution = blockchain_data.get('holder_distribution', 0)
            contract_verified = blockchain_data.get('contract_verified', False)
            token_age_days = blockchain_data.get('token_age_days', 0)
            liquidity = blockchain_data.get('liquidity', 0)
            
            social_sentiment = social_data.get('sentiment_score', 0)
            social_volume = social_data.get('mention_count', 0)
            
            # Calculate component scores (0-100 scale)
            
            # Holder score (more holders and better distribution is better)
            holder_score = min(100, (holders_count / 1000) * 50 + holder_distribution * 50)
            
            # Contract score (verified contracts and older tokens are better)
            contract_score = (100 if contract_verified else 0) * 0.5 + min(100, token_age_days * 5) * 0.5
            
            # Liquidity score (more liquidity is better)
            liquidity_score = min(100, (liquidity / 100000) * 100)
            
            # Social score (positive sentiment and high volume is better)
            social_score = (social_sentiment + 1) * 50 + min(100, (social_volume / 100) * 50)
            
            # Technical score (from signal)
            technical_score = signal.get('confidence', 0)
            
            # Calculate overall risk score (0-100 scale, higher is better/less risky)
            weights = {
                'holder': 0.2,
                'contract': 0.2,
                'liquidity': 0.2,
                'social': 0.2,
                'technical': 0.2
            }
            
            risk_score = (
                holder_score * weights['holder'] +
                contract_score * weights['contract'] +
                liquidity_score * weights['liquidity'] +
                social_score * weights['social'] +
                technical_score * weights['technical']
            )
            
            # Determine risk level
            if risk_score >= 80:
                risk_level = "Low"
            elif risk_score >= 60:
                risk_level = "Medium"
            elif risk_score >= 40:
                risk_level = "High"
            else:
                risk_level = "Very High"
            
            return {
                'risk_score': risk_score,
                'risk_level': risk_level,
                'holder_score': holder_score,
                'contract_score': contract_score,
                'liquidity_score': liquidity_score,
                'social_score': social_score,
                'technical_score': technical_score
            }
        
        except Exception as e:
            logger.error(f"Error calculating risk score: {e}", exc_info=True)
            return {
                'risk_score': 0,
                'risk_level': "Unknown"
            }
    
    def _should_send_alert(self, signal, risk_data, trade_rec):
        """Determine if signal is strong enough to send alert"""
        # Check signal strength
        signal_strength = signal.get('confidence', 0)
        
        # Check risk score
        risk_score = risk_data.get('risk_score', 0)
        
        # Check trade recommendation
        recommendation = trade_rec.get('recommendation', 'Skip trade')
        
        # Determine if alert should be sent
        if signal.get('signal', 0) == 0:
            # Don't send alerts for neutral signals
            return False
        
        if signal_strength < config.MIN_SIGNAL_STRENGTH:
            # Signal not strong enough
            return False
        
        if risk_score < config.MIN_RISK_SCORE:
            # Risk too high
            return False
        
        if recommendation == 'Skip trade':
            # Trade not recommended
            return False
        
        # All checks passed
        return True
    
    def _prepare_alert_data(self, signal, risk_data, trade_rec, blockchain_data, social_data):
        """Prepare data for alert"""
        # Combine all data into a single alert object
        alert_data = {
            **signal,
            **risk_data,
            'blockchain_data': blockchain_data,
            'social_data': social_data,
            'trade_rec': trade_rec,
            'timestamp': datetime.now()
        }
        
        return alert_data
    
    def _process_send_alert(self, data):
        """Process send alert task"""
        alert_data = data.get('alert_data', {})
        chart_data = data.get('chart_data', {})
        
        symbol = alert_data.get('symbol', 'Unknown')
        logger.info(f"Sending alert for {symbol}")
        
        try:
            # Generate chart image
            chart_path = None
            if chart_data:
                chart_path = self.chart_generator.generate_candlestick_chart(
                    chart_data.get('ohlcv'),
                    chart_data.get('indicators'),
                    f"/tmp/{symbol}_chart.png"
                )
                alert_data['chart_path'] = chart_path
            
            # Generate alert image
            alert_image_path = self.alert_template.create_buy_sell_alert(
                alert_data,
                chart_data,
                f"/tmp/{symbol}_alert.png"
            )
            
            # Generate coin rating image
            rating_data = {
                'symbol': symbol,
                'overall_score': alert_data.get('risk_score', 0),
                'liquidity': alert_data.get('liquidity_score', 0),
                'volume': alert_data.get('blockchain_data', {}).get('volume_score', 0),
                'holders': alert_data.get('holder_score', 0),
                'social_hype': alert_data.get('social_score', 0),
                'technical_score': alert_data.get('technical_score', 0),
                'risk_score': alert_data.get('risk_score', 0)
            }
            
            rating_image_path = self.alert_template.create_coin_rating_card(
                rating_data,
                f"/tmp/{symbol}_rating.png"
            )
            
            # Format alert message
            message = self.message_formatter.format_alert_message(alert_data)
            
            # Send alert via webhook
            asyncio.run(self.telegram_bot.send_alert({
                **alert_data,
                'formatted_message': message,
                'alert_image_path': alert_image_path,
                'rating_image_path': rating_image_path
            }))
            
            logger.info(f"Alert sent for {symbol}")
        
        except Exception as e:
            logger.error(f"Error sending alert for {symbol}: {e}", exc_info=True)
    
    def _process_reminder_check(self):
        """Process reminder check task"""
        logger.info("Processing reminder check")
        
        try:
            # Get current prices for tokens with active reminders
            current_prices = self._get_current_prices_for_reminders()
            
            # Check reminders
            triggered = asyncio.run(self.telegram_bot.check_reminders(current_prices))
            
            logger.info(f"Checked reminders, triggered {len(triggered)}")
        
        except Exception as e:
            logger.error(f"Error processing reminder check: {e}", exc_info=True)
    
    def _get_current_prices_for_reminders(self):
        """Get current prices for tokens with active reminders"""
        # This would fetch current prices for tokens with active reminders
        # For now, return an empty dictionary
        return {}
    
    def _process_send_reminder(self, reminder_data):
        """Process send reminder task"""
        symbol = reminder_data.get('symbol', 'Unknown')
        logger.info(f"Sending reminder for {symbol}")
        
        try:
            # Format reminder message
            message = self.message_formatter.format_reminder_message(reminder_data)
            
            # Send reminder via webhook
            asyncio.run(self.telegram_bot.send_reminder({
                **reminder_data,
                'formatted_message': message
            }))
            
            logger.info(f"Reminder sent for {symbol}")
        
        except Exception as e:
            logger.error(f"Error sending reminder for {symbol}: {e}", exc_info=True)
    
    def _signal_handler(self, sig, frame):
        """Handle termination signals"""
        logger.info(f"Received signal {sig}, shutting down")
        asyncio.run(self.stop())
        sys.exit(0)


async def main():
    """Main entry point for the application"""
    try:
        # Create and start the system
        system = CryptoAlertSystem()
        await system.start()
        
        # Keep the main thread running
        while True:
            await asyncio.sleep(1)
    
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down")
        await system.stop()
    
    except Exception as e:
        logger.error(f"Unhandled exception: {e}", exc_info=True)
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
