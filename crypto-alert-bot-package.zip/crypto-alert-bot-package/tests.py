"""
Test Module

This module contains test cases for the cryptocurrency analysis and alert system.
"""

import logging
import unittest
import asyncio
import os
import sys
import json
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Add project root to path
sys.path.append('/home/ubuntu/crypto_alert_bot')

# Import local modules
from data_collection.dexscreener import DexScreenerAPI
from data_collection.social_media import SocialMediaMonitor
from data_collection.blockchain import BlockchainAnalyzer
from technical_analysis.indicators import TechnicalAnalysis
from technical_analysis.price_data import PriceDataFetcher
from technical_analysis.signal_generator import SignalGenerator
from risk_management.position_sizing import PositionSizer
from risk_management.risk_calculator import RiskManager
from risk_management.trade_manager import TradeManager
from telegram_integration.message_formatter import MessageFormatter
from visual_presentation.chart_generator import ChartGenerator
from visual_presentation.alert_template import AlertTemplate
from system_integration import CryptoAlertSystem
from scheduler import TaskScheduler, BackgroundTaskManager
from error_handling import ErrorHandler, SafeExecutor

# Import configuration
import config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("test.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class TestDataCollection(unittest.TestCase):
    """Test cases for data collection modules"""
    
    def setUp(self):
        """Set up test environment"""
        self.dex_api = DexScreenerAPI()
        self.social_monitor = SocialMediaMonitor()
        self.blockchain_analyzer = BlockchainAnalyzer()
    
    async def test_dexscreener_api(self):
        """Test DexScreener API"""
        # Test getting trending tokens
        trending_tokens = await self.dex_api.get_trending_tokens()
        self.assertIsNotNone(trending_tokens)
        self.assertIsInstance(trending_tokens, list)
        
        if trending_tokens:
            # Test getting token details
            token = trending_tokens[0]
            token_address = token.get('address')
            chain = token.get('chain', 'ethereum')
            
            token_details = await self.dex_api.get_token_details(token_address, chain)
            self.assertIsNotNone(token_details)
            self.assertIsInstance(token_details, dict)
    
    async def test_social_media_monitor(self):
        """Test social media monitor"""
        # Test getting trending coins
        trending_coins = await self.social_monitor.get_trending_coins()
        self.assertIsNotNone(trending_coins)
        self.assertIsInstance(trending_coins, list)
        
        # Test analyzing a coin
        coin_analysis = await self.social_monitor.analyze_coin("BTC")
        self.assertIsNotNone(coin_analysis)
        self.assertIsInstance(coin_analysis, dict)
    
    async def test_blockchain_analyzer(self):
        """Test blockchain analyzer"""
        # Test analyzing a token
        # Use Ethereum WETH as a test token
        token_address = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
        chain = "ethereum"
        
        token_analysis = await self.blockchain_analyzer.analyze_token(token_address, chain)
        self.assertIsNotNone(token_analysis)
        self.assertIsInstance(token_analysis, dict)


class TestTechnicalAnalysis(unittest.TestCase):
    """Test cases for technical analysis modules"""
    
    def setUp(self):
        """Set up test environment"""
        self.price_fetcher = PriceDataFetcher()
        self.technical_analyzer = TechnicalAnalysis()
        self.signal_generator = SignalGenerator()
    
    def test_technical_indicators(self):
        """Test technical indicators"""
        # Create sample price data
        dates = pd.date_range(start='2023-01-01', periods=100, freq='1H')
        prices = np.random.normal(100, 10, 100).cumsum() + 1000
        
        # Create DataFrame
        df = pd.DataFrame({
            'timestamp': dates,
            'open': prices,
            'high': prices * 1.01,
            'low': prices * 0.99,
            'close': prices,
            'volume': np.random.normal(1000, 100, 100)
        })
        
        # Calculate indicators
        indicators = self.technical_analyzer.calculate_indicators(df)
        
        # Check if indicators were calculated
        self.assertIn('ma_fast', indicators)
        self.assertIn('ma_slow', indicators)
        self.assertIn('gaussian_upper', indicators)
        self.assertIn('gaussian_lower', indicators)
        self.assertIn('macd_line', indicators)
        self.assertIn('signal_line', indicators)
        self.assertIn('histogram', indicators)
        self.assertIn('stoch_k', indicators)
        self.assertIn('stoch_d', indicators)
        self.assertIn('atr', indicators)
    
    async def test_price_data_fetcher(self):
        """Test price data fetcher"""
        # Use Ethereum WETH as a test token
        token_address = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
        chain = "ethereum"
        
        price_data = await self.price_fetcher.fetch_token_price_data(token_address, chain)
        self.assertIsNotNone(price_data)
        self.assertIsInstance(price_data, dict)
        
        # Check if at least one timeframe is available
        self.assertGreater(len(price_data), 0)
        
        # Check first timeframe
        first_timeframe = next(iter(price_data.values()))
        self.assertIsInstance(first_timeframe, pd.DataFrame)
        self.assertIn('timestamp', first_timeframe.columns)
        self.assertIn('open', first_timeframe.columns)
        self.assertIn('high', first_timeframe.columns)
        self.assertIn('low', first_timeframe.columns)
        self.assertIn('close', first_timeframe.columns)
        self.assertIn('volume', first_timeframe.columns)
    
    async def test_signal_generator(self):
        """Test signal generator"""
        # Use Ethereum WETH as a test token
        token_address = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
        chain = "ethereum"
        
        signal = await self.signal_generator.generate_token_signal(token_address, chain)
        self.assertIsNotNone(signal)
        self.assertIsInstance(signal, dict)
        
        # Check if signal contains required fields
        self.assertIn('signal', signal)
        self.assertIn('confidence', signal)
        self.assertIn('trend_strength', signal)
        self.assertIn('price', signal)
        self.assertIn('symbol', signal)


class TestRiskManagement(unittest.TestCase):
    """Test cases for risk management modules"""
    
    def setUp(self):
        """Set up test environment"""
        self.position_sizer = PositionSizer()
        self.risk_manager = RiskManager()
        self.trade_manager = TradeManager(capital=10000)
    
    def test_position_sizing(self):
        """Test position sizing"""
        # Test calculating position size
        position_size = self.position_sizer.calculate_position_size(
            capital=10000,
            risk_percentage=1,
            entry_price=100,
            stop_loss=95
        )
        
        self.assertIsNotNone(position_size)
        self.assertGreater(position_size, 0)
        
        # Test with different risk percentages
        position_size_2 = self.position_sizer.calculate_position_size(
            capital=10000,
            risk_percentage=2,
            entry_price=100,
            stop_loss=95
        )
        
        self.assertGreater(position_size_2, position_size)
    
    def test_risk_calculator(self):
        """Test risk calculator"""
        # Test calculating stop loss
        stop_loss = self.risk_manager.calculate_stop_loss(
            entry_price=100,
            direction=1,  # Long
            atr=2,
            multiplier=2
        )
        
        self.assertIsNotNone(stop_loss)
        self.assertLess(stop_loss, 100)
        
        # Test calculating take profit
        take_profit = self.risk_manager.calculate_take_profit(
            entry_price=100,
            stop_loss=96,
            direction=1,  # Long
            risk_reward_ratio=2
        )
        
        self.assertIsNotNone(take_profit)
        self.assertGreater(take_profit, 100)
    
    def test_trade_manager(self):
        """Test trade manager"""
        # Test processing a signal
        signal = {
            'signal': 1,  # Buy
            'confidence': 80,
            'trend_strength': 70,
            'price': 100,
            'symbol': 'TEST',
            'indicators': {
                'atr': [2] * 100
            }
        }
        
        trade_rec = self.trade_manager.process_signal(signal)
        self.assertIsNotNone(trade_rec)
        self.assertIsInstance(trade_rec, dict)
        
        # Check if trade recommendation contains required fields
        self.assertIn('recommendation', trade_rec)
        self.assertIn('position_size', trade_rec)
        self.assertIn('entry_price', trade_rec)
        self.assertIn('stop_loss', trade_rec)
        self.assertIn('take_profit', trade_rec)
        self.assertIn('risk_amount', trade_rec)
        self.assertIn('potential_profit', trade_rec)
        self.assertIn('risk_reward_ratio', trade_rec)


class TestVisualPresentation(unittest.TestCase):
    """Test cases for visual presentation modules"""
    
    def setUp(self):
        """Set up test environment"""
        self.chart_generator = ChartGenerator()
        self.alert_template = AlertTemplate()
    
    def test_chart_generator(self):
        """Test chart generator"""
        # Create sample price data
        dates = pd.date_range(start='2023-01-01', periods=100, freq='1H')
        prices = np.random.normal(100, 10, 100).cumsum() + 1000
        
        # Create DataFrame
        df = pd.DataFrame({
            'timestamp': dates,
            'open': prices,
            'high': prices * 1.01,
            'low': prices * 0.99,
            'close': prices,
            'volume': np.random.normal(1000, 100, 100)
        })
        
        # Create indicators
        indicators = {
            'symbol': 'TEST',
            'timeframe': '1h',
            'ma_fast': prices * 0.99,
            'ma_slow': prices * 0.98,
            'gaussian_upper': prices * 1.02,
            'gaussian_lower': prices * 0.98,
            'gaussian_middle': prices,
            'macd_line': np.random.normal(0, 1, 100),
            'signal_line': np.random.normal(0, 1, 100),
            'histogram': np.random.normal(0, 1, 100),
            'stoch_k': np.random.normal(50, 20, 100),
            'stoch_d': np.random.normal(50, 15, 100),
            'atr': np.random.normal(10, 2, 100),
            'signals': {
                'buy': [10, 30, 50, 70, 90],
                'sell': [20, 40, 60, 80]
            }
        }
        
        # Generate chart
        chart_path = self.chart_generator.generate_candlestick_chart(
            df,
            indicators,
            "/tmp/test_chart.png"
        )
        
        self.assertIsNotNone(chart_path)
        self.assertTrue(os.path.exists(chart_path))
    
    def test_alert_template(self):
        """Test alert template"""
        # Create sample alert data
        alert_data = {
            'symbol': 'TEST',
            'signal': 1,  # Buy
            'price': 1000,
            'confidence': 80,
            'trend_strength': 70,
            'stop_loss': 950,
            'take_profit': 1100,
            'risk_reward_ratio': 2.0,
            'risk_score': 75,
            'risk_level': 'Medium'
        }
        
        # Generate alert image
        alert_image_path = self.alert_template.create_buy_sell_alert(
            alert_data,
            None,
            "/tmp/test_alert.png"
        )
        
        self.assertIsNotNone(alert_image_path)
        self.assertTrue(os.path.exists(alert_image_path))
        
        # Create sample rating data
        rating_data = {
            'symbol': 'TEST',
            'overall_score': 75,
            'liquidity': 80,
            'volume': 70,
            'holders': 65,
            'social_hype': 85,
            'technical_score': 75,
            'risk_score': 75
        }
        
        # Generate rating card
        rating_image_path = self.alert_template.create_coin_rating_card(
            rating_data,
            "/tmp/test_rating.png"
        )
        
        self.assertIsNotNone(rating_image_path)
        self.assertTrue(os.path.exists(rating_image_path))


class TestSystemIntegration(unittest.TestCase):
    """Test cases for system integration"""
    
    def setUp(self):
        """Set up test environment"""
        self.system = CryptoAlertSystem()
    
    async def test_system_initialization(self):
        """Test system initialization"""
        # Check if all components are initialized
        self.assertIsNotNone(self.system.dex_api)
        self.assertIsNotNone(self.system.social_monitor)
        self.assertIsNotNone(self.system.blockchain_analyzer)
        self.assertIsNotNone(self.system.price_fetcher)
        self.assertIsNotNone(self.system.technical_analyzer)
        self.assertIsNotNone(self.system.mtf_analyzer)
        self.assertIsNotNone(self.system.signal_generator)
        self.assertIsNotNone(self.system.position_sizer)
        self.assertIsNotNone(self.system.risk_manager)
        self.assertIsNotNone(self.system.trade_manager)
        self.assertIsNotNone(self.system.telegram_bot)
        self.assertIsNotNone(self.system.webhook_service)
        self.assertIsNotNone(self.system.alert_sender)
        self.assertIsNotNone(self.system.message_formatter)
        self.assertIsNotNone(self.system.chart_generator)
        self.assertIsNotNone(self.system.alert_template)
    
    async def test_system_start_stop(self):
        """Test system start and stop"""
        # Start system
        start_result = await self.system.start()
        self.assertTrue(start_result)
        self.assertTrue(self.system.running)
        
        # Stop system
        stop_result = await self.system.stop()
        self.assertTrue(stop_result)
        self.assertFalse(self.system.running)


class TestScheduler(unittest.TestCase):
    """Test cases for scheduler"""
    
    def setUp(self):
        """Set up test environment"""
        self.task_scheduler = TaskScheduler()
        self.background_task_manager = BackgroundTaskManager()
    
    def test_task_scheduler(self):
        """Test task scheduler"""
        # Define a test task
        def test_task():
            logger.info("Test task executed")
        
        # Add task
        result = self.task_scheduler.add_task(
            task_id="test_task",
            interval_minutes=5,
            task_func=test_task,
            initial_delay_minutes=0
        )
        
        self.assertTrue(result)
        self.assertIn("test_task", self.task_scheduler.tasks)
        
        # Start scheduler
        start_result = self.task_scheduler.start()
        self.assertTrue(start_result)
        self.assertTrue(self.task_scheduler.running)
        
        # Wait for a short time
        time.sleep(2)
        
        # Stop scheduler
        stop_result = self.task_scheduler.stop()
        self.assertTrue(stop_result)
        self.assertFalse(self.task_scheduler.running)
    
    def test_background_task_manager(self):
        """Test background task manager"""
        # Define a test task
        def test_task(arg1, arg2=None):
            logger.info(f"Test task executed with {arg1} and {arg2}")
            return arg1 + (arg2 or 0)
        
        # Start manager
        start_result = self.background_task_manager.start()
        self.assertTrue(start_result)
        self.assertTrue(self.background_task_manager.running)
        
        # Submit task
        task_id = self.background_task_manager.submit_task(
            task_func=test_task,
            task_args=(1,),
            task_kwargs={'arg2': 2},
            task_id="test_task"
        )
        
        self.assertIsNotNone(task_id)
        self.assertEqual(task_id, "test_task")
        
        # Wait for a short time
        time.sleep(2)
        
        # Stop manager
        stop_result = self.background_task_manager.stop()
        self.assertTrue(stop_result)
        self.assertFalse(self.background_task_manager.running)


class TestErrorHandling(unittest.TestCase):
    """Test cases for error handling"""
    
    def setUp(self):
        """Set up test environment"""
        self.error_handler = ErrorHandler()
        self.safe_executor = SafeExecutor(self.error_handler)
    
    def test_error_handler(self):
        """Test error handler"""
        # Start error handler
        start_result = self.error_handler.start()
        self.assertTrue(start_result)
        self.assertTrue(self.error_handler.running)
        
        # Handle an error
        result = self.error_handler.handle_error(
            error="Test error",
            error_type="error",
            component="test",
            context={"test": True}
        )
        
        self.assertTrue(result)
        self.assertEqual(self.error_handler.error_counts['error'], 1)
        self.assertEqual(self.error_handler.error_categories['test'], 1)
        
        # Stop error handler
        stop_result = self.error_handler.stop()
        self.assertTrue(stop_result)
        self.assertFalse(self.error_handler.running)
    
    def test_safe_executor(self):
        """Test safe executor"""
        # Define a test function
        def test_function(arg1, arg2=None):
            return arg1 + (arg2 or 0)
        
        # Define a test function that raises an exception
        def test_exception_function():
            raise ValueError("Test exception")
        
        # Execute function
        result, error = self.safe_executor.execute(
            test_function,
            1,
            arg2=2,
            component="test"
        )
        
        self.assertEqual(result, 3)
        self.assertIsNone(error)
        
        # Execute function that raises an exception
        result, error = self.safe_executor.execute(
            test_exception_function,
            component="test"
        )
        
        self.assertIsNone(result)
        self.assertIsInstance(error, ValueError)


def run_tests():
    """Run all tests"""
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test cases
    test_suite.addTest(unittest.makeSuite(TestDataCollection))
    test_suite.addTest(unittest.makeSuite(TestTechnicalAnalysis))
    test_suite.addTest(unittest.makeSuite(TestRiskManagement))
    test_suite.addTest(unittest.makeSuite(TestVisualPresentation))
    test_suite.addTest(unittest.makeSuite(TestSystemIntegration))
    test_suite.addTest(unittest.makeSuite(TestScheduler))
    test_suite.addTest(unittest.makeSuite(TestErrorHandling))
    
    # Run tests
    test_runner = unittest.TextTestRunner(verbosity=2)
    test_result = test_runner.run(test_suite)
    
    # Return test result
    return test_result


if __name__ == "__main__":
    # Run tests
    test_result = run_tests()
    
    # Print summary
    print(f"Tests run: {test_result.testsRun}")
    print(f"Errors: {len(test_result.errors)}")
    print(f"Failures: {len(test_result.failures)}")
    
    # Exit with appropriate code
    sys.exit(len(test_result.errors) + len(test_result.failures))
