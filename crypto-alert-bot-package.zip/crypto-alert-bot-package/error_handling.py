"""
Error Handling Module

This module implements comprehensive error handling and logging for the cryptocurrency alert system.
"""

import logging
import traceback
import sys
import os
import json
from datetime import datetime
import threading
import queue
from typing import Dict, List, Any, Optional, Tuple, Callable

# Import configuration
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

# Configure logging
logger = logging.getLogger(__name__)

class ErrorHandler:
    """Class for handling and logging errors in the cryptocurrency alert system"""
    
    def __init__(self, log_dir='/home/ubuntu/crypto_alert_bot/logs'):
        """
        Initialize the error handler
        
        Args:
            log_dir: Directory for log files
        """
        self.log_dir = log_dir
        
        # Create log directory if it doesn't exist
        os.makedirs(log_dir, exist_ok=True)
        
        # Initialize error queue for background processing
        self.error_queue = queue.Queue()
        self.running = False
        self.worker_thread = None
        
        # Initialize error counters
        self.error_counts = {
            'critical': 0,
            'error': 0,
            'warning': 0,
            'info': 0
        }
        
        # Initialize error categories
        self.error_categories = {
            'data_collection': 0,
            'technical_analysis': 0,
            'risk_management': 0,
            'telegram': 0,
            'visual': 0,
            'system': 0,
            'scheduler': 0,
            'other': 0
        }
        
        logger.info("Error handler initialized")
    
    def start(self):
        """
        Start the error handler
        
        Returns:
            bool: Success or failure
        """
        try:
            if self.running:
                logger.warning("Error handler already running")
                return False
            
            logger.info("Starting error handler")
            
            # Set running flag
            self.running = True
            
            # Start worker thread
            self.worker_thread = threading.Thread(target=self._worker_loop)
            self.worker_thread.daemon = True
            self.worker_thread.start()
            
            logger.info("Error handler started")
            return True
        
        except Exception as e:
            logger.error(f"Error starting error handler: {e}", exc_info=True)
            self.running = False
            return False
    
    def stop(self):
        """
        Stop the error handler
        
        Returns:
            bool: Success or failure
        """
        try:
            if not self.running:
                logger.warning("Error handler not running")
                return False
            
            logger.info("Stopping error handler")
            
            # Clear running flag
            self.running = False
            
            # Signal worker to stop
            self.error_queue.put(None)
            
            # Wait for worker thread to finish
            if self.worker_thread:
                self.worker_thread.join(timeout=5)
            
            logger.info("Error handler stopped")
            return True
        
        except Exception as e:
            logger.error(f"Error stopping error handler: {e}", exc_info=True)
            return False
    
    def handle_error(self, error, error_type='error', component='system', context=None):
        """
        Handle an error
        
        Args:
            error: Exception or error message
            error_type: Error type (critical, error, warning, info)
            component: Component where the error occurred
            context: Additional context information
            
        Returns:
            bool: Success or failure
        """
        try:
            # Create error record
            error_record = {
                'timestamp': datetime.now().isoformat(),
                'type': error_type,
                'component': component,
                'message': str(error),
                'traceback': traceback.format_exc() if isinstance(error, Exception) else None,
                'context': context
            }
            
            # Add to queue for background processing
            self.error_queue.put(error_record)
            
            # Update error counters
            if error_type in self.error_counts:
                self.error_counts[error_type] += 1
            
            # Update error categories
            if component in self.error_categories:
                self.error_categories[component] += 1
            else:
                self.error_categories['other'] += 1
            
            # Log error
            if error_type == 'critical':
                logger.critical(f"{component}: {error}", exc_info=True if isinstance(error, Exception) else False)
            elif error_type == 'error':
                logger.error(f"{component}: {error}", exc_info=True if isinstance(error, Exception) else False)
            elif error_type == 'warning':
                logger.warning(f"{component}: {error}")
            else:
                logger.info(f"{component}: {error}")
            
            return True
        
        except Exception as e:
            logger.error(f"Error handling error: {e}", exc_info=True)
            return False
    
    def _worker_loop(self):
        """Worker loop for processing errors"""
        logger.info("Error handler worker started")
        
        while self.running:
            try:
                # Get error from queue
                error_record = self.error_queue.get(timeout=1)
                
                # Check if stop signal
                if error_record is None:
                    logger.info("Error handler worker received stop signal")
                    break
                
                # Process error
                self._process_error(error_record)
                
                # Mark error as done in queue
                self.error_queue.task_done()
            
            except queue.Empty:
                # Queue timeout, continue loop
                pass
            
            except Exception as e:
                logger.error(f"Error in error handler worker: {e}", exc_info=True)
                time.sleep(5)  # Sleep on error
        
        logger.info("Error handler worker stopped")
    
    def _process_error(self, error_record):
        """
        Process an error record
        
        Args:
            error_record: Error record to process
        """
        try:
            # Write error to log file
            self._write_error_to_log(error_record)
            
            # Check if critical error
            if error_record['type'] == 'critical':
                # Send notification
                self._send_critical_error_notification(error_record)
        
        except Exception as e:
            logger.error(f"Error processing error record: {e}", exc_info=True)
    
    def _write_error_to_log(self, error_record):
        """
        Write error record to log file
        
        Args:
            error_record: Error record to write
        """
        try:
            # Get current date for log file name
            date_str = datetime.now().strftime('%Y-%m-%d')
            log_file = os.path.join(self.log_dir, f"errors_{date_str}.log")
            
            # Write error record to log file
            with open(log_file, 'a') as f:
                f.write(json.dumps(error_record) + '\n')
        
        except Exception as e:
            logger.error(f"Error writing error to log: {e}", exc_info=True)
    
    def _send_critical_error_notification(self, error_record):
        """
        Send notification for critical error
        
        Args:
            error_record: Error record to send notification for
        """
        # This would send a notification for critical errors
        # For now, just log it
        logger.critical(f"CRITICAL ERROR: {error_record['component']}: {error_record['message']}")
    
    def get_error_stats(self):
        """
        Get error statistics
        
        Returns:
            dict: Error statistics
        """
        return {
            'counts': self.error_counts.copy(),
            'categories': self.error_categories.copy(),
            'total': sum(self.error_counts.values())
        }
    
    def clear_error_stats(self):
        """
        Clear error statistics
        
        Returns:
            bool: Success or failure
        """
        try:
            # Reset error counters
            for key in self.error_counts:
                self.error_counts[key] = 0
            
            # Reset error categories
            for key in self.error_categories:
                self.error_categories[key] = 0
            
            logger.info("Error statistics cleared")
            return True
        
        except Exception as e:
            logger.error(f"Error clearing error statistics: {e}", exc_info=True)
            return False


class SafeExecutor:
    """Class for safely executing functions with error handling"""
    
    def __init__(self, error_handler=None):
        """
        Initialize the safe executor
        
        Args:
            error_handler: ErrorHandler instance (optional)
        """
        self.error_handler = error_handler
        
        logger.info("Safe executor initialized")
    
    def execute(self, func, *args, error_type='error', component='system', context=None, **kwargs):
        """
        Safely execute a function with error handling
        
        Args:
            func: Function to execute
            *args: Positional arguments for the function
            error_type: Error type (critical, error, warning, info)
            component: Component where the function is executed
            context: Additional context information
            **kwargs: Keyword arguments for the function
            
        Returns:
            tuple: (result, error)
        """
        try:
            # Execute function
            result = func(*args, **kwargs)
            
            # Return result with no error
            return result, None
        
        except Exception as e:
            # Handle error
            if self.error_handler:
                self.error_handler.handle_error(e, error_type, component, context)
            else:
                logger.error(f"Error executing function: {e}", exc_info=True)
            
            # Return None with error
            return None, e
    
    async def execute_async(self, func, *args, error_type='error', component='system', context=None, **kwargs):
        """
        Safely execute an async function with error handling
        
        Args:
            func: Async function to execute
            *args: Positional arguments for the function
            error_type: Error type (critical, error, warning, info)
            component: Component where the function is executed
            context: Additional context information
            **kwargs: Keyword arguments for the function
            
        Returns:
            tuple: (result, error)
        """
        try:
            # Execute async function
            result = await func(*args, **kwargs)
            
            # Return result with no error
            return result, None
        
        except Exception as e:
            # Handle error
            if self.error_handler:
                self.error_handler.handle_error(e, error_type, component, context)
            else:
                logger.error(f"Error executing async function: {e}", exc_info=True)
            
            # Return None with error
            return None, e


def setup_logging(log_dir='/home/ubuntu/crypto_alert_bot/logs', log_level=logging.INFO):
    """
    Setup logging configuration
    
    Args:
        log_dir: Directory for log files
        log_level: Logging level
        
    Returns:
        bool: Success or failure
    """
    try:
        # Create log directory if it doesn't exist
        os.makedirs(log_dir, exist_ok=True)
        
        # Get current date for log file name
        date_str = datetime.now().strftime('%Y-%m-%d')
        log_file = os.path.join(log_dir, f"crypto_alert_bot_{date_str}.log")
        
        # Configure logging
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        
        # Set log level for specific loggers
        logging.getLogger('urllib3').setLevel(logging.WARNING)
        logging.getLogger('requests').setLevel(logging.WARNING)
        logging.getLogger('telegram').setLevel(logging.WARNING)
        
        logger.info("Logging setup complete")
        return True
    
    except Exception as e:
        print(f"Error setting up logging: {e}")
        traceback.print_exc()
        return False
