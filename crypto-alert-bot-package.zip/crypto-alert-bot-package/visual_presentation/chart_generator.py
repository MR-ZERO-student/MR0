"""
Chart Generator Module

This module creates chart snapshots with technical indicators for cryptocurrency alerts.
"""

import logging
import os
from datetime import datetime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.figure import Figure
import matplotlib.ticker as mticker
from PIL import Image, ImageDraw, ImageFont

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class ChartGenerator:
    """Class for generating chart snapshots with technical indicators"""
    
    def __init__(self):
        """Initialize the chart generator"""
        # Set chart style
        plt.style.use('dark_background')
        
        # Set default chart dimensions
        self.width = 10
        self.height = 6
        self.dpi = 100
        
        # Set default colors
        self.colors = {
            'background': '#121212',
            'grid': '#333333',
            'candle_up': '#26a69a',
            'candle_down': '#ef5350',
            'volume_up': '#26a69a',
            'volume_down': '#ef5350',
            'ma_fast': '#f5d442',
            'ma_slow': '#ff9800',
            'gaussian_upper': '#64b5f6',
            'gaussian_lower': '#64b5f6',
            'gaussian_middle': '#bbdefb',
            'macd_line': '#2196f3',
            'signal_line': '#ff9800',
            'histogram_positive': '#26a69a',
            'histogram_negative': '#ef5350',
            'stoch_k': '#2196f3',
            'stoch_d': '#ff9800',
            'atr': '#ce93d8',
            'buy_signal': '#26a69a',
            'sell_signal': '#ef5350',
            'text': '#ffffff'
        }
        
        logger.info("Chart generator initialized")
    
    def generate_candlestick_chart(self, df, indicators=None, save_path=None):
        """
        Generate a candlestick chart with technical indicators
        
        Args:
            df: DataFrame with OHLCV data
            indicators: Dictionary with indicator data
            save_path: Path to save the chart image
            
        Returns:
            str: Path to saved chart image
        """
        try:
            # Create figure and subplots
            fig = plt.figure(figsize=(self.width, self.height), dpi=self.dpi)
            
            # Determine number of subplots based on indicators
            if indicators and ('macd' in indicators or 'stoch_rsi' in indicators):
                # Main chart + indicators
                if 'macd' in indicators and 'stoch_rsi' in indicators:
                    # Price, MACD, Stoch RSI
                    gs = fig.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])
                    ax1 = fig.add_subplot(gs[0])  # Price chart
                    ax2 = fig.add_subplot(gs[1], sharex=ax1)  # Volume
                    ax3 = fig.add_subplot(gs[2], sharex=ax1)  # MACD
                    ax4 = fig.add_subplot(gs[3], sharex=ax1)  # Stoch RSI
                elif 'macd' in indicators:
                    # Price, MACD
                    gs = fig.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                    ax1 = fig.add_subplot(gs[0])  # Price chart
                    ax2 = fig.add_subplot(gs[1], sharex=ax1)  # Volume
                    ax3 = fig.add_subplot(gs[2], sharex=ax1)  # MACD
                    ax4 = None
                else:
                    # Price, Stoch RSI
                    gs = fig.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                    ax1 = fig.add_subplot(gs[0])  # Price chart
                    ax2 = fig.add_subplot(gs[1], sharex=ax1)  # Volume
                    ax3 = None
                    ax4 = fig.add_subplot(gs[2], sharex=ax1)  # Stoch RSI
            else:
                # Just price and volume
                gs = fig.add_gridspec(2, 1, height_ratios=[4, 1])
                ax1 = fig.add_subplot(gs[0])  # Price chart
                ax2 = fig.add_subplot(gs[1], sharex=ax1)  # Volume
                ax3 = None
                ax4 = None
            
            # Set background color
            fig.patch.set_facecolor(self.colors['background'])
            ax1.set_facecolor(self.colors['background'])
            ax2.set_facecolor(self.colors['background'])
            if ax3:
                ax3.set_facecolor(self.colors['background'])
            if ax4:
                ax4.set_facecolor(self.colors['background'])
            
            # Plot candlestick chart
            self._plot_candlesticks(ax1, df)
            
            # Plot volume
            self._plot_volume(ax2, df)
            
            # Plot indicators
            if indicators:
                self._plot_indicators(ax1, ax3, ax4, df, indicators)
            
            # Set title
            symbol = indicators.get('symbol', 'Unknown') if indicators else 'Unknown'
            timeframe = indicators.get('timeframe', '1h') if indicators else '1h'
            ax1.set_title(f"{symbol} - {timeframe} Timeframe", color=self.colors['text'])
            
            # Format x-axis
            self._format_xaxis(ax1, df)
            
            # Hide x-axis labels for all but the bottom subplot
            ax1.tick_params(axis='x', labelsize=8, colors=self.colors['text'])
            ax2.tick_params(axis='x', labelsize=8, colors=self.colors['text'])
            if ax3:
                ax3.tick_params(axis='x', labelsize=8, colors=self.colors['text'])
            if ax4:
                ax4.tick_params(axis='x', labelsize=8, colors=self.colors['text'])
            
            # Format y-axis
            ax1.tick_params(axis='y', labelsize=8, colors=self.colors['text'])
            ax2.tick_params(axis='y', labelsize=8, colors=self.colors['text'])
            if ax3:
                ax3.tick_params(axis='y', labelsize=8, colors=self.colors['text'])
            if ax4:
                ax4.tick_params(axis='y', labelsize=8, colors=self.colors['text'])
            
            # Add grid
            ax1.grid(True, linestyle='--', alpha=0.3, color=self.colors['grid'])
            ax2.grid(True, linestyle='--', alpha=0.3, color=self.colors['grid'])
            if ax3:
                ax3.grid(True, linestyle='--', alpha=0.3, color=self.colors['grid'])
            if ax4:
                ax4.grid(True, linestyle='--', alpha=0.3, color=self.colors['grid'])
            
            # Add signal markers if available
            if indicators and 'signals' in indicators:
                self._plot_signals(ax1, df, indicators['signals'])
            
            # Adjust layout
            plt.tight_layout()
            
            # Save chart
            if save_path:
                plt.savefig(save_path, facecolor=self.colors['background'])
                plt.close(fig)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"/tmp/{symbol}_{timeframe}_chart.png"
                plt.savefig(temp_path, facecolor=self.colors['background'])
                plt.close(fig)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error generating candlestick chart: {e}", exc_info=True)
            return None
    
    def _plot_candlesticks(self, ax, df):
        """Plot candlestick chart on the given axis"""
        # Get data
        dates = df['timestamp']
        opens = df['open']
        highs = df['high']
        lows = df['low']
        closes = df['close']
        
        # Calculate width of candlesticks
        width = 0.6 * (dates[1] - dates[0]).total_seconds() / (24 * 60 * 60)
        
        # Plot candlesticks
        for i in range(len(dates)):
            # Determine if candle is up or down
            if closes[i] >= opens[i]:
                color = self.colors['candle_up']
                body_bottom = opens[i]
                body_height = closes[i] - opens[i]
            else:
                color = self.colors['candle_down']
                body_bottom = closes[i]
                body_height = opens[i] - closes[i]
            
            # Plot candle body
            ax.add_patch(plt.Rectangle(
                (dates[i] - pd.Timedelta(days=width/2), body_bottom),
                pd.Timedelta(days=width),
                body_height,
                fill=True,
                color=color,
                alpha=0.8
            ))
            
            # Plot candle wicks
            ax.plot(
                [dates[i], dates[i]],
                [lows[i], highs[i]],
                color=color,
                linewidth=1
            )
        
        # Set y-axis label
        ax.set_ylabel('Price', color=self.colors['text'])
    
    def _plot_volume(self, ax, df):
        """Plot volume on the given axis"""
        # Get data
        dates = df['timestamp']
        opens = df['open']
        closes = df['close']
        volumes = df['volume']
        
        # Calculate width of volume bars
        width = 0.6 * (dates[1] - dates[0]).total_seconds() / (24 * 60 * 60)
        
        # Plot volume bars
        for i in range(len(dates)):
            # Determine if candle is up or down
            if closes[i] >= opens[i]:
                color = self.colors['volume_up']
            else:
                color = self.colors['volume_down']
            
            # Plot volume bar
            ax.add_patch(plt.Rectangle(
                (dates[i] - pd.Timedelta(days=width/2), 0),
                pd.Timedelta(days=width),
                volumes[i],
                fill=True,
                color=color,
                alpha=0.5
            ))
        
        # Set y-axis label
        ax.set_ylabel('Volume', color=self.colors['text'])
    
    def _plot_indicators(self, price_ax, macd_ax, stoch_ax, df, indicators):
        """Plot technical indicators on the given axes"""
        # Plot moving averages on price chart
        if 'ma_fast' in indicators and 'ma_slow' in indicators:
            price_ax.plot(
                df['timestamp'],
                indicators['ma_fast'],
                color=self.colors['ma_fast'],
                linewidth=1,
                label=f"MA Fast ({indicators.get('ma_fast_period', 'N/A')})"
            )
            
            price_ax.plot(
                df['timestamp'],
                indicators['ma_slow'],
                color=self.colors['ma_slow'],
                linewidth=1,
                label=f"MA Slow ({indicators.get('ma_slow_period', 'N/A')})"
            )
        
        # Plot Gaussian Channel on price chart
        if 'gaussian_upper' in indicators and 'gaussian_lower' in indicators:
            price_ax.plot(
                df['timestamp'],
                indicators['gaussian_upper'],
                color=self.colors['gaussian_upper'],
                linewidth=1,
                label="Gaussian Upper"
            )
            
            price_ax.plot(
                df['timestamp'],
                indicators['gaussian_lower'],
                color=self.colors['gaussian_lower'],
                linewidth=1,
                label="Gaussian Lower"
            )
            
            if 'gaussian_middle' in indicators:
                price_ax.plot(
                    df['timestamp'],
                    indicators['gaussian_middle'],
                    color=self.colors['gaussian_middle'],
                    linewidth=1,
                    linestyle='--',
                    label="Gaussian Middle"
                )
        
        # Plot MACD
        if macd_ax and 'macd_line' in indicators and 'signal_line' in indicators and 'histogram' in indicators:
            # Plot MACD line
            macd_ax.plot(
                df['timestamp'],
                indicators['macd_line'],
                color=self.colors['macd_line'],
                linewidth=1,
                label="MACD"
            )
            
            # Plot signal line
            macd_ax.plot(
                df['timestamp'],
                indicators['signal_line'],
                color=self.colors['signal_line'],
                linewidth=1,
                label="Signal"
            )
            
            # Plot histogram
            for i in range(len(df)):
                if i > 0:  # Skip first bar
                    hist_val = indicators['histogram'][i]
                    color = self.colors['histogram_positive'] if hist_val >= 0 else self.colors['histogram_negative']
                    
                    macd_ax.add_patch(plt.Rectangle(
                        (df['timestamp'][i] - pd.Timedelta(hours=6), 0),
                        pd.Timedelta(hours=12),
                        hist_val,
                        fill=True,
                        color=color,
                        alpha=0.5
                    ))
            
            # Set y-axis label
            macd_ax.set_ylabel('MACD', color=self.colors['text'])
            
            # Add legend
            macd_ax.legend(loc='upper left', fontsize=8)
        
        # Plot Stochastic RSI
        if stoch_ax and 'stoch_k' in indicators and 'stoch_d' in indicators:
            # Plot K line
            stoch_ax.plot(
                df['timestamp'],
                indicators['stoch_k'],
                color=self.colors['stoch_k'],
                linewidth=1,
                label="K"
            )
            
            # Plot D line
            stoch_ax.plot(
                df['timestamp'],
                indicators['stoch_d'],
                color=self.colors['stoch_d'],
                linewidth=1,
                label="D"
            )
            
            # Add overbought/oversold lines
            stoch_ax.axhline(y=80, color='r', linestyle='--', alpha=0.3)
            stoch_ax.axhline(y=20, color='g', linestyle='--', alpha=0.3)
            
            # Set y-axis limits
            stoch_ax.set_ylim(0, 100)
            
            # Set y-axis label
            stoch_ax.set_ylabel('Stoch RSI', color=self.colors['text'])
            
            # Add legend
            stoch_ax.legend(loc='upper left', fontsize=8)
        
        # Add ATR to price chart
        if 'atr' in indicators:
            # Create twin axis for ATR
            atr_ax = price_ax.twinx()
            
            # Plot ATR
            atr_ax.plot(
                df['timestamp'],
                indicators['atr'],
                color=self.colors['atr'],
                linewidth=1,
                linestyle=':',
                label=f"ATR ({indicators.get('atr_period', 'N/A')})"
            )
            
            # Set y-axis label
            atr_ax.set_ylabel('ATR', color=self.colors['atr'])
            
            # Set y-axis tick color
            atr_ax.tick_params(axis='y', colors=self.colors['atr'])
            
            # Add legend
            atr_ax.legend(loc='upper right', fontsize=8)
        
        # Add legend to price chart
        price_ax.legend(loc='upper left', fontsize=8)
    
    def _plot_signals(self, ax, df, signals):
        """Plot buy/sell signals on the price chart"""
        # Get data
        dates = df['timestamp']
        highs = df['high']
        lows = df['low']
        
        # Plot buy signals
        if 'buy' in signals:
            for i in signals['buy']:
                if 0 <= i < len(dates):
                    ax.scatter(
                        dates[i],
                        lows[i] * 0.99,  # Slightly below the low
                        marker='^',
                        color=self.colors['buy_signal'],
                        s=100,
                        alpha=0.8,
                        label='Buy' if i == signals['buy'][0] else ""
                    )
        
        # Plot sell signals
        if 'sell' in signals:
            for i in signals['sell']:
                if 0 <= i < len(dates):
                    ax.scatter(
                        dates[i],
                        highs[i] * 1.01,  # Slightly above the high
                        marker='v',
                        color=self.colors['sell_signal'],
                        s=100,
                        alpha=0.8,
                        label='Sell' if i == signals['sell'][0] else ""
                    )
    
    def _format_xaxis(self, ax, df):
        """Format the x-axis with proper date labels"""
        # Set x-axis limits
        ax.set_xlim(df['timestamp'].iloc[0], df['timestamp'].iloc[-1])
        
        # Format date labels
        date_format = mdates.DateFormatter('%m-%d %H:%M')
        ax.xaxis.set_major_formatter(date_format)
        
        # Rotate date labels
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
    
    def generate_alert_image(self, alert_data, save_path=None):
        """
        Generate a custom alert image with key information
        
        Args:
            alert_data: Alert data with signal information
            save_path: Path to save the image
            
        Returns:
            str: Path to saved image
        """
        try:
            # Create a new image
            width, height = 800, 600
            image = Image.new('RGB', (width, height), color=(18, 18, 18))  # Dark background
            draw = ImageDraw.Draw(image)
            
            # Try to load a font, use default if not available
            try:
                title_font = ImageFont.truetype("Arial.ttf", 36)
                header_font = ImageFont.truetype("Arial.ttf", 24)
                text_font = ImageFont.truetype("Arial.ttf", 18)
            except IOError:
                title_font = ImageFont.load_default()
                header_font = ImageFont.load_default()
                text_font = ImageFont.load_default()
            
            # Get signal type
            signal = alert_data.get('signal', 0)
            signal_type = "BUY" if signal > 0 else "SELL" if signal < 0 else "NEUTRAL"
            
            # Set signal color
            if signal_type == "BUY":
                signal_color = (38, 166, 154)  # Green
            elif signal_type == "SELL":
                signal_color = (239, 83, 80)  # Red
            else:
                signal_color = (158, 158, 158)  # Gray
            
            # Draw header background
            draw.rectangle([(0, 0), (width, 80)], fill=signal_color)
            
            # Draw title
            symbol = alert_data.get('symbol', 'Unknown')
            draw.text((width/2, 40), f"{signal_type} SIGNAL: {symbol}", fill=(255, 255, 255), font=title_font, anchor="mm")
            
            # Draw price information
            price = alert_data.get('price', 0)
            y_pos = 120
            draw.text((width/2, y_pos), f"Current Price: ${price:.4f}", fill=(255, 255, 255), font=header_font, anchor="mm")
            
            # Draw technical indicators
            y_pos += 60
            draw.text((width/2, y_pos), "Technical Indicators", fill=(255, 255, 255), font=header_font, anchor="mm")
            
            y_pos += 40
            trend_strength = alert_data.get('trend_strength', 0)
            confidence = alert_data.get('confidence', 0)
            
            # Draw trend strength bar
            bar_width = 300
            bar_height = 20
            draw.text((width/2 - bar_width/2 - 10, y_pos + bar_height/2), "Trend Strength:", fill=(255, 255, 255), font=text_font, anchor="rm")
            
            # Draw background bar
            draw.rectangle(
                [(width/2, y_pos), (width/2 + bar_width, y_pos + bar_height)],
                outline=(255, 255, 255),
                fill=(50, 50, 50),
                width=1
            )
            
            # Draw filled bar
            trend_width = (trend_strength / 100) * bar_width
            trend_color = self._get_gradient_color(trend_strength)
            draw.rectangle(
                [(width/2, y_pos), (width/2 + trend_width, y_pos + bar_height)],
                outline=None,
                fill=trend_color
            )
            
            # Draw percentage
            draw.text((width/2 + bar_width + 10, y_pos + bar_height/2), f"{trend_strength:.1f}%", fill=(255, 255, 255), font=text_font, anchor="lm")
            
            # Draw confidence bar
            y_pos += 40
            draw.text((width/2 - bar_width/2 - 10, y_pos + bar_height/2), "Signal Confidence:", fill=(255, 255, 255), font=text_font, anchor="rm")
            
            # Draw background bar
            draw.rectangle(
                [(width/2, y_pos), (width/2 + bar_width, y_pos + bar_height)],
                outline=(255, 255, 255),
                fill=(50, 50, 50),
                width=1
            )
            
            # Draw filled bar
            confidence_width = (confidence / 100) * bar_width
            confidence_color = self._get_gradient_color(confidence)
            draw.rectangle(
                [(width/2, y_pos), (width/2 + confidence_width, y_pos + bar_height)],
                outline=None,
                fill=confidence_color
            )
            
            # Draw percentage
            draw.text((width/2 + bar_width + 10, y_pos + bar_height/2), f"{confidence:.1f}%", fill=(255, 255, 255), font=text_font, anchor="lm")
            
            # Draw risk management
            y_pos += 60
            draw.text((width/2, y_pos), "Risk Management", fill=(255, 255, 255), font=header_font, anchor="mm")
            
            y_pos += 40
            if 'stop_loss' in alert_data and 'take_profit' in alert_data:
                stop_loss = alert_data['stop_loss']
                take_profit = alert_data['take_profit']
                
                # Calculate potential loss and gain
                if signal > 0:  # Long position
                    potential_loss_pct = ((stop_loss / price) - 1) * 100
                    potential_gain_pct = ((take_profit / price) - 1) * 100
                else:  # Short position
                    potential_loss_pct = ((price / stop_loss) - 1) * 100
                    potential_gain_pct = ((price / take_profit) - 1) * 100
                
                # Draw stop loss and take profit
                draw.text((width/4, y_pos), "Stop Loss", fill=(239, 83, 80), font=text_font, anchor="mm")
                draw.text((width/4, y_pos + 30), f"${stop_loss:.4f}", fill=(255, 255, 255), font=text_font, anchor="mm")
                draw.text((width/4, y_pos + 60), f"{potential_loss_pct:.2f}%", fill=(239, 83, 80), font=text_font, anchor="mm")
                
                draw.text((width*3/4, y_pos), "Take Profit", fill=(38, 166, 154), font=text_font, anchor="mm")
                draw.text((width*3/4, y_pos + 30), f"${take_profit:.4f}", fill=(255, 255, 255), font=text_font, anchor="mm")
                draw.text((width*3/4, y_pos + 60), f"{potential_gain_pct:.2f}%", fill=(38, 166, 154), font=text_font, anchor="mm")
                
                # Draw risk-reward ratio if available
                if 'risk_reward_ratio' in alert_data:
                    risk_reward = alert_data['risk_reward_ratio']
                    y_pos += 100
                    draw.text((width/2, y_pos), f"Risk-Reward Ratio: {risk_reward:.2f}", fill=(255, 255, 255), font=text_font, anchor="mm")
            
            # Draw risk score if available
            if 'risk_score' in alert_data and 'risk_level' in alert_data:
                risk_score = alert_data['risk_score']
                risk_level = alert_data['risk_level']
                
                y_pos += 60
                draw.text((width/2, y_pos), "Risk Assessment", fill=(255, 255, 255), font=header_font, anchor="mm")
                
                y_pos += 40
                # Draw risk score bar
                draw.text((width/2 - bar_width/2 - 10, y_pos + bar_height/2), "Risk Score:", fill=(255, 255, 255), font=text_font, anchor="rm")
                
                # Draw background bar
                draw.rectangle(
                    [(width/2, y_pos), (width/2 + bar_width, y_pos + bar_height)],
                    outline=(255, 255, 255),
                    fill=(50, 50, 50),
                    width=1
                )
                
                # Draw filled bar
                risk_width = (risk_score / 100) * bar_width
                risk_color = self._get_gradient_color(risk_score)
                draw.rectangle(
                    [(width/2, y_pos), (width/2 + risk_width, y_pos + bar_height)],
                    outline=None,
                    fill=risk_color
                )
                
                # Draw score and level
                draw.text((width/2 + bar_width + 10, y_pos + bar_height/2), f"{risk_score:.1f}/100 ({risk_level})", fill=(255, 255, 255), font=text_font, anchor="lm")
            
            # Draw timestamp
            timestamp = alert_data.get('timestamp', datetime.now())
            y_pos = height - 40
            draw.text((width/2, y_pos), f"Alert Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}", fill=(158, 158, 158), font=text_font, anchor="mm")
            
            # Save image
            if save_path:
                image.save(save_path)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"/tmp/{symbol}_alert.png"
                image.save(temp_path)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error generating alert image: {e}", exc_info=True)
            return None
    
    def _get_gradient_color(self, value):
        """Get color from red-yellow-green gradient based on value (0-100)"""
        if value >= 80:
            return (38, 166, 154)  # Green
        elif value >= 60:
            return (255, 193, 7)  # Yellow
        elif value >= 40:
            return (255, 152, 0)  # Orange
        else:
            return (239, 83, 80)  # Red
