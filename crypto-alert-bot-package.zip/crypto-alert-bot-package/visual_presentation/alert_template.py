"""
Alert Template Module

This module provides templates for different types of cryptocurrency alerts
with consistent branding and visual elements.
"""

import logging
import os
from datetime import datetime
import json
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import matplotlib.pyplot as plt
import numpy as np

# Import local modules
from visual_presentation.chart_generator import ChartGenerator

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class AlertTemplate:
    """Class for creating alert templates with consistent branding"""
    
    def __init__(self):
        """Initialize the alert template"""
        self.chart_generator = ChartGenerator()
        self.template_dir = "/tmp/templates"
        
        # Create template directory if it doesn't exist
        os.makedirs(self.template_dir, exist_ok=True)
        
        # Set default colors
        self.colors = {
            'background': (18, 18, 18),
            'text': (255, 255, 255),
            'buy': (38, 166, 154),
            'sell': (239, 83, 80),
            'neutral': (158, 158, 158),
            'header': (33, 33, 33),
            'footer': (33, 33, 33),
            'border': (66, 66, 66),
            'highlight': (33, 150, 243)
        }
        
        logger.info("Alert template initialized")
    
    def create_buy_sell_alert(self, alert_data, chart_data=None, save_path=None):
        """
        Create a buy/sell alert image with chart and key information
        
        Args:
            alert_data: Alert data with signal information
            chart_data: Chart data with OHLCV and indicators (optional)
            save_path: Path to save the image
            
        Returns:
            str: Path to saved image
        """
        try:
            # Generate chart if data provided
            chart_path = None
            if chart_data is not None:
                # Generate chart
                chart_path = self.chart_generator.generate_candlestick_chart(
                    chart_data['ohlcv'],
                    chart_data.get('indicators'),
                    f"{self.template_dir}/temp_chart.png"
                )
            elif 'chart_path' in alert_data and alert_data['chart_path']:
                # Use provided chart path
                chart_path = alert_data['chart_path']
            
            # Create alert image
            alert_image_path = self.chart_generator.generate_alert_image(
                alert_data,
                f"{self.template_dir}/temp_alert.png"
            )
            
            # If both chart and alert image are available, combine them
            if chart_path and alert_image_path:
                return self._combine_chart_and_alert(chart_path, alert_image_path, save_path)
            elif chart_path:
                # Only chart available
                if save_path:
                    # Copy chart to save path
                    import shutil
                    shutil.copy(chart_path, save_path)
                    return save_path
                else:
                    return chart_path
            elif alert_image_path:
                # Only alert image available
                if save_path:
                    # Copy alert image to save path
                    import shutil
                    shutil.copy(alert_image_path, save_path)
                    return save_path
                else:
                    return alert_image_path
            else:
                logger.error("Failed to generate chart or alert image")
                return None
        
        except Exception as e:
            logger.error(f"Error creating buy/sell alert: {e}", exc_info=True)
            return None
    
    def _combine_chart_and_alert(self, chart_path, alert_path, save_path=None):
        """Combine chart and alert images into a single image"""
        try:
            # Open images
            chart_img = Image.open(chart_path)
            alert_img = Image.open(alert_path)
            
            # Create new image with combined height
            width = max(chart_img.width, alert_img.width)
            height = chart_img.height + alert_img.height
            
            combined_img = Image.new('RGB', (width, height), color=self.colors['background'])
            
            # Paste chart at top
            chart_x = (width - chart_img.width) // 2
            combined_img.paste(chart_img, (chart_x, 0))
            
            # Paste alert below chart
            alert_x = (width - alert_img.width) // 2
            combined_img.paste(alert_img, (alert_x, chart_img.height))
            
            # Save combined image
            if save_path:
                combined_img.save(save_path)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"{self.template_dir}/combined_alert.png"
                combined_img.save(temp_path)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error combining chart and alert: {e}", exc_info=True)
            return None
    
    def create_coin_rating_card(self, rating_data, save_path=None):
        """
        Create a coin rating card with category breakdowns
        
        Args:
            rating_data: Dictionary with rating information
            save_path: Path to save the image
            
        Returns:
            str: Path to saved image
        """
        try:
            # Create a new image
            width, height = 800, 600
            image = Image.new('RGB', (width, height), color=self.colors['background'])
            draw = ImageDraw.Draw(image)
            
            # Try to load a font, use default if not available
            try:
                title_font = ImageFont.truetype("Arial.ttf", 36)
                header_font = ImageFont.truetype("Arial.ttf", 24)
                text_font = ImageFont.truetype("Arial.ttf", 18)
            except IOError:
                title_font = ImageFont.load_default()
                header_font = ImageFont.load_default()
                text_font = ImageFont.load_default()
            
            # Draw header background
            draw.rectangle([(0, 0), (width, 80)], fill=self.colors['header'])
            
            # Draw title
            symbol = rating_data.get('symbol', 'Unknown')
            draw.text((width/2, 40), f"Coin Rating: {symbol}", fill=self.colors['text'], font=title_font, anchor="mm")
            
            # Draw overall score
            overall_score = rating_data.get('overall_score', 0)
            
            # Determine color based on score
            if overall_score >= 80:
                score_color = self.colors['buy']  # Green
            elif overall_score >= 60:
                score_color = (255, 165, 0)  # Orange
            elif overall_score >= 40:
                score_color = (255, 140, 0)  # Dark Orange
            else:
                score_color = self.colors['sell']  # Red
            
            # Draw score circle
            circle_center = (width/2, 150)
            circle_radius = 60
            draw.ellipse(
                [(circle_center[0]-circle_radius, circle_center[1]-circle_radius),
                 (circle_center[0]+circle_radius, circle_center[1]+circle_radius)],
                outline=self.colors['border'],
                fill=score_color,
                width=2
            )
            
            # Draw score text
            draw.text(circle_center, f"{overall_score}", fill=self.colors['text'], font=title_font, anchor="mm")
            
            # Draw category scores
            categories = [
                ('liquidity', 'Liquidity'),
                ('volume', 'Volume'),
                ('holders', 'Holders'),
                ('social_hype', 'Social Hype'),
                ('technical_score', 'Technical'),
                ('risk_score', 'Risk')
            ]
            
            # Calculate positions
            start_y = 250
            bar_height = 25
            bar_width = 400
            spacing = 50
            
            for i, (key, label) in enumerate(categories):
                y_pos = start_y + i * spacing
                
                # Get score
                score = rating_data.get(key, 0)
                
                # Determine color based on score
                if score >= 80:
                    bar_color = self.colors['buy']  # Green
                elif score >= 60:
                    bar_color = (255, 165, 0)  # Orange
                elif score >= 40:
                    bar_color = (255, 140, 0)  # Dark Orange
                else:
                    bar_color = self.colors['sell']  # Red
                
                # Draw label
                draw.text((width/2 - bar_width/2 - 10, y_pos + bar_height/2), label, fill=self.colors['text'], font=text_font, anchor="rm")
                
                # Draw background bar
                draw.rectangle(
                    [(width/2 - bar_width/2, y_pos), (width/2 + bar_width/2, y_pos + bar_height)],
                    outline=self.colors['border'],
                    fill=(50, 50, 50),
                    width=1
                )
                
                # Draw score bar
                score_width = (score / 100) * bar_width
                draw.rectangle(
                    [(width/2 - bar_width/2, y_pos), (width/2 - bar_width/2 + score_width, y_pos + bar_height)],
                    outline=None,
                    fill=bar_color
                )
                
                # Draw score text
                draw.text((width/2 + bar_width/2 + 10, y_pos + bar_height/2), f"{score:.1f}", fill=self.colors['text'], font=text_font, anchor="lm")
            
            # Draw footer
            draw.rectangle([(0, height-50), (width, height)], fill=self.colors['footer'])
            
            # Draw timestamp
            timestamp = datetime.now()
            draw.text((width/2, height-25), f"Generated: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}", fill=self.colors['text'], font=text_font, anchor="mm")
            
            # Save image
            if save_path:
                image.save(save_path)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"{self.template_dir}/{symbol}_rating.png"
                image.save(temp_path)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error creating coin rating card: {e}", exc_info=True)
            return None
    
    def create_social_hype_card(self, hype_data, save_path=None):
        """
        Create a social media hype score card
        
        Args:
            hype_data: Dictionary with social media hype information
            save_path: Path to save the image
            
        Returns:
            str: Path to saved image
        """
        try:
            # Create a new image
            width, height = 800, 600
            image = Image.new('RGB', (width, height), color=self.colors['background'])
            draw = ImageDraw.Draw(image)
            
            # Try to load a font, use default if not available
            try:
                title_font = ImageFont.truetype("Arial.ttf", 36)
                header_font = ImageFont.truetype("Arial.ttf", 24)
                text_font = ImageFont.truetype("Arial.ttf", 18)
            except IOError:
                title_font = ImageFont.load_default()
                header_font = ImageFont.load_default()
                text_font = ImageFont.load_default()
            
            # Draw header background
            draw.rectangle([(0, 0), (width, 80)], fill=self.colors['header'])
            
            # Draw title
            symbol = hype_data.get('symbol', 'Unknown')
            draw.text((width/2, 40), f"Social Hype: {symbol}", fill=self.colors['text'], font=title_font, anchor="mm")
            
            # Draw overall hype score
            hype_score = hype_data.get('hype_score', 0)
            
            # Determine color based on score
            if hype_score >= 80:
                score_color = self.colors['buy']  # Green
            elif hype_score >= 60:
                score_color = (255, 165, 0)  # Orange
            elif hype_score >= 40:
                score_color = (255, 140, 0)  # Dark Orange
            else:
                score_color = self.colors['sell']  # Red
            
            # Draw score circle
            circle_center = (width/2, 150)
            circle_radius = 60
            draw.ellipse(
                [(circle_center[0]-circle_radius, circle_center[1]-circle_radius),
                 (circle_center[0]+circle_radius, circle_center[1]+circle_radius)],
                outline=self.colors['border'],
                fill=score_color,
                width=2
            )
            
            # Draw score text
            draw.text(circle_center, f"{hype_score}", fill=self.colors['text'], font=title_font, anchor="mm")
            
            # Draw platform scores
            platforms = [
                ('twitter', 'Twitter/X'),
                ('telegram', 'Telegram'),
                ('reddit', 'Reddit'),
                ('discord', 'Discord')
            ]
            
            # Calculate positions
            start_y = 250
            bar_height = 25
            bar_width = 400
            spacing = 50
            
            for i, (key, label) in enumerate(platforms):
                y_pos = start_y + i * spacing
                
                # Get score
                score = hype_data.get(f"{key}_score", 0)
                
                # Determine color based on score
                if score >= 80:
                    bar_color = self.colors['buy']  # Green
                elif score >= 60:
                    bar_color = (255, 165, 0)  # Orange
                elif score >= 40:
                    bar_color = (255, 140, 0)  # Dark Orange
                else:
                    bar_color = self.colors['sell']  # Red
                
                # Draw label
                draw.text((width/2 - bar_width/2 - 10, y_pos + bar_height/2), label, fill=self.colors['text'], font=text_font, anchor="rm")
                
                # Draw background bar
                draw.rectangle(
                    [(width/2 - bar_width/2, y_pos), (width/2 + bar_width/2, y_pos + bar_height)],
                    outline=self.colors['border'],
                    fill=(50, 50, 50),
                    width=1
                )
                
                # Draw score bar
                score_width = (score / 100) * bar_width
                draw.rectangle(
                    [(width/2 - bar_width/2, y_pos), (width/2 - bar_width/2 + score_width, y_pos + bar_height)],
                    outline=None,
                    fill=bar_color
                )
                
                # Draw score text
                draw.text((width/2 + bar_width/2 + 10, y_pos + bar_height/2), f"{score:.1f}", fill=self.colors['text'], font=text_font, anchor="lm")
                
                # Draw mentions count if available
                mentions = hype_data.get(f"{key}_mentions", 0)
                if mentions > 0:
                    draw.text((width/2 + bar_width/2 + 80, y_pos + bar_height/2), f"({mentions} mentions)", fill=self.colors['text'], font=text_font, anchor="lm")
            
            # Draw sentiment analysis if available
            if 'sentiment_positive' in hype_data and 'sentiment_negative' in hype_data and 'sentiment_neutral' in hype_data:
                y_pos = start_y + len(platforms) * spacing + 20
                
                draw.text((width/2, y_pos), "Sentiment Analysis", fill=self.colors['text'], font=header_font, anchor="mm")
                
                # Get sentiment values
                positive = hype_data['sentiment_positive']
                negative = hype_data['sentiment_negative']
                neutral = hype_data['sentiment_neutral']
                
                # Calculate total for percentages
                total = positive + negative + neutral
                if total > 0:
                    positive_pct = (positive / total) * 100
                    negative_pct = (negative / total) * 100
                    neutral_pct = (neutral / total) * 100
                else:
                    positive_pct = negative_pct = neutral_pct = 0
                
                # Draw pie chart
                y_pos += 50
                pie_center = (width/2, y_pos + 80)
                pie_radius = 80
                
                # Draw sentiment pie chart using matplotlib
                plt.figure(figsize=(6, 6))
                plt.pie(
                    [positive_pct, neutral_pct, negative_pct],
                    labels=['Positive', 'Neutral', 'Negative'],
                    colors=[self.colors['buy'], (158, 158, 158), self.colors['sell']],
                    autopct='%1.1f%%',
                    startangle=90
                )
                plt.axis('equal')
                
                # Save pie chart
                pie_path = f"{self.template_dir}/sentiment_pie.png"
                plt.savefig(pie_path, facecolor=self.colors['background'])
                plt.close()
                
                # Open pie chart and paste into main image
                pie_img = Image.open(pie_path)
                pie_img = pie_img.resize((200, 200))
                image.paste(pie_img, (width//2 - 100, y_pos))
            
            # Draw footer
            draw.rectangle([(0, height-50), (width, height)], fill=self.colors['footer'])
            
            # Draw timestamp
            timestamp = datetime.now()
            draw.text((width/2, height-25), f"Generated: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}", fill=self.colors['text'], font=text_font, anchor="mm")
            
            # Save image
            if save_path:
                image.save(save_path)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"{self.template_dir}/{symbol}_hype.png"
                image.save(temp_path)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error creating social hype card: {e}", exc_info=True)
            return None
    
    def create_risk_analysis_card(self, risk_data, save_path=None):
        """
        Create a risk analysis card with component scoring
        
        Args:
            risk_data: Dictionary with risk information
            save_path: Path to save the image
            
        Returns:
            str: Path to saved image
        """
        try:
            # Create figure
            fig, ax = plt.subplots(figsize=(10, 8), facecolor=self.colors['background'])
            
            # Extract data
            symbol = risk_data.get('symbol', 'Unknown')
            risk_score = risk_data.get('risk_score', 0)
            risk_level = risk_data.get('risk_level', 'Unknown')
            
            # Get component scores
            trend_score = risk_data.get('trend_score', 0)
            confidence_score = risk_data.get('confidence_score', 0)
            risk_reward_score = risk_data.get('risk_reward_score', 0)
            
            # Set title
            ax.set_title(f"Risk Analysis: {symbol}", fontsize=20, color=self.colors['text'])
            ax.set_facecolor(self.colors['background'])
            
            # Create bar chart for component scores
            categories = ['Trend\nStrength', 'Signal\nConfidence', 'Risk-Reward\nRatio']
            scores = [trend_score, confidence_score, risk_reward_score]
            
            # Set colors based on scores
            colors = []
            for score in scores:
                if score >= 30:
                    colors.append(self.colors['buy'])
                elif score >= 20:
                    colors.append((255, 165, 0))
                elif score >= 10:
                    colors.append((255, 140, 0))
                else:
                    colors.append(self.colors['sell'])
            
            # Convert RGB tuples to matplotlib format
            colors = [(r/255, g/255, b/255) for r, g, b in colors]
            
            # Create bar chart
            bars = ax.bar(categories, scores, color=colors)
            
            # Add score labels on top of bars
            for bar in bars:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 1,
                        f'{height:.1f}',
                        ha='center', va='bottom', color=self.colors['text'])
            
            # Set y-axis limit
            ax.set_ylim(0, 40)
            
            # Set axis colors
            ax.spines['bottom'].set_color(self.colors['border'])
            ax.spines['top'].set_color(self.colors['border'])
            ax.spines['left'].set_color(self.colors['border'])
            ax.spines['right'].set_color(self.colors['border'])
            ax.tick_params(axis='x', colors=self.colors['text'])
            ax.tick_params(axis='y', colors=self.colors['text'])
            
            # Add overall risk score as text
            if risk_score >= 80:
                risk_color = self.colors['buy']
            elif risk_score >= 60:
                risk_color = (255, 165, 0)
            elif risk_score >= 40:
                risk_color = (255, 140, 0)
            else:
                risk_color = self.colors['sell']
            
            # Convert RGB tuple to matplotlib format
            risk_color = (risk_color[0]/255, risk_color[1]/255, risk_color[2]/255)
            
            ax.text(0.5, 0.9, f"Overall Risk Score: {risk_score:.1f}/100 ({risk_level})",
                    horizontalalignment='center',
                    verticalalignment='center',
                    transform=ax.transAxes,
                    fontsize=16,
                    color=self.colors['text'],
                    bbox=dict(facecolor=risk_color, alpha=0.3))
            
            # Add explanation
            ax.text(0.5, 0.05,
                    "Higher scores indicate lower risk. Components add up to 100 max.",
                    horizontalalignment='center',
                    verticalalignment='center',
                    transform=ax.transAxes,
                    fontsize=12,
                    style='italic',
                    color=self.colors['text'])
            
            # Add timestamp
            timestamp = datetime.now()
            ax.text(0.5, 0.02,
                    f"Generated: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}",
                    horizontalalignment='center',
                    verticalalignment='center',
                    transform=ax.transAxes,
                    fontsize=10,
                    color=self.colors['text'])
            
            # Adjust layout
            plt.tight_layout()
            
            # Save image
            if save_path:
                plt.savefig(save_path, facecolor=self.colors['background'])
                plt.close(fig)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"{self.template_dir}/{symbol}_risk.png"
                plt.savefig(temp_path, facecolor=self.colors['background'])
                plt.close(fig)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error creating risk analysis card: {e}", exc_info=True)
            return None
