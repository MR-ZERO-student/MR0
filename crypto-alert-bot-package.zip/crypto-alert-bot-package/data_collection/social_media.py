"""
Social Media Monitoring Module

This module monitors Twitter/X and other social media platforms to capture
trending coin mentions and perform sentiment analysis.
"""

import os
import json
import time
import logging
import asyncio
import re
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from collections import Counter, defaultdict

# Import tweepy for Twitter API
import tweepy
from tweepy import Client, StreamingClient, StreamRule

# Import for sentiment analysis
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class TwitterMonitor:
    """Class for monitoring Twitter/X for cryptocurrency mentions and sentiment"""
    
    def __init__(self):
        """Initialize the Twitter monitor"""
        # Twitter API credentials
        self.api_key = config.TWITTER_API_KEY
        self.api_secret = config.TWITTER_API_SECRET
        self.access_token = config.TWITTER_ACCESS_TOKEN
        self.access_secret = config.TWITTER_ACCESS_SECRET
        
        # Initialize Twitter clients
        self._init_twitter_clients()
        
        # Initialize data structures
        self.coin_mentions = defaultdict(int)
        self.coin_sentiment = defaultdict(list)
        self.trending_coins = []
        self.stream_client = None
        self.running = False
        
        # Initialize sentiment analyzer
        self._init_sentiment_analyzer()
        
        # Crypto-related keywords to track
        self.crypto_keywords = [
            "bitcoin", "btc", "ethereum", "eth", "crypto", "altcoin", "defi", 
            "nft", "blockchain", "token", "binance", "coinbase", "memecoin"
        ]
        
        logger.info("Twitter monitor initialized")
    
    def _init_twitter_clients(self):
        """Initialize Twitter API clients"""
        try:
            # Initialize v2 client
            self.client = Client(
                bearer_token=None,
                consumer_key=self.api_key,
                consumer_secret=self.api_secret,
                access_token=self.access_token,
                access_token_secret=self.access_secret
            )
            logger.info("Twitter API client initialized")
        except Exception as e:
            logger.error(f"Error initializing Twitter client: {e}", exc_info=True)
            self.client = None
    
    def _init_sentiment_analyzer(self):
        """Initialize the sentiment analysis model"""
        try:
            # Simple sentiment analysis pipeline
            # In a production system, you would use a pre-trained model or more sophisticated approach
            self.sentiment_pipeline = Pipeline([
                ('vectorizer', CountVectorizer(ngram_range=(1, 2))),
                ('classifier', MultinomialNB())
            ])
            
            # Simple training data (would be replaced with a proper dataset)
            training_data = [
                ("excited about this coin", "positive"),
                ("great potential", "positive"),
                ("going to the moon", "positive"),
                ("bullish on this", "positive"),
                ("huge gains", "positive"),
                ("scam coin", "negative"),
                ("rug pull", "negative"),
                ("lost all my money", "negative"),
                ("stay away", "negative"),
                ("dumping hard", "negative")
            ]
            
            texts, labels = zip(*training_data)
            self.sentiment_pipeline.fit(texts, labels)
            
            logger.info("Sentiment analyzer initialized")
        except Exception as e:
            logger.error(f"Error initializing sentiment analyzer: {e}", exc_info=True)
            self.sentiment_pipeline = None
    
    async def start_monitoring(self):
        """Start monitoring Twitter for cryptocurrency mentions"""
        logger.info("Starting Twitter monitoring")
        self.running = True
        
        # Start stream in a separate task
        asyncio.create_task(self._start_stream())
        
        # Start periodic search in a separate task
        asyncio.create_task(self._periodic_search())
        
        logger.info("Twitter monitoring started")
    
    async def stop_monitoring(self):
        """Stop monitoring Twitter"""
        logger.info("Stopping Twitter monitoring")
        self.running = False
        
        # Stop the stream if it's running
        if self.stream_client:
            self.stream_client.disconnect()
        
        logger.info("Twitter monitoring stopped")
    
    async def _start_stream(self):
        """Start streaming tweets"""
        # This is a placeholder for the streaming functionality
        # Twitter's streaming API requires elevated access which may not be available
        # In a real implementation, you would use tweepy's StreamingClient
        
        logger.info("Twitter streaming not implemented - using search API instead")
    
    async def _periodic_search(self):
        """Periodically search for cryptocurrency mentions"""
        while self.running:
            try:
                # Search for crypto-related tweets
                await self._search_crypto_tweets()
                
                # Update trending coins
                self._update_trending_coins()
                
                # Log current trending coins
                if self.trending_coins:
                    logger.info(f"Current trending coins: {', '.join(coin for coin, _ in self.trending_coins[:5])}")
                
                # Sleep before next search
                await asyncio.sleep(300)  # Search every 5 minutes
            except Exception as e:
                logger.error(f"Error in periodic search: {e}", exc_info=True)
                await asyncio.sleep(300)
    
    async def _search_crypto_tweets(self):
        """Search for cryptocurrency-related tweets"""
        if not self.client:
            logger.error("Twitter client not initialized")
            return
        
        try:
            # Search for crypto-related tweets
            for keyword in self.crypto_keywords:
                query = f"{keyword} -is:retweet lang:en"
                
                # Use Twitter API v2 search
                response = self.client.search_recent_tweets(
                    query=query,
                    max_results=100,
                    tweet_fields=["created_at", "public_metrics"]
                )
                
                if not response or not response.data:
                    continue
                
                # Process tweets
                for tweet in response.data:
                    self._process_tweet(tweet.text)
            
            # Reset mentions older than 24 hours
            self._clean_old_mentions()
            
        except Exception as e:
            logger.error(f"Error searching tweets: {e}", exc_info=True)
    
    def _process_tweet(self, tweet_text):
        """Process a tweet to extract coin mentions and sentiment"""
        try:
            # Extract potential coin mentions (tokens that start with $ or are all caps)
            potential_coins = re.findall(r'\$([A-Za-z0-9]+)|\b([A-Z]{2,10})\b', tweet_text)
            
            # Flatten and clean the results
            coins = []
            for match in potential_coins:
                for group in match:
                    if group and len(group) >= 2:
                        coins.append(group.upper())
            
            # Update mention counts
            for coin in coins:
                self.coin_mentions[coin] += 1
            
            # Analyze sentiment if we have coins and a sentiment analyzer
            if coins and self.sentiment_pipeline:
                sentiment = self.sentiment_pipeline.predict([tweet_text])[0]
                for coin in coins:
                    self.coin_sentiment[coin].append(sentiment)
        
        except Exception as e:
            logger.error(f"Error processing tweet: {e}", exc_info=True)
    
    def _clean_old_mentions(self):
        """Remove mentions older than 24 hours"""
        # In a real implementation, you would store timestamps with mentions
        # and remove old ones based on those timestamps
        # This is a simplified version that just keeps the counts
        pass
    
    def _update_trending_coins(self):
        """Update the list of trending coins based on mention counts and sentiment"""
        try:
            # Get coins with more than the trending threshold mentions
            trending = [
                (coin, count) 
                for coin, count in self.coin_mentions.items() 
                if count >= config.TRENDING_THRESHOLD
            ]
            
            # Sort by mention count
            trending.sort(key=lambda x: x[1], reverse=True)
            
            # Update trending coins
            self.trending_coins = trending
        
        except Exception as e:
            logger.error(f"Error updating trending coins: {e}", exc_info=True)
    
    def get_trending_coins(self, limit=10):
        """Get the current trending coins"""
        return self.trending_coins[:limit]
    
    def get_coin_sentiment(self, coin):
        """Get sentiment analysis for a specific coin"""
        if coin not in self.coin_sentiment:
            return None
        
        sentiments = self.coin_sentiment[coin]
        if not sentiments:
            return None
        
        # Calculate sentiment score (percentage of positive mentions)
        positive_count = sentiments.count("positive")
        sentiment_score = positive_count / len(sentiments)
        
        return {
            "coin": coin,
            "mentions": self.coin_mentions[coin],
            "sentiment_score": sentiment_score,
            "is_positive": sentiment_score >= config.SENTIMENT_THRESHOLD
        }


class SocialMediaAggregator:
    """Aggregates data from multiple social media sources"""
    
    def __init__(self):
        """Initialize the social media aggregator"""
        self.twitter_monitor = TwitterMonitor()
        # Add other social media monitors here (Reddit, Discord, etc.)
        
        self.aggregated_trends = {}
        self.running = False
        
        logger.info("Social media aggregator initialized")
    
    async def start_monitoring(self):
        """Start monitoring all social media platforms"""
        logger.info("Starting social media monitoring")
        self.running = True
        
        # Start Twitter monitoring
        await self.twitter_monitor.start_monitoring()
        
        # Start aggregation in a separate task
        asyncio.create_task(self._periodic_aggregation())
        
        logger.info("Social media monitoring started")
    
    async def stop_monitoring(self):
        """Stop monitoring all social media platforms"""
        logger.info("Stopping social media monitoring")
        self.running = False
        
        # Stop Twitter monitoring
        await self.twitter_monitor.stop_monitoring()
        
        logger.info("Social media monitoring stopped")
    
    async def _periodic_aggregation(self):
        """Periodically aggregate trends from all social media platforms"""
        while self.running:
            try:
                # Get trending coins from Twitter
                twitter_trends = self.twitter_monitor.get_trending_coins()
                
                # Aggregate trends (currently just Twitter, would add other platforms)
                self._aggregate_trends(twitter_trends)
                
                # Sleep before next aggregation
                await asyncio.sleep(600)  # Aggregate every 10 minutes
            except Exception as e:
                logger.error(f"Error in trend aggregation: {e}", exc_info=True)
                await asyncio.sleep(600)
    
    def _aggregate_trends(self, twitter_trends):
        """Aggregate trends from different social media platforms"""
        try:
            # Reset aggregated trends
            self.aggregated_trends = {}
            
            # Add Twitter trends
            for coin, count in twitter_trends:
                if coin not in self.aggregated_trends:
                    self.aggregated_trends[coin] = {
                        "total_mentions": 0,
                        "sources": []
                    }
                
                self.aggregated_trends[coin]["total_mentions"] += count
                self.aggregated_trends[coin]["sources"].append("Twitter")
                
                # Add sentiment if available
                sentiment = self.twitter_monitor.get_coin_sentiment(coin)
                if sentiment:
                    self.aggregated_trends[coin]["sentiment"] = sentiment["sentiment_score"]
                    self.aggregated_trends[coin]["is_positive"] = sentiment["is_positive"]
            
            # Add other social media platforms here
            
            logger.info(f"Aggregated trends updated with {len(self.aggregated_trends)} coins")
        
        except Exception as e:
            logger.error(f"Error aggregating trends: {e}", exc_info=True)
    
    def get_aggregated_trends(self, limit=10):
        """Get the aggregated trends from all social media platforms"""
        # Convert to list and sort by total mentions
        trends = [
            {
                "coin": coin,
                "data": data
            }
            for coin, data in self.aggregated_trends.items()
        ]
        
        trends.sort(key=lambda x: x["data"]["total_mentions"], reverse=True)
        
        return trends[:limit]
    
    def get_coin_social_data(self, coin):
        """Get social media data for a specific coin"""
        return self.aggregated_trends.get(coin.upper())
