"""
DexScreener API Integration Module

This module connects to DexScreener's API to fetch real-time token data,
analyze tokens for signs of being "rugged" or "pumped", and track new token pairs.
"""

import os
import json
import time
import logging
import asyncio
import websocket
import requests
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class DexScreenerAPI:
    """Class for interacting with DexScreener API and processing token data"""
    
    def __init__(self):
        """Initialize the DexScreener API client"""
        self.api_key = config.DEXSCREENER_API_KEY
        self.base_url = "https://api.dexscreener.com/latest"
        self.ws_url = "wss://api.dexscreener.com/ws"
        self.ws = None
        self.running = False
        self.tracked_tokens = {}
        self.new_pairs = []
        self.rugged_tokens = []
        self.pumped_tokens = []
        
        # Define thresholds for rug and pump detection
        self.rug_liquidity_drop_pct = 0.5  # 50% liquidity drop
        self.rug_price_drop_pct = 0.3      # 30% price drop
        self.pump_price_increase_pct = 0.2  # 20% price increase
        self.pump_volume_increase_pct = 1.0  # 100% volume increase
        
        logger.info("DexScreener API client initialized")
    
    async def start_monitoring(self):
        """Start monitoring token data"""
        logger.info("Starting DexScreener monitoring")
        self.running = True
        
        # Start websocket connection in a separate task
        asyncio.create_task(self._websocket_listener())
        
        # Start periodic REST API polling for tokens not available via websocket
        asyncio.create_task(self._periodic_polling())
        
        logger.info("DexScreener monitoring started")
    
    async def stop_monitoring(self):
        """Stop monitoring token data"""
        logger.info("Stopping DexScreener monitoring")
        self.running = False
        if self.ws:
            self.ws.close()
        logger.info("DexScreener monitoring stopped")
    
    async def _websocket_listener(self):
        """Listen for real-time updates via websocket"""
        while self.running:
            try:
                # Connect to websocket
                self.ws = websocket.WebSocketApp(
                    self.ws_url,
                    on_message=self._on_message,
                    on_error=self._on_error,
                    on_close=self._on_close,
                    on_open=self._on_open
                )
                
                # Run websocket connection (this is blocking)
                self.ws.run_forever()
                
                # If we get here, the connection was closed
                if self.running:
                    logger.warning("WebSocket connection closed, reconnecting in 5 seconds...")
                    await asyncio.sleep(5)
            except Exception as e:
                logger.error(f"WebSocket error: {e}", exc_info=True)
                await asyncio.sleep(5)
    
    def _on_open(self, ws):
        """Called when websocket connection is opened"""
        logger.info("WebSocket connection opened")
        
        # Subscribe to token updates
        subscription_msg = {
            "type": "subscribe",
            "pairs": ["ethereum:0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"]  # WETH as an example
        }
        ws.send(json.dumps(subscription_msg))
    
    def _on_message(self, ws, message):
        """Called when a message is received from the websocket"""
        try:
            data = json.loads(message)
            self._process_token_data(data)
        except Exception as e:
            logger.error(f"Error processing websocket message: {e}", exc_info=True)
    
    def _on_error(self, ws, error):
        """Called when a websocket error occurs"""
        logger.error(f"WebSocket error: {error}")
    
    def _on_close(self, ws, close_status_code, close_msg):
        """Called when websocket connection is closed"""
        logger.info(f"WebSocket connection closed: {close_status_code} - {close_msg}")
    
    async def _periodic_polling(self):
        """Periodically poll the REST API for token data"""
        while self.running:
            try:
                # Get trending pairs
                trending_pairs = await self._get_trending_pairs()
                for pair in trending_pairs:
                    self._process_token_data(pair)
                
                # Get recently added pairs
                new_pairs = await self._get_new_pairs()
                for pair in new_pairs:
                    if pair["pairAddress"] not in [p["pairAddress"] for p in self.new_pairs]:
                        self.new_pairs.append(pair)
                        logger.info(f"New pair detected: {pair['baseToken']['symbol']}/{pair['quoteToken']['symbol']}")
                
                # Sleep before next polling
                await asyncio.sleep(60)  # Poll every minute
            except Exception as e:
                logger.error(f"Error in periodic polling: {e}", exc_info=True)
                await asyncio.sleep(60)
    
    async def _get_trending_pairs(self):
        """Get trending pairs from DexScreener API"""
        url = f"{self.base_url}/dex/trending"
        headers = {"X-API-KEY": self.api_key} if self.api_key else {}
        
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            return data.get("pairs", [])
        except Exception as e:
            logger.error(f"Error fetching trending pairs: {e}", exc_info=True)
            return []
    
    async def _get_new_pairs(self):
        """Get newly added pairs from DexScreener API"""
        # For multiple chains
        chains = ["ethereum", "bsc", "polygon", "arbitrum"]
        all_pairs = []
        
        for chain in chains:
            url = f"{self.base_url}/dex/pairs/{chain}"
            headers = {"X-API-KEY": self.api_key} if self.api_key else {}
            
            try:
                response = requests.get(url, headers=headers)
                response.raise_for_status()
                data = response.json()
                
                # Filter for pairs created in the last hour
                one_hour_ago = datetime.now() - timedelta(hours=1)
                recent_pairs = [
                    pair for pair in data.get("pairs", [])
                    if "pairCreatedAt" in pair and 
                    datetime.fromtimestamp(pair["pairCreatedAt"]/1000) > one_hour_ago
                ]
                
                all_pairs.extend(recent_pairs)
            except Exception as e:
                logger.error(f"Error fetching new pairs for {chain}: {e}", exc_info=True)
        
        return all_pairs
    
    async def get_token_data(self, token_address, chain="ethereum"):
        """Get data for a specific token"""
        url = f"{self.base_url}/dex/tokens/{chain}/{token_address}"
        headers = {"X-API-KEY": self.api_key} if self.api_key else {}
        
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            return data.get("pairs", [])
        except Exception as e:
            logger.error(f"Error fetching token data: {e}", exc_info=True)
            return []
    
    def _process_token_data(self, data):
        """Process token data to detect rugs, pumps, and track metrics"""
        try:
            # Extract key metrics
            pair_address = data.get("pairAddress")
            if not pair_address:
                return
            
            # Get previous data if we've seen this token before
            prev_data = self.tracked_tokens.get(pair_address)
            
            # Update tracked tokens with new data
            self.tracked_tokens[pair_address] = data
            
            # Skip further processing if we don't have previous data
            if not prev_data:
                return
            
            # Check for rug pull (significant liquidity or price drop)
            if self._is_rug_pull(prev_data, data):
                self.rugged_tokens.append(data)
                logger.warning(f"Potential rug pull detected: {data['baseToken']['symbol']}")
            
            # Check for pump (significant price increase)
            if self._is_pump(prev_data, data):
                self.pumped_tokens.append(data)
                logger.info(f"Potential pump detected: {data['baseToken']['symbol']}")
        
        except Exception as e:
            logger.error(f"Error processing token data: {e}", exc_info=True)
    
    def _is_rug_pull(self, prev_data, current_data):
        """Detect if a token is being rugged"""
        try:
            # Check liquidity drop
            prev_liquidity = float(prev_data.get("liquidity", {}).get("usd", 0))
            current_liquidity = float(current_data.get("liquidity", {}).get("usd", 0))
            
            if prev_liquidity > 0 and current_liquidity > 0:
                liquidity_drop_pct = (prev_liquidity - current_liquidity) / prev_liquidity
                
                # Check price drop
                prev_price = float(prev_data.get("priceUsd", 0))
                current_price = float(current_data.get("priceUsd", 0))
                
                if prev_price > 0 and current_price > 0:
                    price_drop_pct = (prev_price - current_price) / prev_price
                    
                    # Detect rug if both liquidity and price dropped significantly
                    if (liquidity_drop_pct > self.rug_liquidity_drop_pct and 
                        price_drop_pct > self.rug_price_drop_pct):
                        return True
        
        except Exception as e:
            logger.error(f"Error in rug detection: {e}", exc_info=True)
        
        return False
    
    def _is_pump(self, prev_data, current_data):
        """Detect if a token is being pumped"""
        try:
            # Check price increase
            prev_price = float(prev_data.get("priceUsd", 0))
            current_price = float(current_data.get("priceUsd", 0))
            
            if prev_price > 0 and current_price > 0:
                price_increase_pct = (current_price - prev_price) / prev_price
                
                # Check volume increase
                prev_volume = float(prev_data.get("volume", {}).get("h24", 0))
                current_volume = float(current_data.get("volume", {}).get("h24", 0))
                
                if prev_volume > 0 and current_volume > 0:
                    volume_increase_pct = (current_volume - prev_volume) / prev_volume
                    
                    # Detect pump if both price and volume increased significantly
                    if (price_increase_pct > self.pump_price_increase_pct and 
                        volume_increase_pct > self.pump_volume_increase_pct):
                        return True
        
        except Exception as e:
            logger.error(f"Error in pump detection: {e}", exc_info=True)
        
        return False
    
    def get_rugged_tokens(self):
        """Get list of tokens detected as rugged"""
        return self.rugged_tokens
    
    def get_pumped_tokens(self):
        """Get list of tokens detected as pumped"""
        return self.pumped_tokens
    
    def get_new_token_pairs(self):
        """Get list of newly detected token pairs"""
        return self.new_pairs
