"""
Blockchain Analysis Module

This module retrieves blockchain data to extract token holder information
and implements a scam checker to flag tokens with abnormal holder distributions.
"""

import os
import json
import time
import logging
import asyncio
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
from web3 import Web3
import requests

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

# Standard ERC20 ABI for token interactions
ERC20_ABI = [
    {
        "constant": True,
        "inputs": [],
        "name": "name",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "symbol",
        "outputs": [{"name": "", "type": "string"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "totalSupply",
        "outputs": [{"name": "", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [{"name": "_to", "type": "address"}, {"name": "_value", "type": "uint256"}],
        "name": "transfer",
        "outputs": [{"name": "", "type": "bool"}],
        "payable": False,
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}, {"name": "_spender", "type": "address"}],
        "name": "allowance",
        "outputs": [{"name": "", "type": "uint256"}],
        "payable": False,
        "stateMutability": "view",
        "type": "function"
    }
]

class BlockchainAnalyzer:
    """Class for analyzing blockchain data and token holders"""
    
    def __init__(self):
        """Initialize the blockchain analyzer"""
        # Initialize Web3 connections for different chains
        self.eth_w3 = Web3(Web3.HTTPProvider(config.ETH_RPC_URL))
        self.bsc_w3 = Web3(Web3.HTTPProvider(config.BSC_RPC_URL))
        self.polygon_w3 = Web3(Web3.HTTPProvider(config.POLYGON_RPC_URL))
        
        # API keys for blockchain explorers
        self.etherscan_api_key = config.ETHERSCAN_API_KEY
        self.bscscan_api_key = config.BSC_SCAN_API_KEY
        
        # Cache for token data
        self.token_cache = {}
        
        # Scam detection parameters
        self.min_holders_count = config.MIN_HOLDERS_COUNT
        self.min_liquidity_usd = config.MIN_LIQUIDITY_USD
        self.min_holder_age_days = config.MIN_HOLDER_AGE_DAYS
        
        logger.info("Blockchain analyzer initialized")
    
    async def analyze_token(self, token_address, chain="ethereum"):
        """Analyze a token on the specified blockchain"""
        logger.info(f"Analyzing token {token_address} on {chain}")
        
        try:
            # Get the appropriate Web3 instance for the chain
            w3 = self._get_web3_for_chain(chain)
            if not w3:
                logger.error(f"Unsupported chain: {chain}")
                return None
            
            # Check if token exists and is a valid contract
            if not w3.eth.get_code(Web3.to_checksum_address(token_address)):
                logger.warning(f"Token {token_address} is not a valid contract")
                return None
            
            # Get token contract
            token_contract = w3.eth.contract(
                address=Web3.to_checksum_address(token_address),
                abi=ERC20_ABI
            )
            
            # Get basic token info
            token_info = await self._get_token_info(token_contract)
            
            # Get holder information
            holders_info = await self._get_token_holders(token_address, chain)
            
            # Analyze holder distribution
            distribution_analysis = self._analyze_holder_distribution(holders_info)
            
            # Check for scam indicators
            scam_check = self._check_scam_indicators(token_info, holders_info, distribution_analysis)
            
            # Combine all data
            analysis_result = {
                "token_info": token_info,
                "holders_info": holders_info,
                "distribution_analysis": distribution_analysis,
                "scam_check": scam_check
            }
            
            # Cache the result
            self.token_cache[f"{chain}:{token_address}"] = {
                "timestamp": datetime.now(),
                "data": analysis_result
            }
            
            return analysis_result
        
        except Exception as e:
            logger.error(f"Error analyzing token {token_address}: {e}", exc_info=True)
            return None
    
    def _get_web3_for_chain(self, chain):
        """Get the appropriate Web3 instance for the specified chain"""
        chain = chain.lower()
        if chain == "ethereum":
            return self.eth_w3
        elif chain == "bsc":
            return self.bsc_w3
        elif chain == "polygon":
            return self.polygon_w3
        else:
            return None
    
    async def _get_token_info(self, token_contract):
        """Get basic information about a token from its contract"""
        try:
            name = token_contract.functions.name().call()
            symbol = token_contract.functions.symbol().call()
            decimals = token_contract.functions.decimals().call()
            total_supply = token_contract.functions.totalSupply().call() / (10 ** decimals)
            
            return {
                "name": name,
                "symbol": symbol,
                "decimals": decimals,
                "total_supply": total_supply
            }
        
        except Exception as e:
            logger.error(f"Error getting token info: {e}", exc_info=True)
            return {
                "name": "Unknown",
                "symbol": "Unknown",
                "decimals": 18,
                "total_supply": 0
            }
    
    async def _get_token_holders(self, token_address, chain="ethereum"):
        """Get information about token holders from blockchain explorer APIs"""
        api_url = self._get_explorer_api_url(chain)
        api_key = self._get_explorer_api_key(chain)
        
        if not api_url or not api_key:
            logger.error(f"No API configuration for chain: {chain}")
            return []
        
        try:
            # Use blockchain explorer API to get token holders
            params = {
                "module": "token",
                "action": "tokenholderlist",
                "contractaddress": token_address,
                "page": 1,
                "offset": 100,  # Get top 100 holders
                "apikey": api_key
            }
            
            response = requests.get(api_url, params=params)
            data = response.json()
            
            if data["status"] != "1":
                logger.warning(f"API error: {data.get('message', 'Unknown error')}")
                return []
            
            holders = data.get("result", [])
            
            # Get additional data for each holder
            for holder in holders:
                # Convert balance to token amount using decimals
                decimals = int(holder.get("TokenDivisor", "18").replace("1e", ""))
                balance = float(holder.get("TokenHolderQuantity", 0)) / (10 ** decimals)
                holder["balance"] = balance
                
                # Get first transaction timestamp if available
                holder["first_tx_timestamp"] = await self._get_first_transaction_time(
                    holder["TokenHolderAddress"], 
                    token_address, 
                    chain
                )
            
            return holders
        
        except Exception as e:
            logger.error(f"Error getting token holders: {e}", exc_info=True)
            return []
    
    async def _get_first_transaction_time(self, holder_address, token_address, chain="ethereum"):
        """Get the timestamp of the first transaction for a holder with this token"""
        api_url = self._get_explorer_api_url(chain)
        api_key = self._get_explorer_api_key(chain)
        
        if not api_url or not api_key:
            return None
        
        try:
            # Use blockchain explorer API to get token transfer events
            params = {
                "module": "account",
                "action": "tokentx",
                "contractaddress": token_address,
                "address": holder_address,
                "page": 1,
                "offset": 1,
                "sort": "asc",  # Oldest first
                "apikey": api_key
            }
            
            response = requests.get(api_url, params=params)
            data = response.json()
            
            if data["status"] != "1" or not data.get("result"):
                return None
            
            # Get timestamp of first transaction
            first_tx = data["result"][0]
            timestamp = int(first_tx.get("timeStamp", 0))
            
            return datetime.fromtimestamp(timestamp) if timestamp > 0 else None
        
        except Exception as e:
            logger.error(f"Error getting first transaction time: {e}", exc_info=True)
            return None
    
    def _get_explorer_api_url(self, chain):
        """Get the API URL for the specified blockchain explorer"""
        chain = chain.lower()
        if chain == "ethereum":
            return "https://api.etherscan.io/api"
        elif chain == "bsc":
            return "https://api.bscscan.com/api"
        elif chain == "polygon":
            return "https://api.polygonscan.com/api"
        else:
            return None
    
    def _get_explorer_api_key(self, chain):
        """Get the API key for the specified blockchain explorer"""
        chain = chain.lower()
        if chain == "ethereum":
            return self.etherscan_api_key
        elif chain == "bsc":
            return self.bscscan_api_key
        else:
            return None
    
    def _analyze_holder_distribution(self, holders):
        """Analyze the distribution of token holders"""
        if not holders:
            return {
                "total_holders": 0,
                "concentration_ratio": 0,
                "top10_percentage": 0,
                "avg_holding_time_days": 0
            }
        
        try:
            # Calculate total holders
            total_holders = len(holders)
            
            # Calculate total tokens held
            total_tokens_held = sum(holder["balance"] for holder in holders)
            
            # Calculate concentration ratio (percentage held by top 10 holders)
            top10_holders = sorted(holders, key=lambda x: x["balance"], reverse=True)[:10]
            top10_tokens = sum(holder["balance"] for holder in top10_holders)
            top10_percentage = (top10_tokens / total_tokens_held) * 100 if total_tokens_held > 0 else 0
            
            # Calculate Gini coefficient (measure of inequality)
            sorted_balances = sorted([holder["balance"] for holder in holders])
            n = len(sorted_balances)
            gini = sum((2 * i - n - 1) * b for i, b in enumerate(sorted_balances)) / (n * sum(sorted_balances)) if n > 0 and sum(sorted_balances) > 0 else 0
            
            # Calculate average holding time
            now = datetime.now()
            holding_times = []
            
            for holder in holders:
                first_tx_time = holder.get("first_tx_timestamp")
                if first_tx_time:
                    holding_days = (now - first_tx_time).days
                    holding_times.append(holding_days)
            
            avg_holding_time_days = sum(holding_times) / len(holding_times) if holding_times else 0
            
            return {
                "total_holders": total_holders,
                "concentration_ratio": top10_percentage,
                "gini_coefficient": gini,
                "avg_holding_time_days": avg_holding_time_days
            }
        
        except Exception as e:
            logger.error(f"Error analyzing holder distribution: {e}", exc_info=True)
            return {
                "total_holders": len(holders),
                "concentration_ratio": 0,
                "gini_coefficient": 0,
                "avg_holding_time_days": 0
            }
    
    def _check_scam_indicators(self, token_info, holders, distribution):
        """Check for indicators that a token might be a scam"""
        scam_indicators = []
        scam_score = 0
        
        try:
            # Check number of holders
            if distribution["total_holders"] < self.min_holders_count:
                scam_indicators.append("Low holder count")
                scam_score += 25
            
            # Check concentration ratio
            if distribution["concentration_ratio"] > 80:  # More than 80% held by top 10
                scam_indicators.append("High concentration of tokens")
                scam_score += 20
            
            # Check average holding time
            if distribution["avg_holding_time_days"] < self.min_holder_age_days:
                scam_indicators.append("Very new token/holders")
                scam_score += 15
            
            # Check for contract issues (would require more detailed analysis)
            # This is a placeholder for more sophisticated contract analysis
            
            # Normalize scam score to 0-100 range
            scam_score = min(scam_score, 100)
            
            return {
                "is_potential_scam": scam_score > 50,
                "scam_score": scam_score,
                "scam_indicators": scam_indicators
            }
        
        except Exception as e:
            logger.error(f"Error checking scam indicators: {e}", exc_info=True)
            return {
                "is_potential_scam": False,
                "scam_score": 0,
                "scam_indicators": ["Error in scam detection"]
            }
    
    async def check_token_scam(self, token_address, chain="ethereum"):
        """Check if a token has scam indicators"""
        # Check cache first
        cache_key = f"{chain}:{token_address}"
        if cache_key in self.token_cache:
            cache_entry = self.token_cache[cache_key]
            cache_age = (datetime.now() - cache_entry["timestamp"]).total_seconds() / 3600
            
            # Use cache if less than 1 hour old
            if cache_age < 1:
                return cache_entry["data"]["scam_check"]
        
        # Analyze token if not in cache or cache is old
        analysis = await self.analyze_token(token_address, chain)
        if not analysis:
            return {
                "is_potential_scam": True,
                "scam_score": 100,
                "scam_indicators": ["Unable to analyze token"]
            }
        
        return analysis["scam_check"]
    
    async def get_holder_count(self, token_address, chain="ethereum"):
        """Get the number of holders for a token"""
        # Check cache first
        cache_key = f"{chain}:{token_address}"
        if cache_key in self.token_cache:
            cache_entry = self.token_cache[cache_key]
            cache_age = (datetime.now() - cache_entry["timestamp"]).total_seconds() / 3600
            
            # Use cache if less than 1 hour old
            if cache_age < 1:
                return cache_entry["data"]["distribution_analysis"]["total_holders"]
        
        # Analyze token if not in cache or cache is old
        analysis = await self.analyze_token(token_address, chain)
        if not analysis:
            return 0
        
        return analysis["distribution_analysis"]["total_holders"]
    
    async def get_token_age(self, token_address, chain="ethereum"):
        """Get the age of a token in days"""
        api_url = self._get_explorer_api_url(chain)
        api_key = self._get_explorer_api_key(chain)
        
        if not api_url or not api_key:
            return 0
        
        try:
            # Use blockchain explorer API to get contract creation info
            params = {
                "module": "contract",
                "action": "getcontractcreation",
                "contractaddresses": token_address,
                "apikey": api_key
            }
            
            response = requests.get(api_url, params=params)
            data = response.json()
            
            if data["status"] != "1" or not data.get("result"):
                return 0
            
            # Get creation transaction
            creation_tx = data["result"][0]["txHash"]
            
            # Get transaction details
            params = {
                "module": "proxy",
                "action": "eth_getTransactionByHash",
                "txhash": creation_tx,
                "apikey": api_key
            }
            
            response = requests.get(api_url, params=params)
            tx_data = response.json()
            
            if "result" not in tx_data or not tx_data["result"]:
                return 0
            
            # Get block details
            block_number = int(tx_data["result"]["blockNumber"], 16)
            
            params = {
                "module": "block",
                "action": "getblockreward",
                "blockno": block_number,
                "apikey": api_key
            }
            
            response = requests.get(api_url, params=params)
            block_data = response.json()
            
            if data["status"] != "1" or not block_data.get("result"):
                return 0
            
            # Calculate age in days
            timestamp = int(block_data["result"]["timeStamp"])
            creation_date = datetime.fromtimestamp(timestamp)
            age_days = (datetime.now() - creation_date).days
            
            return max(0, age_days)
        
        except Exception as e:
            logger.error(f"Error getting token age: {e}", exc_info=True)
            return 0


class ScamChecker:
    """Class for checking if tokens are potential scams"""
    
    def __init__(self, blockchain_analyzer):
        """Initialize the scam checker"""
        self.blockchain_analyzer = blockchain_analyzer
        self.scam_database = {}  # Would be a database of known scams
        
        logger.info("Scam checker initialized")
    
    async def check_token(self, token_address, chain="ethereum", liquidity_usd=0):
        """Check if a token is a potential scam"""
        try:
            # Check if token is in known scam database
            if f"{chain}:{token_address}" in self.scam_database:
                return {
                    "is_scam": True,
                    "confidence": 100,
                    "reason": "Known scam token"
                }
            
            # Check blockchain indicators
            scam_check = await self.blockchain_analyzer.check_token_scam(token_address, chain)
            
            # Check liquidity
            if liquidity_usd < config.MIN_LIQUIDITY_USD:
                if "scam_indicators" not in scam_check:
                    scam_check["scam_indicators"] = []
                scam_check["scam_indicators"].append("Low liquidity")
                scam_check["scam_score"] += 15
                scam_check["scam_score"] = min(scam_check["scam_score"], 100)
                scam_check["is_potential_scam"] = scam_check["scam_score"] > 50
            
            # Get token age
            token_age = await self.blockchain_analyzer.get_token_age(token_address, chain)
            if token_age < 7:  # Less than a week old
                if "scam_indicators" not in scam_check:
                    scam_check["scam_indicators"] = []
                scam_check["scam_indicators"].append(f"Very new token ({token_age} days)")
                scam_check["scam_score"] += 10
                scam_check["scam_score"] = min(scam_check["scam_score"], 100)
                scam_check["is_potential_scam"] = scam_check["scam_score"] > 50
            
            return {
                "is_scam": scam_check["is_potential_scam"],
                "confidence": scam_check["scam_score"],
                "indicators": scam_check["scam_indicators"],
                "token_age_days": token_age
            }
        
        except Exception as e:
            logger.error(f"Error checking token scam status: {e}", exc_info=True)
            return {
                "is_scam": False,
                "confidence": 0,
                "indicators": ["Error in scam detection"],
                "token_age_days": 0
            }
