#!/bin/bash
# Installation script for Crypto Alert Bot on Android (Termux)

echo "===== Crypto Alert Bot Installation Script for Android ====="
echo "This script will install the Crypto Alert Bot on your Android device using Termux."
echo "Make sure you have Termux installed from the Google Play Store or F-Droid."
echo ""

# Update and upgrade packages
echo "Updating Termux packages..."
pkg update -y && pkg upgrade -y

# Install required packages
echo "Installing required packages..."
pkg install -y python git libxml2 libxslt libjpeg-turbo

# Create directory for the bot
echo "Creating directory for the bot..."
mkdir -p ~/crypto-alert-bot
cd ~/crypto-alert-bot

# Copy all files from the current directory
echo "Setting up bot files..."
cp -r /home/ubuntu/crypto_alert_bot/* .

# Install Python dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating .env file..."
    cp .env.template .env
    echo "Please edit the .env file with your API keys and settings."
    echo "You can do this by running: nano .env"
fi

echo ""
echo "===== Installation Complete ====="
echo ""
echo "To run the bot, use the following command:"
echo "cd ~/crypto-alert-bot && python main.py"
echo ""
echo "To keep the bot running when you close Termux:"
echo "1. Install Termux:API from the same source you got Termux"
echo "2. Run: pkg install termux-api"
echo "3. Start the bot with: nohup python main.py > bot.log 2>&1 &"
echo ""
echo "To view logs: cat bot.log"
echo "To stop the bot: pkill -f 'python main.py'"
echo ""
echo "Remember to disable battery optimization for Termux in your Android settings!"
echo "Settings > Apps > Termux > Battery > Unrestricted"
