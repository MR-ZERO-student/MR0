"""
Message Formatter Module

This module creates visually enhanced messages for Telegram alerts
with icons, formatting, and visual elements.
"""

import logging
from datetime import datetime
import os
import io
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.figure import Figure
from PIL import Image, ImageDraw, ImageFont

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class MessageFormatter:
    """Class for formatting visually appealing Telegram messages"""
    
    def __init__(self):
        """Initialize the message formatter"""
        self.use_emojis = config.USE_EMOJIS
        
        # Define emoji sets
        self.emojis = {
            'buy': '🟢',
            'sell': '🔴',
            'neutral': '⚪',
            'price': '💰',
            'time': '⏰',
            'chart': '📊',
            'up': '📈',
            'down': '📉',
            'alert': '🚨',
            'risk_low': '🟢',
            'risk_medium': '🟡',
            'risk_high': '🟠',
            'risk_very_high': '🔴',
            'target': '🎯',
            'wallet': '👛',
            'rocket': '🚀',
            'fire': '🔥',
            'ice': '❄️',
            'warning': '⚠️',
            'check': '✅',
            'cross': '❌'
        }
        
        logger.info("Message formatter initialized")
    
    def format_alert_message(self, alert_data):
        """
        Format an alert message with visual enhancements
        
        Args:
            alert_data: Alert data with signal information
            
        Returns:
            str: Formatted message
        """
        try:
            # Get signal type
            signal = alert_data.get('signal', 0)
            signal_type = "BUY" if signal > 0 else "SELL" if signal < 0 else "NEUTRAL"
            
            # Get emojis
            if self.use_emojis:
                if signal_type == "BUY":
                    signal_emoji = self.emojis['buy']
                    trend_emoji = self.emojis['up']
                elif signal_type == "SELL":
                    signal_emoji = self.emojis['sell']
                    trend_emoji = self.emojis['down']
                else:
                    signal_emoji = self.emojis['neutral']
                    trend_emoji = ""
            else:
                signal_emoji = ""
                trend_emoji = ""
            
            # Format header
            symbol = alert_data.get('symbol', 'Unknown')
            header = f"{signal_emoji} <b>{signal_type} SIGNAL: {symbol}</b> {signal_emoji}\n\n"
            
            # Format price information
            price = alert_data.get('price', 0)
            price_emoji = self.emojis['price'] if self.use_emojis else ""
            price_info = f"{price_emoji} Current Price: <b>${price:.4f}</b>\n"
            
            # Format technical indicators
            chart_emoji = self.emojis['chart'] if self.use_emojis else ""
            indicators = (
                f"{chart_emoji} <u>Technical Indicators:</u>\n"
                f"• Trend Strength: <b>{alert_data.get('trend_strength', 0):.1f}%</b>\n"
                f"• Signal Confidence: <b>{alert_data.get('confidence', 0):.1f}%</b>\n"
            )
            
            # Add more indicators if available
            if 'stoch_rsi_k' in alert_data:
                indicators += f"• Stoch RSI: <b>{alert_data['stoch_rsi_k']:.1f}</b>\n"
            
            if 'macd_histogram' in alert_data:
                indicators += f"• MACD Histogram: <b>{alert_data['macd_histogram']:.4f}</b>\n"
            
            # Format risk management
            if 'stop_loss' in alert_data and 'take_profit' in alert_data:
                target_emoji = self.emojis['target'] if self.use_emojis else ""
                risk_info = (
                    f"{target_emoji} <u>Risk Management:</u>\n"
                    f"• Stop Loss: <b>${alert_data['stop_loss']:.4f}</b>\n"
                    f"• Take Profit: <b>${alert_data['take_profit']:.4f}</b>\n"
                )
                
                # Add risk-reward ratio if available
                if 'risk_reward_ratio' in alert_data:
                    risk_info += f"• Risk-Reward Ratio: <b>{alert_data['risk_reward_ratio']:.2f}</b>\n"
            else:
                risk_info = ""
            
            # Format position sizing if available
            if 'position_size_units' in alert_data and 'position_size_currency' in alert_data:
                wallet_emoji = self.emojis['wallet'] if self.use_emojis else ""
                position_info = (
                    f"{wallet_emoji} <u>Position Sizing:</u>\n"
                    f"• Recommended Position: <b>{alert_data['position_size_units']:.4f} units</b>\n"
                    f"• Position Value: <b>${alert_data['position_size_currency']:.2f}</b>\n"
                )
                
                # Add capital percentage if available
                if 'capital_percentage' in alert_data:
                    position_info += f"• Capital Percentage: <b>{alert_data['capital_percentage']:.2f}%</b>\n"
            else:
                position_info = ""
            
            # Format risk score if available
            if 'risk_score' in alert_data and 'risk_level' in alert_data:
                risk_level = alert_data['risk_level']
                
                # Get risk emoji based on level
                if self.use_emojis:
                    if risk_level == "Low":
                        risk_emoji = self.emojis['risk_low']
                    elif risk_level == "Medium":
                        risk_emoji = self.emojis['risk_medium']
                    elif risk_level == "High":
                        risk_emoji = self.emojis['risk_high']
                    else:
                        risk_emoji = self.emojis['risk_very_high']
                else:
                    risk_emoji = ""
                
                risk_score_info = (
                    f"{risk_emoji} <u>Risk Assessment:</u>\n"
                    f"• Risk Score: <b>{alert_data['risk_score']:.1f}/100</b>\n"
                    f"• Risk Level: <b>{risk_level}</b>\n"
                )
            else:
                risk_score_info = ""
            
            # Format timestamp
            timestamp = alert_data.get('timestamp', datetime.now())
            time_emoji = self.emojis['time'] if self.use_emojis else ""
            time_info = f"\n{time_emoji} Alert Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
            
            # Format footer
            footer = "\n<i>Use buttons below for price alerts, reminders, or to share this signal</i>"
            
            # Combine all sections
            message = header + price_info + "\n" + indicators + "\n" + risk_info + position_info + risk_score_info + time_info + footer
            
            return message
        
        except Exception as e:
            logger.error(f"Error formatting alert message: {e}", exc_info=True)
            return f"Alert for {alert_data.get('symbol', 'Unknown')}"
    
    def format_reminder_message(self, reminder_data):
        """
        Format a reminder message with visual enhancements
        
        Args:
            reminder_data: Reminder data
            
        Returns:
            str: Formatted message
        """
        try:
            # Get reminder type and symbol
            reminder_type = reminder_data.get('type', 'general')
            symbol = reminder_data.get('symbol', 'Unknown')
            
            # Choose emoji based on reminder type
            if self.use_emojis:
                if reminder_type == 'price_target':
                    type_emoji = self.emojis['target']
                elif reminder_type == 'time':
                    type_emoji = self.emojis['time']
                else:
                    type_emoji = self.emojis['alert']
            else:
                type_emoji = ""
            
            # Format header
            header = f"{type_emoji} <b>REMINDER: {symbol}</b> {type_emoji}\n\n"
            
            # Format message based on reminder type
            if reminder_type == 'price_target':
                target_price = reminder_data.get('target_price', 0)
                current_price = reminder_data.get('current_price', 0)
                
                # Determine if price went up or down
                if 'original_price' in reminder_data:
                    original_price = reminder_data['original_price']
                    price_change = ((current_price / original_price) - 1) * 100
                    
                    if price_change > 0:
                        change_emoji = self.emojis['up'] if self.use_emojis else ""
                        change_text = f"up <b>{price_change:.2f}%</b>"
                    else:
                        change_emoji = self.emojis['down'] if self.use_emojis else ""
                        change_text = f"down <b>{abs(price_change):.2f}%</b>"
                    
                    price_change_info = f"{change_emoji} Price has moved {change_text} since original alert.\n"
                else:
                    price_change_info = ""
                
                price_emoji = self.emojis['price'] if self.use_emojis else ""
                target_emoji = self.emojis['target'] if self.use_emojis else ""
                
                message = (
                    f"{target_emoji} Price target of <b>${target_price:.4f}</b> has been reached!\n"
                    f"{price_emoji} Current price: <b>${current_price:.4f}</b>\n"
                    f"{price_change_info}"
                )
            elif reminder_type == 'time':
                hours = reminder_data.get('hours', 0)
                time_emoji = self.emojis['time'] if self.use_emojis else ""
                
                message = (
                    f"{time_emoji} It's been {hours} hours since the original alert.\n"
                )
                
                # Add original signal if available
                if 'original_signal' in reminder_data:
                    signal_type = reminder_data['original_signal']
                    if signal_type == "BUY":
                        signal_emoji = self.emojis['buy'] if self.use_emojis else ""
                    elif signal_type == "SELL":
                        signal_emoji = self.emojis['sell'] if self.use_emojis else ""
                    else:
                        signal_emoji = self.emojis['neutral'] if self.use_emojis else ""
                    
                    message += f"{signal_emoji} Original signal: <b>{signal_type}</b>\n"
                
                # Add price change if available
                if 'original_price' in reminder_data and 'current_price' in reminder_data:
                    original_price = reminder_data['original_price']
                    current_price = reminder_data['current_price']
                    price_change = ((current_price / original_price) - 1) * 100
                    
                    price_emoji = self.emojis['price'] if self.use_emojis else ""
                    
                    if price_change > 0:
                        change_emoji = self.emojis['up'] if self.use_emojis else ""
                        message += f"{price_emoji} Original price: <b>${original_price:.4f}</b>\n"
                        message += f"{price_emoji} Current price: <b>${current_price:.4f}</b>\n"
                        message += f"{change_emoji} Price change: <b>+{price_change:.2f}%</b>\n"
                    else:
                        change_emoji = self.emojis['down'] if self.use_emojis else ""
                        message += f"{price_emoji} Original price: <b>${original_price:.4f}</b>\n"
                        message += f"{price_emoji} Current price: <b>${current_price:.4f}</b>\n"
                        message += f"{change_emoji} Price change: <b>{price_change:.2f}%</b>\n"
            else:
                alert_emoji = self.emojis['alert'] if self.use_emojis else ""
                message = f"{alert_emoji} {reminder_data.get('message', 'General reminder for this cryptocurrency.')}"
            
            # Format timestamp
            timestamp = datetime.now()
            time_emoji = self.emojis['time'] if self.use_emojis else ""
            time_info = f"\n{time_emoji} Reminder Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
            
            # Combine all sections
            full_message = header + message + time_info
            
            return full_message
        
        except Exception as e:
            logger.error(f"Error formatting reminder message: {e}", exc_info=True)
            return f"Reminder for {reminder_data.get('symbol', 'Unknown')}"
    
    def create_coin_rating_image(self, rating_data, save_path=None):
        """
        Create a visual coin rating image
        
        Args:
            rating_data: Dictionary with rating information
            save_path: Path to save the image (optional)
            
        Returns:
            str: Path to saved image
        """
        try:
            # Create a new image
            width, height = 800, 400
            image = Image.new('RGB', (width, height), color=(255, 255, 255))
            draw = ImageDraw.Draw(image)
            
            # Try to load a font, use default if not available
            try:
                title_font = ImageFont.truetype("Arial.ttf", 36)
                header_font = ImageFont.truetype("Arial.ttf", 24)
                text_font = ImageFont.truetype("Arial.ttf", 18)
            except IOError:
                title_font = ImageFont.load_default()
                header_font = ImageFont.load_default()
                text_font = ImageFont.load_default()
            
            # Draw title
            symbol = rating_data.get('symbol', 'Unknown')
            draw.text((width/2, 30), f"Coin Rating: {symbol}", fill=(0, 0, 0), font=title_font, anchor="mm")
            
            # Draw overall score
            overall_score = rating_data.get('overall_score', 0)
            
            # Determine color based on score
            if overall_score >= 80:
                score_color = (0, 150, 0)  # Green
            elif overall_score >= 60:
                score_color = (255, 165, 0)  # Orange
            elif overall_score >= 40:
                score_color = (255, 140, 0)  # Dark Orange
            else:
                score_color = (255, 0, 0)  # Red
            
            # Draw score circle
            circle_center = (width/2, 120)
            circle_radius = 50
            draw.ellipse(
                [(circle_center[0]-circle_radius, circle_center[1]-circle_radius),
                 (circle_center[0]+circle_radius, circle_center[1]+circle_radius)],
                outline=(0, 0, 0),
                fill=score_color,
                width=2
            )
            
            # Draw score text
            draw.text(circle_center, f"{overall_score}", fill=(255, 255, 255), font=header_font, anchor="mm")
            
            # Draw category scores
            categories = [
                ('liquidity', 'Liquidity'),
                ('volume', 'Volume'),
                ('holders', 'Holders'),
                ('social_hype', 'Social Hype'),
                ('technical_score', 'Technical'),
                ('risk_score', 'Risk')
            ]
            
            # Calculate positions
            start_y = 200
            bar_height = 20
            bar_width = 300
            spacing = 30
            
            for i, (key, label) in enumerate(categories):
                y_pos = start_y + i * spacing
                
                # Get score
                score = rating_data.get(key, 0)
                
                # Determine color based on score
                if score >= 80:
                    bar_color = (0, 150, 0)  # Green
                elif score >= 60:
                    bar_color = (255, 165, 0)  # Orange
                elif score >= 40:
                    bar_color = (255, 140, 0)  # Dark Orange
                else:
                    bar_color = (255, 0, 0)  # Red
                
                # Draw label
                draw.text((width/2 - bar_width/2 - 10, y_pos + bar_height/2), label, fill=(0, 0, 0), font=text_font, anchor="rm")
                
                # Draw background bar
                draw.rectangle(
                    [(width/2 - bar_width/2, y_pos), (width/2 + bar_width/2, y_pos + bar_height)],
                    outline=(0, 0, 0),
                    fill=(220, 220, 220),
                    width=1
                )
                
                # Draw score bar
                score_width = (score / 100) * bar_width
                draw.rectangle(
                    [(width/2 - bar_width/2, y_pos), (width/2 - bar_width/2 + score_width, y_pos + bar_height)],
                    outline=None,
                    fill=bar_color
                )
                
                # Draw score text
                draw.text((width/2 + bar_width/2 + 10, y_pos + bar_height/2), f"{score:.1f}", fill=(0, 0, 0), font=text_font, anchor="lm")
            
            # Save image if path provided
            if save_path:
                image.save(save_path)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"/tmp/{symbol}_rating.png"
                image.save(temp_path)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error creating coin rating image: {e}", exc_info=True)
            return None
    
    def create_risk_analysis_image(self, risk_data, save_path=None):
        """
        Create a visual risk analysis image
        
        Args:
            risk_data: Dictionary with risk information
            save_path: Path to save the image (optional)
            
        Returns:
            str: Path to saved image
        """
        try:
            # Create figure
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # Extract data
            symbol = risk_data.get('symbol', 'Unknown')
            risk_score = risk_data.get('risk_score', 0)
            risk_level = risk_data.get('risk_level', 'Unknown')
            
            # Get component scores
            trend_score = risk_data.get('trend_score', 0)
            confidence_score = risk_data.get('confidence_score', 0)
            risk_reward_score = risk_data.get('risk_reward_score', 0)
            
            # Set title
            ax.set_title(f"Risk Analysis: {symbol}", fontsize=16)
            
            # Create bar chart for component scores
            categories = ['Trend\nStrength', 'Signal\nConfidence', 'Risk-Reward\nRatio']
            scores = [trend_score, confidence_score, risk_reward_score]
            
            # Set colors based on scores
            colors = []
            for score in scores:
                if score >= 30:
                    colors.append('green')
                elif score >= 20:
                    colors.append('orange')
                elif score >= 10:
                    colors.append('darkorange')
                else:
                    colors.append('red')
            
            # Create bar chart
            bars = ax.bar(categories, scores, color=colors)
            
            # Add score labels on top of bars
            for bar in bars:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 1,
                        f'{height:.1f}',
                        ha='center', va='bottom')
            
            # Set y-axis limit
            ax.set_ylim(0, 40)
            
            # Add overall risk score as text
            risk_color = 'green' if risk_score >= 80 else 'orange' if risk_score >= 60 else 'darkorange' if risk_score >= 40 else 'red'
            ax.text(0.5, 0.9, f"Overall Risk Score: {risk_score:.1f}/100 ({risk_level})",
                    horizontalalignment='center',
                    verticalalignment='center',
                    transform=ax.transAxes,
                    fontsize=14,
                    bbox=dict(facecolor=risk_color, alpha=0.3))
            
            # Add explanation
            ax.text(0.5, 0.05,
                    "Higher scores indicate lower risk. Components add up to 100 max.",
                    horizontalalignment='center',
                    verticalalignment='center',
                    transform=ax.transAxes,
                    fontsize=10,
                    style='italic')
            
            # Adjust layout
            plt.tight_layout()
            
            # Save image if path provided
            if save_path:
                plt.savefig(save_path)
                plt.close(fig)
                return save_path
            else:
                # Save to a temporary file
                temp_path = f"/tmp/{symbol}_risk.png"
                plt.savefig(temp_path)
                plt.close(fig)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error creating risk analysis image: {e}", exc_info=True)
            return None
