"""
Webhook Service Module

This module implements a webhook service to connect the analysis system
to the Telegram bot for delivering alerts.
"""

import os
import logging
import asyncio
import json
from datetime import datetime
from aiohttp import web
import requests

# Import local modules
from telegram_integration.bot import TelegramBot

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class WebhookService:
    """Class for managing webhooks to connect analysis system to Telegram"""
    
    def __init__(self, telegram_bot=None):
        """
        Initialize the webhook service
        
        Args:
            telegram_bot: TelegramBot instance (optional)
        """
        self.app = web.Application()
        self.runner = None
        self.site = None
        self.host = '0.0.0.0'  # Listen on all interfaces
        self.port = 8080
        
        # Initialize Telegram bot if not provided
        self.telegram_bot = telegram_bot if telegram_bot else TelegramBot()
        
        # Setup routes
        self._setup_routes()
        
        logger.info("Webhook service initialized")
    
    def _setup_routes(self):
        """Setup webhook routes"""
        self.app.router.add_post('/webhook/alert', self._handle_alert_webhook)
        self.app.router.add_post('/webhook/reminder', self._handle_reminder_webhook)
        self.app.router.add_get('/health', self._handle_health_check)
        
        logger.info("Webhook routes configured")
    
    async def start(self):
        """Start the webhook service"""
        try:
            # Start the Telegram bot if not already started
            if not self.telegram_bot.bot:
                await self.telegram_bot.start()
            
            # Start the web server
            self.runner = web.AppRunner(self.app)
            await self.runner.setup()
            self.site = web.TCPSite(self.runner, self.host, self.port)
            await self.site.start()
            
            logger.info(f"Webhook service started on {self.host}:{self.port}")
            
            return True
        
        except Exception as e:
            logger.error(f"Error starting webhook service: {e}", exc_info=True)
            return False
    
    async def stop(self):
        """Stop the webhook service"""
        try:
            # Stop the web server
            if self.site:
                await self.site.stop()
            
            if self.runner:
                await self.runner.cleanup()
            
            logger.info("Webhook service stopped")
            
            return True
        
        except Exception as e:
            logger.error(f"Error stopping webhook service: {e}", exc_info=True)
            return False
    
    async def _handle_alert_webhook(self, request):
        """
        Handle alert webhook requests
        
        Args:
            request: Web request
            
        Returns:
            web.Response: HTTP response
        """
        try:
            # Parse request body
            body = await request.json()
            
            # Validate request
            if not self._validate_alert_request(body):
                return web.json_response(
                    {"status": "error", "message": "Invalid request format"},
                    status=400
                )
            
            # Process alert
            success = await self.telegram_bot.send_alert(body)
            
            if success:
                return web.json_response(
                    {"status": "success", "message": "Alert sent successfully"}
                )
            else:
                return web.json_response(
                    {"status": "error", "message": "Failed to send alert"},
                    status=500
                )
        
        except Exception as e:
            logger.error(f"Error handling alert webhook: {e}", exc_info=True)
            return web.json_response(
                {"status": "error", "message": str(e)},
                status=500
            )
    
    async def _handle_reminder_webhook(self, request):
        """
        Handle reminder webhook requests
        
        Args:
            request: Web request
            
        Returns:
            web.Response: HTTP response
        """
        try:
            # Parse request body
            body = await request.json()
            
            # Validate request
            if not self._validate_reminder_request(body):
                return web.json_response(
                    {"status": "error", "message": "Invalid request format"},
                    status=400
                )
            
            # Process reminder
            success = await self.telegram_bot.send_reminder(body)
            
            if success:
                return web.json_response(
                    {"status": "success", "message": "Reminder sent successfully"}
                )
            else:
                return web.json_response(
                    {"status": "error", "message": "Failed to send reminder"},
                    status=500
                )
        
        except Exception as e:
            logger.error(f"Error handling reminder webhook: {e}", exc_info=True)
            return web.json_response(
                {"status": "error", "message": str(e)},
                status=500
            )
    
    async def _handle_health_check(self, request):
        """
        Handle health check requests
        
        Args:
            request: Web request
            
        Returns:
            web.Response: HTTP response
        """
        return web.json_response({
            "status": "ok",
            "timestamp": datetime.now().isoformat(),
            "service": "crypto-alert-webhook",
            "telegram_bot_status": "running" if self.telegram_bot.bot else "stopped"
        })
    
    def _validate_alert_request(self, data):
        """
        Validate alert webhook request data
        
        Args:
            data: Request data
            
        Returns:
            bool: True if valid, False otherwise
        """
        # Check required fields
        required_fields = ['symbol', 'signal', 'price']
        
        for field in required_fields:
            if field not in data:
                logger.warning(f"Missing required field in alert request: {field}")
                return False
        
        return True
    
    def _validate_reminder_request(self, data):
        """
        Validate reminder webhook request data
        
        Args:
            data: Request data
            
        Returns:
            bool: True if valid, False otherwise
        """
        # Check required fields
        required_fields = ['symbol', 'type']
        
        for field in required_fields:
            if field not in data:
                logger.warning(f"Missing required field in reminder request: {field}")
                return False
        
        # Check type-specific fields
        reminder_type = data.get('type')
        
        if reminder_type == 'price_target':
            if 'target_price' not in data or 'current_price' not in data:
                logger.warning("Missing price fields in price_target reminder")
                return False
        elif reminder_type == 'time':
            if 'hours' not in data:
                logger.warning("Missing hours field in time reminder")
                return False
        
        return True


class AlertSender:
    """Class for sending alerts to the webhook service"""
    
    def __init__(self, webhook_url=None):
        """
        Initialize the alert sender
        
        Args:
            webhook_url: URL of the webhook service (optional)
        """
        # Use default URL if not provided
        self.webhook_url = webhook_url if webhook_url else "http://localhost:8080/webhook/alert"
        self.reminder_url = self.webhook_url.replace("/alert", "/reminder")
        
        logger.info("Alert sender initialized")
    
    def send_alert(self, alert_data):
        """
        Send an alert to the webhook service
        
        Args:
            alert_data: Alert data
            
        Returns:
            bool: Success or failure
        """
        try:
            # Send POST request to webhook
            response = requests.post(
                self.webhook_url,
                json=alert_data,
                headers={"Content-Type": "application/json"}
            )
            
            # Check response
            if response.status_code == 200:
                logger.info(f"Alert sent successfully for {alert_data.get('symbol', 'Unknown')}")
                return True
            else:
                logger.error(f"Failed to send alert: {response.text}")
                return False
        
        except Exception as e:
            logger.error(f"Error sending alert: {e}", exc_info=True)
            return False
    
    def send_reminder(self, reminder_data):
        """
        Send a reminder to the webhook service
        
        Args:
            reminder_data: Reminder data
            
        Returns:
            bool: Success or failure
        """
        try:
            # Send POST request to webhook
            response = requests.post(
                self.reminder_url,
                json=reminder_data,
                headers={"Content-Type": "application/json"}
            )
            
            # Check response
            if response.status_code == 200:
                logger.info(f"Reminder sent successfully for {reminder_data.get('symbol', 'Unknown')}")
                return True
            else:
                logger.error(f"Failed to send reminder: {response.text}")
                return False
        
        except Exception as e:
            logger.error(f"Error sending reminder: {e}", exc_info=True)
            return False
