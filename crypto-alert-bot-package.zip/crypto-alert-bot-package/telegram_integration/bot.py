"""
Telegram Bot Module

This module implements a Telegram bot for delivering cryptocurrency alerts
with visual enhancements and interactive features.
"""

import os
import logging
import asyncio
from datetime import datetime
import telegram
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class TelegramBot:
    """Class for managing Telegram bot and sending alerts"""
    
    def __init__(self):
        """Initialize the Telegram bot"""
        self.token = config.TELEGRAM_BOT_TOKEN
        self.channel_id = config.TELEGRAM_CHANNEL_ID
        self.use_emojis = config.USE_EMOJIS
        self.include_charts = config.INCLUDE_CHARTS
        
        # Initialize bot application
        self.application = None
        self.bot = None
        
        # Track sent alerts to avoid duplicates
        self.sent_alerts = {}
        
        # Track reminders
        self.reminders = {}
        
        logger.info("Telegram bot initialized")
    
    async def start(self):
        """Start the Telegram bot"""
        try:
            # Create bot application
            self.application = Application.builder().token(self.token).build()
            
            # Get bot instance
            self.bot = self.application.bot
            
            # Add command handlers
            self.application.add_handler(CommandHandler("start", self._start_command))
            self.application.add_handler(CommandHandler("help", self._help_command))
            self.application.add_handler(CommandHandler("status", self._status_command))
            
            # Add callback query handler for button clicks
            self.application.add_handler(CallbackQueryHandler(self._button_callback))
            
            # Start the bot
            await self.application.initialize()
            await self.application.start()
            await self.application.updater.start_polling()
            
            logger.info("Telegram bot started")
            
            # Send startup message to channel
            await self.send_text_message(
                "🚀 Crypto Alert Bot is now online and monitoring the market for opportunities!"
            )
            
            return True
        
        except Exception as e:
            logger.error(f"Error starting Telegram bot: {e}", exc_info=True)
            return False
    
    async def stop(self):
        """Stop the Telegram bot"""
        try:
            if self.application:
                # Send shutdown message to channel
                await self.send_text_message(
                    "🛑 Crypto Alert Bot is shutting down. Alerts will be paused until the bot is restarted."
                )
                
                # Stop the bot
                await self.application.stop()
                await self.application.shutdown()
                
                logger.info("Telegram bot stopped")
                
                return True
            
            return False
        
        except Exception as e:
            logger.error(f"Error stopping Telegram bot: {e}", exc_info=True)
            return False
    
    async def send_text_message(self, text, chat_id=None):
        """
        Send a text message to the channel or specified chat
        
        Args:
            text: Message text
            chat_id: Chat ID to send to (default: channel ID)
            
        Returns:
            bool: Success or failure
        """
        try:
            if not self.bot:
                logger.error("Bot not initialized")
                return False
            
            # Use channel ID if chat ID not specified
            if not chat_id:
                chat_id = self.channel_id
            
            # Send message
            await self.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode='HTML',
                disable_web_page_preview=True
            )
            
            return True
        
        except Exception as e:
            logger.error(f"Error sending text message: {e}", exc_info=True)
            return False
    
    async def send_photo_message(self, photo_path, caption, chat_id=None):
        """
        Send a photo with caption to the channel or specified chat
        
        Args:
            photo_path: Path to photo file
            caption: Caption text
            chat_id: Chat ID to send to (default: channel ID)
            
        Returns:
            bool: Success or failure
        """
        try:
            if not self.bot:
                logger.error("Bot not initialized")
                return False
            
            # Use channel ID if chat ID not specified
            if not chat_id:
                chat_id = self.channel_id
            
            # Check if photo exists
            if not os.path.exists(photo_path):
                logger.error(f"Photo not found: {photo_path}")
                return False
            
            # Send photo
            with open(photo_path, 'rb') as photo:
                await self.bot.send_photo(
                    chat_id=chat_id,
                    photo=photo,
                    caption=caption,
                    parse_mode='HTML'
                )
            
            return True
        
        except Exception as e:
            logger.error(f"Error sending photo message: {e}", exc_info=True)
            return False
    
    async def send_alert(self, alert_data):
        """
        Send a cryptocurrency alert to the channel
        
        Args:
            alert_data: Alert data with signal information
            
        Returns:
            bool: Success or failure
        """
        try:
            if not self.bot:
                logger.error("Bot not initialized")
                return False
            
            # Generate alert ID
            symbol = alert_data.get('symbol', 'Unknown')
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            alert_id = f"{symbol}_{timestamp}"
            
            # Check if similar alert was sent recently
            if symbol in self.sent_alerts:
                last_alert_time = self.sent_alerts[symbol]
                time_diff = (datetime.now() - last_alert_time).total_seconds() / 60
                
                # Skip if similar alert sent in the last 30 minutes
                if time_diff < 30:
                    logger.info(f"Skipping duplicate alert for {symbol} (sent {time_diff:.1f} minutes ago)")
                    return False
            
            # Format alert message
            message = self._format_alert_message(alert_data)
            
            # Add buttons
            keyboard = [
                [
                    InlineKeyboardButton("Set Price Alert", callback_data=f"price_{alert_id}"),
                    InlineKeyboardButton("Set Reminder", callback_data=f"remind_{alert_id}")
                ],
                [
                    InlineKeyboardButton("Share Alert", callback_data=f"share_{alert_id}"),
                    InlineKeyboardButton("View Details", callback_data=f"details_{alert_id}")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # Send message with chart if available
            success = False
            if self.include_charts and 'chart_path' in alert_data and alert_data['chart_path']:
                # Send as photo with caption
                with open(alert_data['chart_path'], 'rb') as photo:
                    message = await self.bot.send_photo(
                        chat_id=self.channel_id,
                        photo=photo,
                        caption=message,
                        parse_mode='HTML',
                        reply_markup=reply_markup
                    )
                success = True
            else:
                # Send as text
                message = await self.bot.send_message(
                    chat_id=self.channel_id,
                    text=message,
                    parse_mode='HTML',
                    disable_web_page_preview=True,
                    reply_markup=reply_markup
                )
                success = True
            
            # Store alert data for callbacks
            if success:
                # Update sent alerts
                self.sent_alerts[symbol] = datetime.now()
                
                # Store alert data with message ID for callbacks
                alert_data['message_id'] = message.message_id
                alert_data['alert_id'] = alert_id
                
                logger.info(f"Alert sent for {symbol}")
                
                return True
            
            return False
        
        except Exception as e:
            logger.error(f"Error sending alert: {e}", exc_info=True)
            return False
    
    def _format_alert_message(self, alert_data):
        """Format alert message with signal information"""
        try:
            # Get signal type
            signal = alert_data.get('signal', 0)
            signal_type = "BUY" if signal > 0 else "SELL" if signal < 0 else "NEUTRAL"
            
            # Get emojis
            if self.use_emojis:
                if signal_type == "BUY":
                    signal_emoji = "🟢"
                elif signal_type == "SELL":
                    signal_emoji = "🔴"
                else:
                    signal_emoji = "⚪"
            else:
                signal_emoji = ""
            
            # Format header
            symbol = alert_data.get('symbol', 'Unknown')
            header = f"{signal_emoji} <b>{signal_type} SIGNAL: {symbol}</b> {signal_emoji}\n\n"
            
            # Format price information
            price = alert_data.get('price', 0)
            price_info = f"Current Price: <b>${price:.4f}</b>\n"
            
            # Format technical indicators
            indicators = (
                f"Trend Strength: <b>{alert_data.get('trend_strength', 0):.1f}%</b>\n"
                f"Signal Confidence: <b>{alert_data.get('confidence', 0):.1f}%</b>\n"
            )
            
            # Format risk management
            if 'stop_loss' in alert_data and 'take_profit' in alert_data:
                risk_info = (
                    f"Stop Loss: <b>${alert_data['stop_loss']:.4f}</b>\n"
                    f"Take Profit: <b>${alert_data['take_profit']:.4f}</b>\n"
                )
                
                # Add risk-reward ratio if available
                if 'risk_reward_ratio' in alert_data:
                    risk_info += f"Risk-Reward Ratio: <b>{alert_data['risk_reward_ratio']:.2f}</b>\n"
            else:
                risk_info = ""
            
            # Format position sizing if available
            if 'position_size_units' in alert_data and 'position_size_currency' in alert_data:
                position_info = (
                    f"Recommended Position: <b>{alert_data['position_size_units']:.4f} units</b>\n"
                    f"Position Value: <b>${alert_data['position_size_currency']:.2f}</b>\n"
                )
            else:
                position_info = ""
            
            # Format risk score if available
            if 'risk_score' in alert_data and 'risk_level' in alert_data:
                risk_score_info = (
                    f"Risk Score: <b>{alert_data['risk_score']:.1f}/100</b>\n"
                    f"Risk Level: <b>{alert_data['risk_level']}</b>\n"
                )
            else:
                risk_score_info = ""
            
            # Format timestamp
            timestamp = alert_data.get('timestamp', datetime.now())
            time_info = f"\nAlert Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
            
            # Format footer
            footer = "\n<i>Use buttons below for price alerts, reminders, or to share this signal</i>"
            
            # Combine all sections
            message = header + price_info + indicators + risk_info + position_info + risk_score_info + time_info + footer
            
            return message
        
        except Exception as e:
            logger.error(f"Error formatting alert message: {e}", exc_info=True)
            return f"Alert for {alert_data.get('symbol', 'Unknown')}"
    
    async def send_reminder(self, reminder_data):
        """
        Send a reminder alert to the channel
        
        Args:
            reminder_data: Reminder data
            
        Returns:
            bool: Success or failure
        """
        try:
            if not self.bot:
                logger.error("Bot not initialized")
                return False
            
            # Format reminder message
            symbol = reminder_data.get('symbol', 'Unknown')
            reminder_type = reminder_data.get('type', 'general')
            
            # Choose emoji based on reminder type
            if self.use_emojis:
                if reminder_type == 'price_target':
                    emoji = "🎯"
                elif reminder_type == 'time':
                    emoji = "⏰"
                else:
                    emoji = "📢"
            else:
                emoji = ""
            
            # Format header
            header = f"{emoji} <b>REMINDER: {symbol}</b> {emoji}\n\n"
            
            # Format message based on reminder type
            if reminder_type == 'price_target':
                target_price = reminder_data.get('target_price', 0)
                current_price = reminder_data.get('current_price', 0)
                
                message = (
                    f"Price target of <b>${target_price:.4f}</b> has been reached!\n"
                    f"Current price: <b>${current_price:.4f}</b>\n"
                )
            elif reminder_type == 'time':
                hours = reminder_data.get('hours', 0)
                
                message = (
                    f"It's been {hours} hours since the original alert.\n"
                    f"Original signal: <b>{reminder_data.get('original_signal', 'Unknown')}</b>\n"
                )
                
                # Add price change if available
                if 'original_price' in reminder_data and 'current_price' in reminder_data:
                    original_price = reminder_data['original_price']
                    current_price = reminder_data['current_price']
                    price_change = ((current_price / original_price) - 1) * 100
                    
                    message += f"Price change: <b>{price_change:.2f}%</b>\n"
            else:
                message = reminder_data.get('message', 'General reminder for this cryptocurrency.')
            
            # Format timestamp
            timestamp = datetime.now()
            time_info = f"\nReminder Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
            
            # Combine all sections
            full_message = header + message + time_info
            
            # Send message
            await self.bot.send_message(
                chat_id=self.channel_id,
                text=full_message,
                parse_mode='HTML',
                disable_web_page_preview=True
            )
            
            logger.info(f"Reminder sent for {symbol}")
            
            return True
        
        except Exception as e:
            logger.error(f"Error sending reminder: {e}", exc_info=True)
            return False
    
    async def set_price_reminder(self, symbol, current_price, target_price, alert_id=None):
        """
        Set a price target reminder
        
        Args:
            symbol: Cryptocurrency symbol
            current_price: Current price
            target_price: Target price to trigger reminder
            alert_id: Original alert ID (optional)
            
        Returns:
            str: Reminder ID
        """
        try:
            # Generate reminder ID
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            reminder_id = f"price_{symbol}_{timestamp}"
            
            # Store reminder data
            self.reminders[reminder_id] = {
                'type': 'price_target',
                'symbol': symbol,
                'current_price': current_price,
                'target_price': target_price,
                'created_at': datetime.now(),
                'alert_id': alert_id,
                'triggered': False
            }
            
            logger.info(f"Price reminder set for {symbol} at ${target_price}")
            
            return reminder_id
        
        except Exception as e:
            logger.error(f"Error setting price reminder: {e}", exc_info=True)
            return None
    
    async def set_time_reminder(self, symbol, hours, original_price=None, original_signal=None, alert_id=None):
        """
        Set a time-based reminder
        
        Args:
            symbol: Cryptocurrency symbol
            hours: Hours until reminder
            original_price: Original price (optional)
            original_signal: Original signal type (optional)
            alert_id: Original alert ID (optional)
            
        Returns:
            str: Reminder ID
        """
        try:
            # Generate reminder ID
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            reminder_id = f"time_{symbol}_{timestamp}"
            
            # Store reminder data
            self.reminders[reminder_id] = {
                'type': 'time',
                'symbol': symbol,
                'hours': hours,
                'trigger_time': datetime.now().timestamp() + (hours * 3600),
                'original_price': original_price,
                'original_signal': original_signal,
                'created_at': datetime.now(),
                'alert_id': alert_id,
                'triggered': False
            }
            
            logger.info(f"Time reminder set for {symbol} in {hours} hours")
            
            return reminder_id
        
        except Exception as e:
            logger.error(f"Error setting time reminder: {e}", exc_info=True)
            return None
    
    async def check_reminders(self, current_prices=None):
        """
        Check and trigger reminders
        
        Args:
            current_prices: Dictionary of current prices by symbol
            
        Returns:
            list: Triggered reminder IDs
        """
        try:
            triggered = []
            current_time = datetime.now().timestamp()
            
            for reminder_id, reminder in self.reminders.items():
                # Skip already triggered reminders
                if reminder['triggered']:
                    continue
                
                # Check time-based reminders
                if reminder['type'] == 'time' and current_time >= reminder.get('trigger_time', 0):
                    # Update current price if available
                    if current_prices and reminder['symbol'] in current_prices:
                        reminder['current_price'] = current_prices[reminder['symbol']]
                    
                    # Trigger reminder
                    await self.send_reminder(reminder)
                    reminder['triggered'] = True
                    triggered.append(reminder_id)
                
                # Check price-based reminders
                elif reminder['type'] == 'price_target' and current_prices:
                    symbol = reminder['symbol']
                    
                    if symbol in current_prices:
                        current_price = current_prices[symbol]
                        target_price = reminder['target_price']
                        original_price = reminder['current_price']
                        
                        # Check if target reached
                        if (original_price < target_price and current_price >= target_price) or \
                           (original_price > target_price and current_price <= target_price):
                            # Update current price
                            reminder['current_price'] = current_price
                            
                            # Trigger reminder
                            await self.send_reminder(reminder)
                            reminder['triggered'] = True
                            triggered.append(reminder_id)
            
            return triggered
        
        except Exception as e:
            logger.error(f"Error checking reminders: {e}", exc_info=True)
            return []
    
    # Command handlers
    
    async def _start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /start command"""
        user = update.effective_user
        await update.message.reply_html(
            f"Hi {user.mention_html()}! I'm the Crypto Alert Bot. "
            f"I'll send alerts to the channel when I detect trading opportunities."
        )
    
    async def _help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /help command"""
        help_text = (
            "<b>Crypto Alert Bot Help</b>\n\n"
            "This bot monitors cryptocurrencies and sends alerts when trading opportunities are detected.\n\n"
            "<b>Commands:</b>\n"
            "/start - Start the bot\n"
            "/help - Show this help message\n"
            "/status - Check bot status\n\n"
            "<b>Alert Features:</b>\n"
            "• Set price alerts using the buttons on alert messages\n"
            "• Set time-based reminders for follow-ups\n"
            "• Share alerts with others\n"
            "• View detailed analysis\n\n"
            "Alerts are sent to the configured channel automatically."
        )
        
        await update.message.reply_html(help_text)
    
    async def _status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /status command"""
        status_text = (
            "<b>Crypto Alert Bot Status</b>\n\n"
            f"• Bot is running: <b>Yes</b>\n"
            f"• Alerts sent today: <b>{len(self.sent_alerts)}</b>\n"
            f"• Active reminders: <b>{len([r for r in self.reminders.values() if not r['triggered']])}</b>\n"
            f"• Monitoring channel: <b>{self.channel_id}</b>\n"
            f"• Charts enabled: <b>{'Yes' if self.include_charts else 'No'}</b>\n"
            f"• Emojis enabled: <b>{'Yes' if self.use_emojis else 'No'}</b>\n"
        )
        
        await update.message.reply_html(status_text)
    
    # Callback query handler
    
    async def _button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle button clicks"""
        query = update.callback_query
        await query.answer()
        
        # Parse callback data
        data = query.data
        
        if data.startswith("price_"):
            # Price alert button clicked
            alert_id = data[6:]
            await self._handle_price_alert(query, alert_id)
        
        elif data.startswith("remind_"):
            # Reminder button clicked
            alert_id = data[7:]
            await self._handle_reminder(query, alert_id)
        
        elif data.startswith("share_"):
            # Share button clicked
            alert_id = data[6:]
            await self._handle_share(query, alert_id)
        
        elif data.startswith("details_"):
            # Details button clicked
            alert_id = data[8:]
            await self._handle_details(query, alert_id)
    
    async def _handle_price_alert(self, query, alert_id):
        """Handle price alert button click"""
        # This would be implemented to set a price alert
        # For now, just acknowledge the click
        await query.edit_message_reply_markup(reply_markup=None)
        await query.message.reply_text("Price alert feature will be implemented soon!")
    
    async def _handle_reminder(self, query, alert_id):
        """Handle reminder button click"""
        # This would be implemented to set a reminder
        # For now, just acknowledge the click
        await query.edit_message_reply_markup(reply_markup=None)
        await query.message.reply_text("Reminder feature will be implemented soon!")
    
    async def _handle_share(self, query, alert_id):
        """Handle share button click"""
        # This would be implemented to share the alert
        # For now, just acknowledge the click
        await query.edit_message_reply_markup(reply_markup=None)
        await query.message.reply_text("Share feature will be implemented soon!")
    
    async def _handle_details(self, query, alert_id):
        """Handle details button click"""
        # This would be implemented to show more details
        # For now, just acknowledge the click
        await query.edit_message_reply_markup(reply_markup=None)
        await query.message.reply_text("Details feature will be implemented soon!")
