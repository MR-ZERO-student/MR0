"""
Manual Scan Module

This module provides a simplified interface for manually triggering market scans
without relying on scheduled tasks.
"""

import logging
import asyncio
import sys
import os
import json
from datetime import datetime
import argparse

# Add project root to path
sys.path.append('/home/ubuntu/crypto_alert_bot')

# Import local modules
from system_integration import CryptoAlertSystem
from error_handling import setup_logging

# Configure logging
setup_logging()
logger = logging.getLogger(__name__)

class ManualScanner:
    """Class for manually triggering market scans"""
    
    def __init__(self):
        """Initialize the manual scanner"""
        self.system = CryptoAlertSystem()
        logger.info("Manual scanner initialized")
    
    async def start_system(self):
        """Start the cryptocurrency alert system"""
        try:
            logger.info("Starting cryptocurrency alert system")
            result = await self.system.start()
            if result:
                logger.info("System started successfully")
                return True
            else:
                logger.error("Failed to start system")
                return False
        
        except Exception as e:
            logger.error(f"Error starting system: {e}", exc_info=True)
            return False
    
    async def stop_system(self):
        """Stop the cryptocurrency alert system"""
        try:
            logger.info("Stopping cryptocurrency alert system")
            result = await self.system.stop()
            if result:
                logger.info("System stopped successfully")
                return True
            else:
                logger.error("Failed to stop system")
                return False
        
        except Exception as e:
            logger.error(f"Error stopping system: {e}", exc_info=True)
            return False
    
    async def trigger_market_scan(self):
        """Trigger a market scan"""
        try:
            logger.info("Triggering market scan")
            
            # Process market scan directly
            self.system._process_market_scan()
            
            logger.info("Market scan triggered")
            return True
        
        except Exception as e:
            logger.error(f"Error triggering market scan: {e}", exc_info=True)
            return False
    
    async def trigger_reminder_check(self):
        """Trigger a reminder check"""
        try:
            logger.info("Triggering reminder check")
            
            # Process reminder check directly
            self.system._process_reminder_check()
            
            logger.info("Reminder check triggered")
            return True
        
        except Exception as e:
            logger.error(f"Error triggering reminder check: {e}", exc_info=True)
            return False
    
    async def analyze_specific_token(self, token_address, chain="ethereum"):
        """
        Analyze a specific token
        
        Args:
            token_address: Token address to analyze
            chain: Blockchain chain (ethereum, bsc, etc.)
            
        Returns:
            bool: Success or failure
        """
        try:
            logger.info(f"Analyzing token: {token_address} on {chain}")
            
            # Create token data
            token_data = {
                'address': token_address,
                'chain': chain,
                'symbol': 'Unknown'  # Will be updated during analysis
            }
            
            # Process token analysis directly
            self.system._process_token_analysis(token_data)
            
            logger.info(f"Token analysis triggered for {token_address}")
            return True
        
        except Exception as e:
            logger.error(f"Error analyzing token: {e}", exc_info=True)
            return False


async def main():
    """Main entry point for the manual scanner"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Manually trigger cryptocurrency market scans')
    parser.add_argument('--scan', action='store_true', help='Trigger a market scan')
    parser.add_argument('--reminders', action='store_true', help='Trigger a reminder check')
    parser.add_argument('--token', type=str, help='Analyze a specific token address')
    parser.add_argument('--chain', type=str, default='ethereum', help='Blockchain chain for token analysis')
    args = parser.parse_args()
    
    # Create manual scanner
    scanner = ManualScanner()
    
    try:
        # Start the system
        result = await scanner.start_system()
        if not result:
            logger.error("Failed to start system, exiting")
            return
        
        # Process commands
        if args.scan:
            await scanner.trigger_market_scan()
        
        if args.reminders:
            await scanner.trigger_reminder_check()
        
        if args.token:
            await scanner.analyze_specific_token(args.token, args.chain)
        
        # If no specific command, show help
        if not (args.scan or args.reminders or args.token):
            parser.print_help()
        
        # Wait a moment for any background tasks to complete
        await asyncio.sleep(5)
        
        # Stop the system
        await scanner.stop_system()
    
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received, shutting down")
        await scanner.stop_system()
    
    except Exception as e:
        logger.error(f"Unhandled exception: {e}", exc_info=True)
        await scanner.stop_system()


if __name__ == "__main__":
    # Run the main function
    asyncio.run(main())
