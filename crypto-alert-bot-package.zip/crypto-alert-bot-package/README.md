# Cryptocurrency Analysis and Alert System

A professional-grade cryptocurrency analysis and alert system that delivers detailed notifications to a Telegram channel. The system integrates multiple data sources and advanced technical analysis, with a strong focus on visual presentation in the Telegram messages.

## Features

### Data Collection & Analysis

- **DexScreener Integration**: Real-time token data monitoring, detection of "rugged" tokens, identification of "pumped" tokens, and tracking of new token pairs.
- **Twitter X & Social Media Integration**: Monitoring of trending coin mentions and sentiment analysis to identify early hype or negative sentiment.
- **Blockchain Holder Analysis & Scam Checker**: Token holder information extraction and comprehensive scam detection system.

### Technical Analysis

- **Advanced Indicators**: Gaussian Channel analysis, Stochastic RSI, MACD with slope filtering, and ATR-based adaptive filtering.
- **Multi-Timeframe Analysis**: Support for analyzing multiple timeframes with consensus signal generation.
- **Signal Generation**: Buy/sell signal detection with configurable parameters and confidence scoring.

### Risk Management

- **Dynamic Position Sizing**: Calculates optimal position sizes based on risk-per-trade setting and volatility.
- **Stop-Loss & Take-Profit Calculations**: Adaptive stop-loss levels and take-profit targets with favorable risk-reward ratios.
- **Risk Evaluation System**: Comprehensive risk scores for each potential trade with categorization into risk levels.

### Telegram Alerts

- **Real-time Notifications**: BUY & SELL alerts with visual indicators, chart snapshots, and detailed metrics.
- **Reminder Alerts**: Price target notifications and time-based updates on trending coins.
- **Visual Presentation**: Rich formatting with charts, coin ratings, risk analysis, and social media hype scores.

## Installation

### Prerequisites

- Python 3.10+
- Telegram Bot API Token
- DexScreener API access
- Twitter/X API credentials (optional)
- Etherscan/BSCScan API keys (optional)

### Setup

1. Clone the repository:
```bash
git clone https://github.com/yourusername/crypto-alert-bot.git
cd crypto-alert-bot
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Create a `.env` file based on the `.env.template`:
```bash
cp .env.template .env
```

4. Edit the `.env` file with your API keys and configuration settings.

## Configuration

The system is highly configurable through the `config.py` file. Key settings include:

- `TELEGRAM_CHANNEL_ID`: ID of your Telegram channel for alerts
- `SCAN_INTERVAL_MINUTES`: How often to scan the market for new opportunities
- `MIN_SIGNAL_STRENGTH`: Minimum confidence threshold for sending alerts
- `MIN_RISK_SCORE`: Minimum risk score threshold for sending alerts
- `TRADING_CAPITAL`: Your trading capital for position sizing calculations
- `MAX_TOKENS_TO_ANALYZE`: Maximum number of tokens to analyze per scan

## Usage

### Starting the Bot

```bash
python main.py
```

### Telegram Commands

- `/start`: Start the bot and receive a welcome message
- `/help`: Display help information
- `/settings`: View and adjust bot settings
- `/scan`: Manually trigger a market scan
- `/alert <symbol> <price>`: Set a price alert for a specific symbol
- `/watchlist`: View your watchlist
- `/add <symbol>`: Add a symbol to your watchlist
- `/remove <symbol>`: Remove a symbol from your watchlist

## System Architecture

The system is organized into several modules:

- **Data Collection**: Interfaces with external APIs to gather market data
- **Technical Analysis**: Processes price data to generate trading signals
- **Risk Management**: Evaluates trade opportunities and calculates position sizes
- **Telegram Integration**: Handles communication with users via Telegram
- **Visual Presentation**: Creates charts and visual elements for alerts
- **System Integration**: Connects all components into a cohesive application
- **Scheduler**: Manages periodic tasks and background processes
- **Error Handling**: Provides robust error management and logging

## Testing

Run the test suite to verify all components are working correctly:

```bash
python tests.py
```

## Deployment

For production deployment, it's recommended to use a process manager like PM2:

```bash
npm install pm2 -g
pm2 start main.py --name crypto-alert-bot
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot) for Telegram integration
- [pandas](https://pandas.pydata.org/) and [numpy](https://numpy.org/) for data analysis
- [matplotlib](https://matplotlib.org/) for chart generation
- [ccxt](https://github.com/ccxt/ccxt) for cryptocurrency exchange data
