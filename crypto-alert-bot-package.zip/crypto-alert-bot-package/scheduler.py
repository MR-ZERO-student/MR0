"""
Scheduler Module

This module implements a scheduling system for the cryptocurrency alert bot
to run periodic tasks and manage background processes.
"""

import logging
import asyncio
import time
from datetime import datetime, timedelta
import threading
import queue
import signal
import sys
from typing import Dict, List, Any, Optional, Tuple, Callable

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class TaskScheduler:
    """Class for scheduling and managing periodic tasks"""
    
    def __init__(self):
        """Initialize the task scheduler"""
        self.tasks = {}
        self.running = False
        self.scheduler_thread = None
        self.task_queue = queue.Queue()
        self.worker_threads = []
        self.num_workers = config.NUM_WORKER_THREADS
        
        logger.info("Task scheduler initialized")
    
    def add_task(self, task_id, interval_minutes, task_func, initial_delay_minutes=0):
        """
        Add a periodic task to the scheduler
        
        Args:
            task_id: Unique identifier for the task
            interval_minutes: Interval between task executions in minutes
            task_func: Function to execute
            initial_delay_minutes: Initial delay before first execution in minutes
            
        Returns:
            bool: Success or failure
        """
        try:
            # Calculate next run time
            next_run = datetime.now() + timedelta(minutes=initial_delay_minutes)
            
            # Add task to dictionary
            self.tasks[task_id] = {
                'interval': interval_minutes,
                'function': task_func,
                'next_run': next_run,
                'running': False,
                'last_run': None,
                'error_count': 0
            }
            
            logger.info(f"Task '{task_id}' added with interval {interval_minutes} minutes")
            return True
        
        except Exception as e:
            logger.error(f"Error adding task '{task_id}': {e}", exc_info=True)
            return False
    
    def remove_task(self, task_id):
        """
        Remove a task from the scheduler
        
        Args:
            task_id: Unique identifier for the task
            
        Returns:
            bool: Success or failure
        """
        try:
            if task_id in self.tasks:
                del self.tasks[task_id]
                logger.info(f"Task '{task_id}' removed")
                return True
            else:
                logger.warning(f"Task '{task_id}' not found")
                return False
        
        except Exception as e:
            logger.error(f"Error removing task '{task_id}': {e}", exc_info=True)
            return False
    
    def start(self):
        """
        Start the task scheduler
        
        Returns:
            bool: Success or failure
        """
        try:
            if self.running:
                logger.warning("Task scheduler already running")
                return False
            
            logger.info("Starting task scheduler")
            
            # Set running flag
            self.running = True
            
            # Start scheduler thread
            self.scheduler_thread = threading.Thread(target=self._scheduler_loop)
            self.scheduler_thread.daemon = True
            self.scheduler_thread.start()
            
            # Start worker threads
            self._start_workers()
            
            logger.info("Task scheduler started")
            return True
        
        except Exception as e:
            logger.error(f"Error starting task scheduler: {e}", exc_info=True)
            self.running = False
            return False
    
    def stop(self):
        """
        Stop the task scheduler
        
        Returns:
            bool: Success or failure
        """
        try:
            if not self.running:
                logger.warning("Task scheduler not running")
                return False
            
            logger.info("Stopping task scheduler")
            
            # Clear running flag
            self.running = False
            
            # Stop worker threads
            self._stop_workers()
            
            # Wait for scheduler thread to finish
            if self.scheduler_thread:
                self.scheduler_thread.join(timeout=5)
            
            logger.info("Task scheduler stopped")
            return True
        
        except Exception as e:
            logger.error(f"Error stopping task scheduler: {e}", exc_info=True)
            return False
    
    def _scheduler_loop(self):
        """Main scheduler loop for checking and scheduling tasks"""
        logger.info("Scheduler loop started")
        
        while self.running:
            try:
                current_time = datetime.now()
                
                # Check each task
                for task_id, task in self.tasks.items():
                    # Skip if task is already running
                    if task['running']:
                        continue
                    
                    # Check if it's time to run the task
                    if current_time >= task['next_run']:
                        logger.info(f"Scheduling task '{task_id}'")
                        
                        # Mark task as running
                        task['running'] = True
                        
                        # Add task to queue
                        self.task_queue.put((task_id, task['function']))
                        
                        # Update next run time
                        task['next_run'] = current_time + timedelta(minutes=task['interval'])
                
                # Sleep for a short time
                time.sleep(1)
            
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}", exc_info=True)
                time.sleep(10)  # Sleep longer on error
        
        logger.info("Scheduler loop stopped")
    
    def _start_workers(self):
        """Start worker threads for processing tasks"""
        logger.info(f"Starting {self.num_workers} worker threads")
        
        for i in range(self.num_workers):
            worker = threading.Thread(target=self._worker_loop, args=(i,))
            worker.daemon = True
            worker.start()
            self.worker_threads.append(worker)
        
        logger.info("Worker threads started")
    
    def _stop_workers(self):
        """Stop worker threads"""
        logger.info("Stopping worker threads")
        
        # Signal workers to stop by adding None tasks
        for _ in range(len(self.worker_threads)):
            self.task_queue.put((None, None))
        
        # Wait for workers to finish
        for thread in self.worker_threads:
            thread.join(timeout=5)
        
        # Clear worker threads list
        self.worker_threads = []
        
        logger.info("Worker threads stopped")
    
    def _worker_loop(self, worker_id):
        """Worker loop for processing tasks"""
        logger.info(f"Worker {worker_id} started")
        
        while self.running:
            try:
                # Get task from queue
                task_id, task_func = self.task_queue.get(timeout=1)
                
                # Check if stop signal
                if task_id is None:
                    logger.info(f"Worker {worker_id} received stop signal")
                    break
                
                # Execute task
                logger.info(f"Worker {worker_id} executing task '{task_id}'")
                start_time = time.time()
                
                try:
                    task_func()
                    
                    # Update task status
                    if task_id in self.tasks:
                        self.tasks[task_id]['last_run'] = datetime.now()
                        self.tasks[task_id]['running'] = False
                        self.tasks[task_id]['error_count'] = 0
                    
                    # Log execution time
                    execution_time = time.time() - start_time
                    logger.info(f"Task '{task_id}' completed in {execution_time:.2f} seconds")
                
                except Exception as e:
                    logger.error(f"Error executing task '{task_id}': {e}", exc_info=True)
                    
                    # Update task status
                    if task_id in self.tasks:
                        self.tasks[task_id]['running'] = False
                        self.tasks[task_id]['error_count'] += 1
                
                # Mark task as done in queue
                self.task_queue.task_done()
            
            except queue.Empty:
                # Queue timeout, continue loop
                pass
            
            except Exception as e:
                logger.error(f"Error in worker {worker_id}: {e}", exc_info=True)
                time.sleep(5)  # Sleep on error
        
        logger.info(f"Worker {worker_id} stopped")
    
    def get_task_status(self, task_id=None):
        """
        Get status of tasks
        
        Args:
            task_id: Unique identifier for the task (optional)
            
        Returns:
            dict: Task status information
        """
        try:
            if task_id:
                # Return status of specific task
                if task_id in self.tasks:
                    task = self.tasks[task_id]
                    return {
                        'id': task_id,
                        'interval': task['interval'],
                        'next_run': task['next_run'],
                        'last_run': task['last_run'],
                        'running': task['running'],
                        'error_count': task['error_count']
                    }
                else:
                    return None
            else:
                # Return status of all tasks
                result = {}
                for tid, task in self.tasks.items():
                    result[tid] = {
                        'interval': task['interval'],
                        'next_run': task['next_run'],
                        'last_run': task['last_run'],
                        'running': task['running'],
                        'error_count': task['error_count']
                    }
                return result
        
        except Exception as e:
            logger.error(f"Error getting task status: {e}", exc_info=True)
            return {}


class BackgroundTaskManager:
    """Class for managing one-time background tasks"""
    
    def __init__(self):
        """Initialize the background task manager"""
        self.task_queue = queue.Queue()
        self.running = False
        self.worker_threads = []
        self.num_workers = config.NUM_BACKGROUND_WORKERS
        
        logger.info("Background task manager initialized")
    
    def start(self):
        """
        Start the background task manager
        
        Returns:
            bool: Success or failure
        """
        try:
            if self.running:
                logger.warning("Background task manager already running")
                return False
            
            logger.info("Starting background task manager")
            
            # Set running flag
            self.running = True
            
            # Start worker threads
            self._start_workers()
            
            logger.info("Background task manager started")
            return True
        
        except Exception as e:
            logger.error(f"Error starting background task manager: {e}", exc_info=True)
            self.running = False
            return False
    
    def stop(self):
        """
        Stop the background task manager
        
        Returns:
            bool: Success or failure
        """
        try:
            if not self.running:
                logger.warning("Background task manager not running")
                return False
            
            logger.info("Stopping background task manager")
            
            # Clear running flag
            self.running = False
            
            # Stop worker threads
            self._stop_workers()
            
            logger.info("Background task manager stopped")
            return True
        
        except Exception as e:
            logger.error(f"Error stopping background task manager: {e}", exc_info=True)
            return False
    
    def submit_task(self, task_func, task_args=None, task_kwargs=None, task_id=None):
        """
        Submit a task for execution
        
        Args:
            task_func: Function to execute
            task_args: Positional arguments for the function (optional)
            task_kwargs: Keyword arguments for the function (optional)
            task_id: Unique identifier for the task (optional)
            
        Returns:
            str: Task ID
        """
        try:
            # Generate task ID if not provided
            if task_id is None:
                task_id = f"task_{int(time.time())}_{id(task_func)}"
            
            # Add task to queue
            self.task_queue.put((task_id, task_func, task_args or (), task_kwargs or {}))
            
            logger.info(f"Task '{task_id}' submitted")
            return task_id
        
        except Exception as e:
            logger.error(f"Error submitting task: {e}", exc_info=True)
            return None
    
    def _start_workers(self):
        """Start worker threads for processing tasks"""
        logger.info(f"Starting {self.num_workers} worker threads")
        
        for i in range(self.num_workers):
            worker = threading.Thread(target=self._worker_loop, args=(i,))
            worker.daemon = True
            worker.start()
            self.worker_threads.append(worker)
        
        logger.info("Worker threads started")
    
    def _stop_workers(self):
        """Stop worker threads"""
        logger.info("Stopping worker threads")
        
        # Signal workers to stop by adding None tasks
        for _ in range(len(self.worker_threads)):
            self.task_queue.put((None, None, None, None))
        
        # Wait for workers to finish
        for thread in self.worker_threads:
            thread.join(timeout=5)
        
        # Clear worker threads list
        self.worker_threads = []
        
        logger.info("Worker threads stopped")
    
    def _worker_loop(self, worker_id):
        """Worker loop for processing tasks"""
        logger.info(f"Worker {worker_id} started")
        
        while self.running:
            try:
                # Get task from queue
                task_id, task_func, task_args, task_kwargs = self.task_queue.get(timeout=1)
                
                # Check if stop signal
                if task_id is None:
                    logger.info(f"Worker {worker_id} received stop signal")
                    break
                
                # Execute task
                logger.info(f"Worker {worker_id} executing task '{task_id}'")
                start_time = time.time()
                
                try:
                    task_func(*task_args, **task_kwargs)
                    
                    # Log execution time
                    execution_time = time.time() - start_time
                    logger.info(f"Task '{task_id}' completed in {execution_time:.2f} seconds")
                
                except Exception as e:
                    logger.error(f"Error executing task '{task_id}': {e}", exc_info=True)
                
                # Mark task as done in queue
                self.task_queue.task_done()
            
            except queue.Empty:
                # Queue timeout, continue loop
                pass
            
            except Exception as e:
                logger.error(f"Error in worker {worker_id}: {e}", exc_info=True)
                time.sleep(5)  # Sleep on error
        
        logger.info(f"Worker {worker_id} stopped")
