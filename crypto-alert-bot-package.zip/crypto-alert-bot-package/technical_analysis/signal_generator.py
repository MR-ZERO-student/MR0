"""
Signal Generator Module

This module combines technical analysis indicators to generate trading signals
and provides a unified interface for the alert system.
"""

import logging
import asyncio
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Import local modules
from technical_analysis.indicators import TechnicalAnalysis, MultiTimeframeAnalysis
from technical_analysis.price_data import PriceDataFetcher

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class SignalGenerator:
    """Class for generating trading signals based on technical analysis"""
    
    def __init__(self):
        """Initialize the signal generator"""
        self.price_fetcher = PriceDataFetcher()
        self.analyzer = TechnicalAnalysis()
        self.mtf_analyzer = MultiTimeframeAnalysis()
        
        # Cache for signals
        self.signal_cache = {}
        
        logger.info("Signal generator initialized")
    
    async def generate_signal(self, symbol, exchange='binance'):
        """
        Generate trading signal for a cryptocurrency on a centralized exchange
        
        Args:
            symbol: Trading pair symbol (e.g., 'BTC/USDT')
            exchange: Exchange to fetch data from
            
        Returns:
            dict with signal data
        """
        try:
            # Fetch price data for multiple timeframes
            price_data = await self.price_fetcher.fetch_multi_timeframe_data(symbol, exchange)
            
            if not price_data:
                logger.error(f"No price data available for {symbol} on {exchange}")
                return None
            
            # Analyze all timeframes
            analysis_results = self.mtf_analyzer.analyze_all_timeframes(price_data)
            
            # Get consensus signal
            consensus = self.mtf_analyzer.get_consensus_signal(analysis_results)
            
            if not consensus:
                logger.warning(f"Could not generate consensus signal for {symbol}")
                return None
            
            # Add symbol and timestamp
            consensus['symbol'] = symbol
            consensus['exchange'] = exchange
            consensus['timestamp'] = datetime.now()
            
            # Generate chart for the 1-hour timeframe if available
            chart_path = None
            if 60 in analysis_results:
                chart_path = self.analyzer.generate_chart(
                    analysis_results[60],
                    title=f"{symbol} Technical Analysis",
                    save_path=f"/tmp/{symbol.replace('/', '_')}_chart.png"
                )
            
            consensus['chart_path'] = chart_path
            
            # Cache the signal
            self.signal_cache[symbol] = {
                'timestamp': datetime.now(),
                'data': consensus
            }
            
            return consensus
        
        except Exception as e:
            logger.error(f"Error generating signal for {symbol}: {e}", exc_info=True)
            return None
    
    async def generate_token_signal(self, token_address, chain='ethereum'):
        """
        Generate trading signal for a token on a decentralized exchange
        
        Args:
            token_address: Token contract address
            chain: Blockchain (ethereum, bsc, etc.)
            
        Returns:
            dict with signal data
        """
        try:
            # Fetch price data for the token
            price_data = await self.price_fetcher.fetch_token_price_data(token_address, chain)
            
            if not price_data:
                logger.error(f"No price data available for token {token_address} on {chain}")
                return None
            
            # Analyze all timeframes
            analysis_results = self.mtf_analyzer.analyze_all_timeframes(price_data)
            
            # Get consensus signal
            consensus = self.mtf_analyzer.get_consensus_signal(analysis_results)
            
            if not consensus:
                logger.warning(f"Could not generate consensus signal for token {token_address}")
                return None
            
            # Add token info and timestamp
            consensus['token_address'] = token_address
            consensus['chain'] = chain
            consensus['timestamp'] = datetime.now()
            
            # Generate chart for the largest timeframe available
            chart_path = None
            if analysis_results:
                # Get the largest timeframe
                largest_tf = max(analysis_results.keys())
                chart_path = self.analyzer.generate_chart(
                    analysis_results[largest_tf],
                    title=f"Token {token_address} Technical Analysis",
                    save_path=f"/tmp/{token_address}_chart.png"
                )
            
            consensus['chart_path'] = chart_path
            
            # Cache the signal
            cache_key = f"{chain}:{token_address}"
            self.signal_cache[cache_key] = {
                'timestamp': datetime.now(),
                'data': consensus
            }
            
            return consensus
        
        except Exception as e:
            logger.error(f"Error generating signal for token {token_address}: {e}", exc_info=True)
            return None
    
    def get_cached_signal(self, symbol_or_token, chain=None):
        """
        Get cached signal for a symbol or token
        
        Args:
            symbol_or_token: Trading pair symbol or token address
            chain: Blockchain (required for tokens)
            
        Returns:
            dict with signal data or None if not in cache or expired
        """
        # Determine cache key
        if chain:
            cache_key = f"{chain}:{symbol_or_token}"
        else:
            cache_key = symbol_or_token
        
        # Check if in cache
        if cache_key in self.signal_cache:
            cache_entry = self.signal_cache[cache_key]
            cache_age = (datetime.now() - cache_entry['timestamp']).total_seconds() / 60
            
            # Use cache if less than 15 minutes old
            if cache_age < 15:
                return cache_entry['data']
        
        return None
    
    async def scan_for_signals(self, symbols=None):
        """
        Scan multiple cryptocurrencies for trading signals
        
        Args:
            symbols: List of symbols to scan (default: predefined list)
            
        Returns:
            dict with symbols as keys and signal data as values
        """
        if symbols is None:
            # Default list of top cryptocurrencies
            symbols = [
                'BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'SOL/USDT', 'XRP/USDT',
                'ADA/USDT', 'DOGE/USDT', 'AVAX/USDT', 'MATIC/USDT', 'DOT/USDT'
            ]
        
        results = {}
        
        # Process symbols in parallel
        tasks = [self.generate_signal(symbol) for symbol in symbols]
        signals = await asyncio.gather(*tasks)
        
        # Combine results
        for i, symbol in enumerate(symbols):
            if signals[i]:
                results[symbol] = signals[i]
        
        return results
    
    def filter_strong_signals(self, signals, min_confidence=70, min_trend_strength=60):
        """
        Filter signals to get only strong ones
        
        Args:
            signals: Dict with symbols as keys and signal data as values
            min_confidence: Minimum confidence level (0-100)
            min_trend_strength: Minimum trend strength (0-100)
            
        Returns:
            dict with filtered signals
        """
        filtered = {}
        
        for symbol, signal in signals.items():
            # Check if signal meets criteria
            if (signal['confidence'] >= min_confidence and 
                signal['trend_strength'] >= min_trend_strength and
                signal['signal'] != 0):  # Not neutral
                
                filtered[symbol] = signal
        
        return filtered
