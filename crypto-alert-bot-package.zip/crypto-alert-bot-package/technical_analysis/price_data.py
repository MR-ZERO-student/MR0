"""
Price Data Fetcher Module

This module fetches price data from various sources for technical analysis.
"""

import logging
import asyncio
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import ccxt
import requests
import json

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class PriceDataFetcher:
    """Class for fetching price data from various sources"""
    
    def __init__(self):
        """Initialize the price data fetcher"""
        # Initialize exchange clients
        self.exchanges = {}
        self._init_exchanges()
        
        # Cache for price data
        self.price_cache = {}
        
        logger.info("Price data fetcher initialized")
    
    def _init_exchanges(self):
        """Initialize exchange API clients"""
        try:
            # Initialize CCXT exchange clients
            self.exchanges['binance'] = ccxt.binance()
            self.exchanges['kucoin'] = ccxt.kucoin()
            self.exchanges['coinbase'] = ccxt.coinbasepro()
            
            logger.info("Exchange clients initialized")
        except Exception as e:
            logger.error(f"Error initializing exchange clients: {e}", exc_info=True)
    
    async def fetch_ohlcv(self, symbol, timeframe='1h', limit=100, exchange='binance'):
        """
        Fetch OHLCV (Open, High, Low, Close, Volume) data from an exchange
        
        Args:
            symbol: Trading pair symbol (e.g., 'BTC/USDT')
            timeframe: Timeframe for candles (e.g., '1m', '5m', '1h', '1d')
            limit: Number of candles to fetch
            exchange: Exchange to fetch from
            
        Returns:
            DataFrame with OHLCV data
        """
        try:
            # Check if exchange is supported
            if exchange not in self.exchanges:
                logger.error(f"Unsupported exchange: {exchange}")
                return None
            
            # Get exchange client
            client = self.exchanges[exchange]
            
            # Fetch OHLCV data
            ohlcv = client.fetch_ohlcv(symbol, timeframe, limit=limit)
            
            # Convert to DataFrame
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            
            # Convert timestamp to datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            # Cache the data
            cache_key = f"{exchange}:{symbol}:{timeframe}"
            self.price_cache[cache_key] = {
                'timestamp': datetime.now(),
                'data': df
            }
            
            return df
        
        except Exception as e:
            logger.error(f"Error fetching OHLCV data: {e}", exc_info=True)
            return None
    
    async def fetch_dexscreener_price(self, pair_address, chain='ethereum'):
        """
        Fetch price data from DexScreener API
        
        Args:
            pair_address: Address of the trading pair
            chain: Blockchain (ethereum, bsc, etc.)
            
        Returns:
            DataFrame with price data
        """
        try:
            # DexScreener API URL
            url = f"https://api.dexscreener.com/latest/dex/pairs/{chain}/{pair_address}"
            
            # Make request
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()
            
            # Check if pair data exists
            if 'pairs' not in data or not data['pairs']:
                logger.warning(f"No pair data found for {pair_address} on {chain}")
                return None
            
            # Get pair data
            pair = data['pairs'][0]
            
            # Get price data
            price_data = pair.get('priceData', {})
            
            # Check if price data exists
            if not price_data or 'candles' not in price_data:
                logger.warning(f"No price data found for {pair_address} on {chain}")
                return None
            
            # Get candles
            candles = price_data['candles']
            
            # Convert to DataFrame
            df = pd.DataFrame(candles)
            
            # Rename columns to match OHLCV format
            df = df.rename(columns={
                'time': 'timestamp',
                'h': 'high',
                'l': 'low',
                'o': 'open',
                'c': 'close',
                'v': 'volume'
            })
            
            # Convert timestamp to datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            # Cache the data
            cache_key = f"dexscreener:{chain}:{pair_address}"
            self.price_cache[cache_key] = {
                'timestamp': datetime.now(),
                'data': df
            }
            
            return df
        
        except Exception as e:
            logger.error(f"Error fetching DexScreener price data: {e}", exc_info=True)
            return None
    
    async def fetch_multi_timeframe_data(self, symbol, exchange='binance'):
        """
        Fetch price data for multiple timeframes
        
        Args:
            symbol: Trading pair symbol (e.g., 'BTC/USDT')
            exchange: Exchange to fetch from
            
        Returns:
            Dictionary with timeframes as keys and price DataFrames as values
        """
        results = {}
        
        # Map config timeframes (minutes) to exchange timeframes
        timeframe_map = {
            1: '1m',
            5: '5m',
            15: '15m',
            60: '1h'
        }
        
        # Fetch data for each timeframe
        for minutes, tf in timeframe_map.items():
            if minutes in config.TIMEFRAMES:
                df = await self.fetch_ohlcv(symbol, timeframe=tf, exchange=exchange)
                if df is not None:
                    results[minutes] = df
        
        return results
    
    async def fetch_token_price_data(self, token_address, chain='ethereum'):
        """
        Fetch token price data from appropriate source based on chain
        
        Args:
            token_address: Token contract address
            chain: Blockchain (ethereum, bsc, etc.)
            
        Returns:
            Dictionary with timeframes as keys and price DataFrames as values
        """
        # For now, just use DexScreener for all chains
        # In a production system, you would use different sources based on the chain
        
        # Get pair address (this is simplified, in reality you'd need to find the main liquidity pair)
        # This would typically involve querying the blockchain or using an API
        
        # For demonstration, we'll just use the token address as the pair address
        pair_address = token_address
        
        # Fetch data from DexScreener
        df = await self.fetch_dexscreener_price(pair_address, chain)
        
        if df is None:
            return {}
        
        # For demonstration, we'll just use the same data for all timeframes
        # In a production system, you would fetch data for each timeframe or resample
        
        results = {}
        for tf in config.TIMEFRAMES:
            results[tf] = df
        
        return results
