"""
Technical Analysis Module

This module implements advanced technical indicators for cryptocurrency analysis,
including Gaussian Channel, Stochastic RSI, MACD, and ATR-based filters.
"""

import numpy as np
import pandas as pd
import logging
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import io
import os

# Import configuration
import sys
sys.path.append('/home/ubuntu/crypto_alert_bot')
import config

logger = logging.getLogger(__name__)

class TechnicalAnalysis:
    """Class for performing technical analysis on cryptocurrency price data"""
    
    def __init__(self):
        """Initialize the technical analysis module"""
        # Parameters from config
        self.gaussian_period = config.GAUSSIAN_CHANNEL_PERIOD
        self.stoch_rsi_period = config.STOCH_RSI_PERIOD
        self.stoch_rsi_k = config.STOCH_RSI_K
        self.stoch_rsi_d = config.STOCH_RSI_D
        self.macd_fast = config.MACD_FAST
        self.macd_slow = config.MACD_SLOW
        self.macd_signal = config.MACD_SIGNAL
        self.atr_period = config.ATR_PERIOD
        
        logger.info("Technical analysis module initialized")
    
    def analyze_price_data(self, price_data):
        """
        Analyze price data with all technical indicators
        
        Args:
            price_data: DataFrame with columns 'timestamp', 'open', 'high', 'low', 'close', 'volume'
        
        Returns:
            DataFrame with original data and added technical indicators
        """
        try:
            # Make a copy to avoid modifying the original
            df = price_data.copy()
            
            # Ensure DataFrame has required columns
            required_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
            for col in required_columns:
                if col not in df.columns:
                    logger.error(f"Required column '{col}' not found in price data")
                    return None
            
            # Convert timestamp to datetime if it's not already
            if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
                df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
            
            # Sort by timestamp
            df = df.sort_values('timestamp')
            
            # Calculate all indicators
            df = self.add_gaussian_channel(df)
            df = self.add_stochastic_rsi(df)
            df = self.add_macd(df)
            df = self.add_atr(df)
            
            # Add trend conditions
            df = self.add_trend_conditions(df)
            
            return df
        
        except Exception as e:
            logger.error(f"Error analyzing price data: {e}", exc_info=True)
            return None
    
    def add_gaussian_channel(self, df):
        """
        Add Gaussian Channel to the DataFrame
        
        The Gaussian Channel uses linear regression with HMA/EMA to define trend conditions
        """
        try:
            # Calculate Hull Moving Average (HMA) for smoother price data
            # HMA = WMA(2*WMA(n/2) - WMA(n)), sqrt(n)
            half_length = self.gaussian_period // 2
            sqrt_length = int(np.sqrt(self.gaussian_period))
            
            # Calculate WMA of close prices with period n
            df['wma_full'] = self.weighted_moving_average(df['close'], self.gaussian_period)
            
            # Calculate WMA with period n/2
            df['wma_half'] = self.weighted_moving_average(df['close'], half_length)
            
            # Calculate 2*WMA(n/2) - WMA(n)
            df['wma_diff'] = 2 * df['wma_half'] - df['wma_full']
            
            # Calculate HMA which is WMA of wma_diff with period sqrt(n)
            df['hma'] = self.weighted_moving_average(df['wma_diff'], sqrt_length)
            
            # Calculate linear regression on HMA
            df['gaussian_middle'] = self.linear_regression(df['hma'], self.gaussian_period)
            
            # Calculate standard deviation of price from middle line
            df['price_deviation'] = df['close'] - df['gaussian_middle']
            df['std_dev'] = df['price_deviation'].rolling(window=self.gaussian_period).std()
            
            # Calculate upper and lower bands (middle ± 2*std_dev)
            df['gaussian_upper'] = df['gaussian_middle'] + 2 * df['std_dev']
            df['gaussian_lower'] = df['gaussian_middle'] - 2 * df['std_dev']
            
            # Calculate slope of middle line
            df['gaussian_slope'] = self.calculate_slope(df['gaussian_middle'], 5)
            
            # Clean up intermediate columns
            df = df.drop(['wma_full', 'wma_half', 'wma_diff', 'price_deviation'], axis=1)
            
            return df
        
        except Exception as e:
            logger.error(f"Error calculating Gaussian Channel: {e}", exc_info=True)
            # Return original DataFrame if calculation fails
            return df
    
    def add_stochastic_rsi(self, df):
        """
        Add Stochastic RSI to the DataFrame
        
        StochRSI combines RSI and Stochastic to create a more responsive momentum indicator
        """
        try:
            # Calculate RSI
            df['rsi'] = self.relative_strength_index(df['close'], self.stoch_rsi_period)
            
            # Calculate Stochastic RSI
            # First, get highest and lowest RSI values over the period
            df['rsi_high'] = df['rsi'].rolling(window=self.stoch_rsi_period).max()
            df['rsi_low'] = df['rsi'].rolling(window=self.stoch_rsi_period).min()
            
            # Calculate raw Stochastic RSI
            rsi_range = df['rsi_high'] - df['rsi_low']
            df['stoch_rsi_k_raw'] = 100 * ((df['rsi'] - df['rsi_low']) / rsi_range.replace(0, 1))
            
            # Apply smoothing to K and calculate D
            df['stoch_rsi_k'] = df['stoch_rsi_k_raw'].rolling(window=self.stoch_rsi_k).mean()
            df['stoch_rsi_d'] = df['stoch_rsi_k'].rolling(window=self.stoch_rsi_d).mean()
            
            # Calculate slope of K line
            df['stoch_rsi_k_slope'] = self.calculate_slope(df['stoch_rsi_k'], 3)
            
            # Clean up intermediate columns
            df = df.drop(['rsi_high', 'rsi_low', 'stoch_rsi_k_raw'], axis=1)
            
            return df
        
        except Exception as e:
            logger.error(f"Error calculating Stochastic RSI: {e}", exc_info=True)
            # Return original DataFrame if calculation fails
            return df
    
    def add_macd(self, df):
        """
        Add MACD (Moving Average Convergence Divergence) to the DataFrame
        
        MACD with slope filtering helps confirm trends and filter out market noise
        """
        try:
            # Calculate EMAs
            df['ema_fast'] = df['close'].ewm(span=self.macd_fast, adjust=False).mean()
            df['ema_slow'] = df['close'].ewm(span=self.macd_slow, adjust=False).mean()
            
            # Calculate MACD line
            df['macd_line'] = df['ema_fast'] - df['ema_slow']
            
            # Calculate signal line
            df['macd_signal'] = df['macd_line'].ewm(span=self.macd_signal, adjust=False).mean()
            
            # Calculate histogram
            df['macd_histogram'] = df['macd_line'] - df['macd_signal']
            
            # Calculate slopes
            df['macd_line_slope'] = self.calculate_slope(df['macd_line'], 3)
            df['macd_hist_slope'] = self.calculate_slope(df['macd_histogram'], 3)
            
            # Clean up intermediate columns
            df = df.drop(['ema_fast', 'ema_slow'], axis=1)
            
            return df
        
        except Exception as e:
            logger.error(f"Error calculating MACD: {e}", exc_info=True)
            # Return original DataFrame if calculation fails
            return df
    
    def add_atr(self, df):
        """
        Add ATR (Average True Range) to the DataFrame
        
        ATR is used for adaptive filtering and dynamic threshold setting
        """
        try:
            # Calculate True Range
            df['tr1'] = abs(df['high'] - df['low'])
            df['tr2'] = abs(df['high'] - df['close'].shift(1))
            df['tr3'] = abs(df['low'] - df['close'].shift(1))
            df['true_range'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)
            
            # Calculate ATR
            df['atr'] = df['true_range'].rolling(window=self.atr_period).mean()
            
            # Calculate ATR percentage (ATR relative to price)
            df['atr_pct'] = (df['atr'] / df['close']) * 100
            
            # Calculate dynamic thresholds based on ATR
            df['atr_upper'] = df['close'] + df['atr'] * config.ATR_MULTIPLIER_TP
            df['atr_lower'] = df['close'] - df['atr'] * config.ATR_MULTIPLIER_SL
            
            # Clean up intermediate columns
            df = df.drop(['tr1', 'tr2', 'tr3', 'true_range'], axis=1)
            
            return df
        
        except Exception as e:
            logger.error(f"Error calculating ATR: {e}", exc_info=True)
            # Return original DataFrame if calculation fails
            return df
    
    def add_trend_conditions(self, df):
        """
        Add trend conditions based on all indicators
        """
        try:
            # Initialize trend columns
            df['trend'] = 0  # 1 for bullish, -1 for bearish, 0 for neutral
            df['trend_strength'] = 0  # 0-100 scale
            
            # Gaussian Channel trend
            df['gaussian_trend'] = 0
            df.loc[df['gaussian_slope'] > 0, 'gaussian_trend'] = 1
            df.loc[df['gaussian_slope'] < 0, 'gaussian_trend'] = -1
            
            # Price position relative to Gaussian Channel
            df['price_position'] = 0
            df.loc[df['close'] > df['gaussian_upper'], 'price_position'] = 2  # Overbought
            df.loc[(df['close'] > df['gaussian_middle']) & (df['close'] <= df['gaussian_upper']), 'price_position'] = 1  # Bullish
            df.loc[(df['close'] < df['gaussian_middle']) & (df['close'] >= df['gaussian_lower']), 'price_position'] = -1  # Bearish
            df.loc[df['close'] < df['gaussian_lower'], 'price_position'] = -2  # Oversold
            
            # Stochastic RSI signals
            df['stoch_rsi_signal'] = 0
            df.loc[(df['stoch_rsi_k'] > df['stoch_rsi_d']) & (df['stoch_rsi_k_slope'] > 0), 'stoch_rsi_signal'] = 1
            df.loc[(df['stoch_rsi_k'] < df['stoch_rsi_d']) & (df['stoch_rsi_k_slope'] < 0), 'stoch_rsi_signal'] = -1
            
            # Overbought/Oversold conditions
            df.loc[df['stoch_rsi_k'] > 80, 'stoch_rsi_signal'] = 2  # Overbought
            df.loc[df['stoch_rsi_k'] < 20, 'stoch_rsi_signal'] = -2  # Oversold
            
            # MACD signals
            df['macd_signal_value'] = 0
            df.loc[(df['macd_line'] > df['macd_signal']) & (df['macd_line_slope'] > 0), 'macd_signal_value'] = 1
            df.loc[(df['macd_line'] < df['macd_signal']) & (df['macd_line_slope'] < 0), 'macd_signal_value'] = -1
            
            # Combine signals for overall trend
            # Weight the signals (can be adjusted based on preference)
            gaussian_weight = 0.4
            stoch_rsi_weight = 0.3
            macd_weight = 0.3
            
            df['trend_raw'] = (
                df['gaussian_trend'] * gaussian_weight +
                df['stoch_rsi_signal'] * stoch_rsi_weight +
                df['macd_signal_value'] * macd_weight
            )
            
            # Determine final trend
            df.loc[df['trend_raw'] > 0.2, 'trend'] = 1  # Bullish
            df.loc[df['trend_raw'] < -0.2, 'trend'] = -1  # Bearish
            
            # Calculate trend strength (0-100)
            df['trend_strength'] = abs(df['trend_raw']) * 100
            df['trend_strength'] = df['trend_strength'].clip(0, 100)
            
            # Clean up intermediate columns
            df = df.drop(['trend_raw'], axis=1)
            
            return df
        
        except Exception as e:
            logger.error(f"Error calculating trend conditions: {e}", exc_info=True)
            # Return original DataFrame if calculation fails
            return df
    
    def generate_signals(self, df):
        """
        Generate buy/sell signals based on technical analysis
        
        Returns:
            DataFrame with added signal column (1 for buy, -1 for sell, 0 for hold)
        """
        try:
            # Initialize signal column
            df['signal'] = 0
            
            # Generate buy signals
            buy_condition = (
                (df['trend'] == 1) &  # Bullish trend
                (df['stoch_rsi_k'] < 80) &  # Not overbought
                (df['stoch_rsi_k'] > df['stoch_rsi_d']) &  # StochRSI K above D
                (df['macd_line'] > df['macd_signal']) &  # MACD line above signal
                (df['macd_histogram'] > 0) &  # Positive MACD histogram
                (df['close'] > df['gaussian_middle'])  # Price above Gaussian middle
            )
            
            # Generate sell signals
            sell_condition = (
                (df['trend'] == -1) &  # Bearish trend
                (df['stoch_rsi_k'] > 20) &  # Not oversold
                (df['stoch_rsi_k'] < df['stoch_rsi_d']) &  # StochRSI K below D
                (df['macd_line'] < df['macd_signal']) &  # MACD line below signal
                (df['macd_histogram'] < 0) &  # Negative MACD histogram
                (df['close'] < df['gaussian_middle'])  # Price below Gaussian middle
            )
            
            # Apply signals
            df.loc[buy_condition, 'signal'] = 1
            df.loc[sell_condition, 'signal'] = -1
            
            return df
        
        except Exception as e:
            logger.error(f"Error generating signals: {e}", exc_info=True)
            # Return original DataFrame if calculation fails
            return df
    
    def get_latest_signal(self, df):
        """
        Get the latest signal and analysis from the DataFrame
        
        Returns:
            dict with latest signal and analysis data
        """
        try:
            if df is None or df.empty:
                return None
            
            # Get the latest row
            latest = df.iloc[-1]
            
            # Create signal data
            signal_data = {
                'timestamp': latest['timestamp'],
                'price': latest['close'],
                'signal': latest['signal'],  # 1 for buy, -1 for sell, 0 for hold
                'trend': latest['trend'],  # 1 for bullish, -1 for bearish, 0 for neutral
                'trend_strength': latest['trend_strength'],
                'gaussian_middle': latest['gaussian_middle'],
                'gaussian_upper': latest['gaussian_upper'],
                'gaussian_lower': latest['gaussian_lower'],
                'stoch_rsi_k': latest['stoch_rsi_k'],
                'stoch_rsi_d': latest['stoch_rsi_d'],
                'macd_line': latest['macd_line'],
                'macd_signal': latest['macd_signal'],
                'macd_histogram': latest['macd_histogram'],
                'atr': latest['atr'],
                'atr_pct': latest['atr_pct'],
                'stop_loss': latest['atr_lower'],
                'take_profit': latest['atr_upper']
            }
            
            return signal_data
        
        except Exception as e:
            logger.error(f"Error getting latest signal: {e}", exc_info=True)
            return None
    
    def generate_chart(self, df, title="Price Chart with Technical Indicators", save_path=None):
        """
        Generate a chart with price and technical indicators
        
        Args:
            df: DataFrame with price and indicator data
            title: Chart title
            save_path: Path to save the chart image
            
        Returns:
            Path to saved chart image or None if failed
        """
        try:
            if df is None or df.empty:
                logger.error("Cannot generate chart: DataFrame is empty or None")
                return None
            
            # Create figure with subplots
            fig = plt.figure(figsize=(12, 10))
            
            # Price and Gaussian Channel subplot
            ax1 = plt.subplot2grid((4, 1), (0, 0), rowspan=2)
            ax1.set_title(title)
            ax1.plot(df['timestamp'], df['close'], label='Price', color='black')
            ax1.plot(df['timestamp'], df['gaussian_middle'], label='Gaussian Middle', color='blue')
            ax1.plot(df['timestamp'], df['gaussian_upper'], label='Gaussian Upper', color='green', linestyle='--')
            ax1.plot(df['timestamp'], df['gaussian_lower'], label='Gaussian Lower', color='red', linestyle='--')
            
            # Add buy/sell signals
            buy_signals = df[df['signal'] == 1]
            sell_signals = df[df['signal'] == -1]
            
            ax1.scatter(buy_signals['timestamp'], buy_signals['close'], marker='^', color='green', s=100, label='Buy')
            ax1.scatter(sell_signals['timestamp'], sell_signals['close'], marker='v', color='red', s=100, label='Sell')
            
            ax1.set_ylabel('Price')
            ax1.grid(True)
            ax1.legend(loc='upper left')
            
            # Stochastic RSI subplot
            ax2 = plt.subplot2grid((4, 1), (2, 0), rowspan=1, sharex=ax1)
            ax2.plot(df['timestamp'], df['stoch_rsi_k'], label='Stoch RSI K', color='blue')
            ax2.plot(df['timestamp'], df['stoch_rsi_d'], label='Stoch RSI D', color='red')
            ax2.axhline(80, color='red', linestyle='--')
            ax2.axhline(20, color='green', linestyle='--')
            ax2.set_ylabel('Stoch RSI')
            ax2.grid(True)
            ax2.legend(loc='upper left')
            
            # MACD subplot
            ax3 = plt.subplot2grid((4, 1), (3, 0), rowspan=1, sharex=ax1)
            ax3.plot(df['timestamp'], df['macd_line'], label='MACD', color='blue')
            ax3.plot(df['timestamp'], df['macd_signal'], label='Signal', color='red')
            ax3.bar(df['timestamp'], df['macd_histogram'], label='Histogram', color='green', alpha=0.5)
            ax3.set_ylabel('MACD')
            ax3.grid(True)
            ax3.legend(loc='upper left')
            
            # Format x-axis
            plt.xlabel('Date')
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
            plt.xticks(rotation=45)
            
            # Adjust layout
            plt.tight_layout()
            
            # Save chart if path provided
            if save_path:
                plt.savefig(save_path)
                plt.close(fig)
                return save_path
            else:
                # Save to a temporary file
                temp_path = '/tmp/chart.png'
                plt.savefig(temp_path)
                plt.close(fig)
                return temp_path
        
        except Exception as e:
            logger.error(f"Error generating chart: {e}", exc_info=True)
            return None
    
    # Helper methods for technical indicators
    
    def weighted_moving_average(self, series, period):
        """Calculate Weighted Moving Average"""
        weights = np.arange(1, period + 1)
        return series.rolling(period).apply(lambda x: np.sum(weights * x) / weights.sum(), raw=True)
    
    def linear_regression(self, series, period):
        """Calculate Linear Regression line"""
        return series.rolling(window=period).apply(
            lambda x: np.polyval(np.polyfit(np.arange(len(x)), x, 1), len(x) - 1)
        )
    
    def calculate_slope(self, series, period):
        """Calculate slope of a series over a period"""
        def slope(x):
            if len(x) < 2:
                return 0
            return np.polyfit(np.arange(len(x)), x, 1)[0]
        
        return series.rolling(window=period).apply(slope, raw=True)
    
    def relative_strength_index(self, series, period):
        """Calculate Relative Strength Index"""
        delta = series.diff()
        gain = delta.where(delta > 0, 0).rolling(window=period).mean()
        loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
        
        rs = gain / loss.replace(0, 1e-9)  # Avoid division by zero
        rsi = 100 - (100 / (1 + rs))
        
        return rsi


class MultiTimeframeAnalysis:
    """Class for performing analysis across multiple timeframes"""
    
    def __init__(self):
        """Initialize the multi-timeframe analysis"""
        self.timeframes = config.TIMEFRAMES  # [1, 5, 15, 60] minutes
        self.analyzer = TechnicalAnalysis()
        
        logger.info("Multi-timeframe analysis initialized")
    
    def analyze_all_timeframes(self, price_data_dict):
        """
        Analyze price data across all timeframes
        
        Args:
            price_data_dict: Dictionary with timeframes as keys and price DataFrames as values
            
        Returns:
            Dictionary with timeframes as keys and analysis results as values
        """
        results = {}
        
        for timeframe, df in price_data_dict.items():
            if df is not None and not df.empty:
                # Analyze this timeframe
                analysis = self.analyzer.analyze_price_data(df)
                analysis = self.analyzer.generate_signals(analysis)
                results[timeframe] = analysis
        
        return results
    
    def get_consensus_signal(self, analysis_results):
        """
        Get consensus signal across all timeframes
        
        Args:
            analysis_results: Dictionary with timeframes as keys and analysis results as values
            
        Returns:
            dict with consensus signal and confidence
        """
        if not analysis_results:
            return None
        
        # Get latest signals from each timeframe
        signals = {}
        for timeframe, df in analysis_results.items():
            signal_data = self.analyzer.get_latest_signal(df)
            if signal_data:
                signals[timeframe] = signal_data
        
        if not signals:
            return None
        
        # Calculate consensus
        buy_count = sum(1 for s in signals.values() if s['signal'] == 1)
        sell_count = sum(1 for s in signals.values() if s['signal'] == -1)
        neutral_count = sum(1 for s in signals.values() if s['signal'] == 0)
        
        total_timeframes = len(signals)
        
        # Determine consensus signal
        consensus_signal = 0
        if buy_count > sell_count and buy_count > neutral_count:
            consensus_signal = 1
        elif sell_count > buy_count and sell_count > neutral_count:
            consensus_signal = -1
        
        # Calculate confidence (percentage of timeframes with the same signal)
        if consensus_signal == 1:
            confidence = (buy_count / total_timeframes) * 100
        elif consensus_signal == -1:
            confidence = (sell_count / total_timeframes) * 100
        else:
            confidence = (neutral_count / total_timeframes) * 100
        
        # Get average trend strength
        avg_trend_strength = sum(s['trend_strength'] for s in signals.values()) / total_timeframes
        
        # Create consensus data
        consensus = {
            'signal': consensus_signal,  # 1 for buy, -1 for sell, 0 for neutral
            'confidence': confidence,
            'trend_strength': avg_trend_strength,
            'timeframes_analyzed': total_timeframes,
            'buy_count': buy_count,
            'sell_count': sell_count,
            'neutral_count': neutral_count,
            'signals_by_timeframe': signals
        }
        
        return consensus
