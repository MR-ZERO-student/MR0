"""
Free Config Module

This module provides configuration settings optimized for free operation
of the cryptocurrency analysis and alert system.
"""

# General settings
APP_NAME = "Crypto Alert Bot"
DEBUG_MODE = False

# API settings
USE_PUBLIC_APIS = True
API_TIMEOUT_SECONDS = 30
MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 5

# Market scan settings
MAX_TOKENS_TO_ANALYZE = 10  # Reduced from 50 to save resources
SCAN_INTERVAL_MINUTES = 60  # Increased from 15 to reduce API calls
REMINDER_CHECK_MINUTES = 60  # Increased from 30 to reduce API calls

# Signal settings
MIN_SIGNAL_STRENGTH = 70  # Increased from 60 to reduce false positives
MIN_RISK_SCORE = 60  # Increased from 50 to reduce false positives

# Risk management settings
TRADING_CAPITAL = 1000  # Default trading capital for position sizing
DEFAULT_RISK_PERCENTAGE = 1  # Default risk per trade (1% of capital)
MAX_POSITION_SIZE_PERCENTAGE = 5  # Maximum position size (5% of capital)

# Technical analysis settings
USE_GAUSSIAN_CHANNEL = True
USE_MACD = True
USE_STOCH_RSI = True
USE_ATR = True
USE_MULTI_TIMEFRAME = False  # Disabled to save resources

# Timeframes to analyze (reduced to save resources)
TIMEFRAMES = [
    60,   # 1 hour
    240,  # 4 hours
]

# Visual settings
GENERATE_CHARTS = True
CHART_DPI = 80  # Reduced from 100 to save resources
MAX_CHART_POINTS = 100  # Reduced from 200 to save resources

# System settings
NUM_WORKER_THREADS = 2  # Reduced from 4 to save resources
NUM_BACKGROUND_WORKERS = 1  # Reduced from 2 to save resources
MAX_MEMORY_USAGE_MB = 200  # Maximum memory usage before restart
MAX_CPU_USAGE_PERCENT = 80  # Maximum CPU usage before restart

# Free API endpoints
FREE_DEXSCREENER_API = "https://api.dexscreener.com/latest/dex"
FREE_COINGECKO_API = "https://api.coingecko.com/api/v3"
FREE_ETHERSCAN_API = "https://api.etherscan.io/api"
FREE_BSCSCAN_API = "https://api.bscscan.com/api"

# Social media monitoring settings
MONITOR_TWITTER = False  # Disabled to avoid API costs
MONITOR_REDDIT = True
MONITOR_TELEGRAM = True
SOCIAL_SCAN_INTERVAL_MINUTES = 120  # Increased to reduce API calls

# Blockchain analysis settings
MAX_HOLDERS_TO_ANALYZE = 50  # Reduced from 100 to save resources
HOLDER_ANALYSIS_DEPTH = 10  # Reduced from 20 to save resources

# Telegram settings
TELEGRAM_MESSAGE_INTERVAL_SECONDS = 5  # Minimum time between messages
MAX_ALERTS_PER_DAY = 20  # Maximum number of alerts per day
USE_SIMPLE_MESSAGES = True  # Use simpler messages to save resources

# Logging settings
LOG_LEVEL = "INFO"  # Use INFO instead of DEBUG to reduce log size
MAX_LOG_SIZE_MB = 10
MAX_LOG_FILES = 3

# Android-specific settings
ANDROID_MODE = True  # Enable Android-specific optimizations
BATTERY_SAVER_MODE = True  # Reduce resource usage when battery is low
WIFI_ONLY_MODE = True  # Only perform scans when connected to WiFi
