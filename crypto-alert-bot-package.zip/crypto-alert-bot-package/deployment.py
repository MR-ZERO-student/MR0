"""
Deployment Module

This module handles the deployment and monitoring of the cryptocurrency alert system.
"""

import os
import sys
import logging
import json
import time
import subprocess
import signal
import psutil
from datetime import datetime, timedelta

# Add project root to path
sys.path.append('/home/ubuntu/crypto_alert_bot')

# Import configuration
import config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("deployment.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class Deployment:
    """Class for deploying and monitoring the cryptocurrency alert system"""
    
    def __init__(self, app_dir='/home/ubuntu/crypto_alert_bot'):
        """
        Initialize the deployment
        
        Args:
            app_dir: Application directory
        """
        self.app_dir = app_dir
        self.process = None
        self.start_time = None
        self.restart_count = 0
        self.max_restarts = 5
        self.restart_interval = 60  # seconds
        self.last_restart = None
        self.monitoring_interval = 30  # seconds
        self.running = False
        self.monitor_thread = None
        
        # Create logs directory if it doesn't exist
        os.makedirs(os.path.join(app_dir, 'logs'), exist_ok=True)
        
        logger.info("Deployment initialized")
    
    def deploy(self):
        """
        Deploy the cryptocurrency alert system
        
        Returns:
            bool: Success or failure
        """
        try:
            logger.info("Deploying cryptocurrency alert system")
            
            # Check if already running
            if self.is_running():
                logger.warning("System is already running")
                return False
            
            # Start the application
            result = self.start()
            if not result:
                logger.error("Failed to start the system")
                return False
            
            # Start monitoring
            self.start_monitoring()
            
            logger.info("Deployment successful")
            return True
        
        except Exception as e:
            logger.error(f"Error deploying system: {e}", exc_info=True)
            return False
    
    def start(self):
        """
        Start the cryptocurrency alert system
        
        Returns:
            bool: Success or failure
        """
        try:
            logger.info("Starting cryptocurrency alert system")
            
            # Change to application directory
            os.chdir(self.app_dir)
            
            # Start the application
            self.process = subprocess.Popen(
                ['python3', 'main.py'],
                stdout=open(os.path.join(self.app_dir, 'logs', 'stdout.log'), 'a'),
                stderr=open(os.path.join(self.app_dir, 'logs', 'stderr.log'), 'a'),
                preexec_fn=os.setsid
            )
            
            # Set start time
            self.start_time = datetime.now()
            
            logger.info(f"System started with PID {self.process.pid}")
            return True
        
        except Exception as e:
            logger.error(f"Error starting system: {e}", exc_info=True)
            return False
    
    def stop(self):
        """
        Stop the cryptocurrency alert system
        
        Returns:
            bool: Success or failure
        """
        try:
            logger.info("Stopping cryptocurrency alert system")
            
            # Check if process exists
            if not self.process:
                logger.warning("No process to stop")
                return False
            
            # Stop monitoring
            self.stop_monitoring()
            
            # Send termination signal to process group
            os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
            
            # Wait for process to terminate
            try:
                self.process.wait(timeout=10)
                logger.info("System stopped")
                return True
            except subprocess.TimeoutExpired:
                # Force kill if timeout
                os.killpg(os.getpgid(self.process.pid), signal.SIGKILL)
                logger.warning("System forcefully terminated")
                return True
        
        except Exception as e:
            logger.error(f"Error stopping system: {e}", exc_info=True)
            return False
    
    def restart(self):
        """
        Restart the cryptocurrency alert system
        
        Returns:
            bool: Success or failure
        """
        try:
            logger.info("Restarting cryptocurrency alert system")
            
            # Check restart limits
            current_time = datetime.now()
            if self.last_restart and (current_time - self.last_restart).total_seconds() < self.restart_interval:
                # Too frequent restarts
                self.restart_count += 1
                if self.restart_count > self.max_restarts:
                    logger.error(f"Too many restarts ({self.restart_count}), giving up")
                    return False
            else:
                # Reset restart count if enough time has passed
                self.restart_count = 0
            
            # Update last restart time
            self.last_restart = current_time
            
            # Stop the system
            self.stop()
            
            # Wait a moment
            time.sleep(2)
            
            # Start the system
            result = self.start()
            if not result:
                logger.error("Failed to restart the system")
                return False
            
            # Start monitoring if not already running
            if not self.running:
                self.start_monitoring()
            
            logger.info("System restarted")
            return True
        
        except Exception as e:
            logger.error(f"Error restarting system: {e}", exc_info=True)
            return False
    
    def is_running(self):
        """
        Check if the cryptocurrency alert system is running
        
        Returns:
            bool: True if running, False otherwise
        """
        try:
            if not self.process:
                return False
            
            # Check if process is still running
            return self.process.poll() is None
        
        except Exception as e:
            logger.error(f"Error checking if system is running: {e}", exc_info=True)
            return False
    
    def get_status(self):
        """
        Get status of the cryptocurrency alert system
        
        Returns:
            dict: Status information
        """
        try:
            # Check if process exists
            if not self.process:
                return {
                    'status': 'stopped',
                    'uptime': None,
                    'pid': None,
                    'memory_usage': None,
                    'cpu_usage': None,
                    'start_time': None,
                    'restart_count': self.restart_count
                }
            
            # Check if process is still running
            if not self.is_running():
                return {
                    'status': 'crashed',
                    'uptime': None,
                    'pid': self.process.pid,
                    'memory_usage': None,
                    'cpu_usage': None,
                    'start_time': self.start_time.isoformat() if self.start_time else None,
                    'restart_count': self.restart_count
                }
            
            # Get process information
            process = psutil.Process(self.process.pid)
            
            # Calculate uptime
            uptime = None
            if self.start_time:
                uptime = (datetime.now() - self.start_time).total_seconds()
            
            # Get memory and CPU usage
            memory_info = process.memory_info()
            memory_usage = memory_info.rss / (1024 * 1024)  # MB
            cpu_usage = process.cpu_percent(interval=0.1)
            
            return {
                'status': 'running',
                'uptime': uptime,
                'pid': self.process.pid,
                'memory_usage': memory_usage,
                'cpu_usage': cpu_usage,
                'start_time': self.start_time.isoformat() if self.start_time else None,
                'restart_count': self.restart_count
            }
        
        except Exception as e:
            logger.error(f"Error getting system status: {e}", exc_info=True)
            return {
                'status': 'unknown',
                'error': str(e)
            }
    
    def start_monitoring(self):
        """
        Start monitoring the cryptocurrency alert system
        
        Returns:
            bool: Success or failure
        """
        try:
            logger.info("Starting system monitoring")
            
            # Check if already monitoring
            if self.running:
                logger.warning("Monitoring is already running")
                return False
            
            # Set running flag
            self.running = True
            
            # Start monitor thread
            self.monitor_thread = threading.Thread(target=self._monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            
            logger.info("Monitoring started")
            return True
        
        except Exception as e:
            logger.error(f"Error starting monitoring: {e}", exc_info=True)
            self.running = False
            return False
    
    def stop_monitoring(self):
        """
        Stop monitoring the cryptocurrency alert system
        
        Returns:
            bool: Success or failure
        """
        try:
            logger.info("Stopping system monitoring")
            
            # Check if monitoring is running
            if not self.running:
                logger.warning("Monitoring is not running")
                return False
            
            # Clear running flag
            self.running = False
            
            # Wait for monitor thread to finish
            if self.monitor_thread:
                self.monitor_thread.join(timeout=5)
            
            logger.info("Monitoring stopped")
            return True
        
        except Exception as e:
            logger.error(f"Error stopping monitoring: {e}", exc_info=True)
            return False
    
    def _monitor_loop(self):
        """Monitor loop for checking system status"""
        logger.info("Monitor loop started")
        
        while self.running:
            try:
                # Check if process is running
                if not self.is_running():
                    logger.warning("System is not running, attempting to restart")
                    self.restart()
                
                # Get system status
                status = self.get_status()
                
                # Log status periodically
                logger.info(f"System status: {status['status']}, "
                           f"Memory: {status.get('memory_usage', 'N/A'):.2f} MB, "
                           f"CPU: {status.get('cpu_usage', 'N/A'):.2f}%")
                
                # Check memory usage
                if status.get('memory_usage') and status['memory_usage'] > config.MAX_MEMORY_USAGE_MB:
                    logger.warning(f"Memory usage too high: {status['memory_usage']:.2f} MB, restarting")
                    self.restart()
                
                # Check CPU usage
                if status.get('cpu_usage') and status['cpu_usage'] > config.MAX_CPU_USAGE_PERCENT:
                    logger.warning(f"CPU usage too high: {status['cpu_usage']:.2f}%, restarting")
                    self.restart()
                
                # Sleep for monitoring interval
                time.sleep(self.monitoring_interval)
            
            except Exception as e:
                logger.error(f"Error in monitor loop: {e}", exc_info=True)
                time.sleep(60)  # Sleep longer on error
        
        logger.info("Monitor loop stopped")


def deploy_system():
    """Deploy the cryptocurrency alert system"""
    deployment = Deployment()
    result = deployment.deploy()
    
    if result:
        logger.info("System deployed successfully")
        
        # Print initial status
        status = deployment.get_status()
        logger.info(f"Initial status: {status}")
        
        return deployment
    else:
        logger.error("Failed to deploy system")
        return None


if __name__ == "__main__":
    # Deploy system
    deployment = deploy_system()
    
    if deployment:
        try:
            # Keep the main thread running
            while True:
                time.sleep(1)
        
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received, shutting down")
            deployment.stop()
        
        except Exception as e:
            logger.error(f"Unhandled exception: {e}", exc_info=True)
            deployment.stop()
