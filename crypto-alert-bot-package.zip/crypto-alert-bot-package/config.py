"""
Configuration file for the Cryptocurrency Analysis and Alert System.
Contains API keys, settings, and parameters for various components.
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# API Keys (loaded from environment variables for security)
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
TELEGRAM_CHANNEL_ID = os.getenv('TELEGRAM_CHANNEL_ID', '')
DEXSCREENER_API_KEY = os.getenv('DEXSCREENER_API_KEY', '')
TWITTER_API_KEY = os.getenv('TWITTER_API_KEY', '')
TWITTER_API_SECRET = os.getenv('TWITTER_API_SECRET', '')
TWITTER_ACCESS_TOKEN = os.getenv('TWITTER_ACCESS_TOKEN', '')
TWITTER_ACCESS_SECRET = os.getenv('TWITTER_ACCESS_SECRET', '')
ETHERSCAN_API_KEY = os.getenv('ETHERSCAN_API_KEY', '')
BSC_SCAN_API_KEY = os.getenv('BSC_SCAN_API_KEY', '')

# Blockchain RPC URLs
ETH_RPC_URL = os.getenv('ETH_RPC_URL', 'https://mainnet.infura.io/v3/your-infura-key')
BSC_RPC_URL = os.getenv('BSC_RPC_URL', 'https://bsc-dataseed.binance.org/')
POLYGON_RPC_URL = os.getenv('POLYGON_RPC_URL', 'https://polygon-rpc.com')
SOLANA_RPC_URL = os.getenv('SOLANA_RPC_URL', 'https://api.mainnet-beta.solana.com')

# Technical Analysis Parameters
GAUSSIAN_CHANNEL_PERIOD = 20
STOCH_RSI_PERIOD = 14
STOCH_RSI_K = 3
STOCH_RSI_D = 3
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
ATR_PERIOD = 14

# Risk Management Parameters
RISK_PER_TRADE = 0.01  # 1% of capital per trade
ATR_MULTIPLIER_SL = 2.0  # Stop loss at 2x ATR
ATR_MULTIPLIER_TP = 3.0  # Take profit at 3x ATR

# Timeframes for analysis (in minutes)
TIMEFRAMES = [1, 5, 15, 60]

# Scam Detection Parameters
MIN_HOLDERS_COUNT = 100
MIN_LIQUIDITY_USD = 50000
MIN_HOLDER_AGE_DAYS = 7

# Social Media Monitoring Parameters
TRENDING_THRESHOLD = 50  # Minimum mentions to be considered trending
SENTIMENT_THRESHOLD = 0.6  # Positive sentiment threshold (0-1)

# Alert System Parameters
REMINDER_INTERVALS = [15, 60, 240]  # Reminder intervals in minutes
PRICE_ALERT_THRESHOLDS = [0.05, 0.1, 0.2]  # 5%, 10%, 20% price movements

# Telegram Message Settings
USE_EMOJIS = True
INCLUDE_CHARTS = True
MAX_ALERTS_PER_HOUR = 10

# Coin Rating System Parameters
RATING_WEIGHTS = {
    'liquidity': 0.2,
    'volume': 0.15,
    'holders': 0.15,
    'social_hype': 0.2,
    'technical_score': 0.2,
    'risk_score': 0.1
}

# Logging Configuration
LOG_LEVEL = 'INFO'
LOG_FILE = 'crypto_alert_bot.log'
